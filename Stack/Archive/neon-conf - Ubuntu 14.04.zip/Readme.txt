08/20/1016- Jeff Lill
---------------------

This archive contains the [neon-conf] tool source code before I stripped out
support for Ubuntu 14.04 in favor of Ubuntu 16.04 and also simplified the 
installation by:

	* Using the integrated Docker 1.12 Swarm implementation.
	* Removing Weave.net, Weave Scope, and Weave Flux
	* Etcd
	
It appears that Docker is steadily implementing Weave related functionality
so I'm betting that this will be deprecated or reimplemented by Weave.  Docker
1.12 has added services and service networking now (like Flux did).  The main
things missing are multicast and cross DC networking/encryption which I can
live without for now.  Weave is hinting at a new product coming out in a few
months that may address these.  For now, I've wasted enough time on the bleeding
edge with Weave.

Docker Swarm no longer needs an external key/value store but we still need Consul
for Vault, so we're leaving that alone.

Etcd was being used by Flux which we're removing so I can remove Etcd as well.

I'm archiving this code in case I want to come back and revisit some of these
in the future.
