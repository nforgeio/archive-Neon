﻿//-----------------------------------------------------------------------------
// FILE:	    NodeHostFolder.cs
// CONTRIBUTOR: Jeff Lill
// COPYRIGHT:	Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using Neon.Stack.Common;

using Renci.SshNet;

namespace Neon.Stack.Management
{
    /// <summary>
    /// Enumerates the paths of important directory for Neon cluster node host
    /// machines.
    /// </summary>
    public static class NodeHostFolder
    {
        /// <summary>
        /// Path to the Neon Cluster configuration directory on the remote machine.
        /// </summary>
        public const string ConfigFolder = "/etc/neoncloud";

        /// <summary>
        /// Path to the Neon Cluster secrets directory on the remote machine.
        /// </summary>
        public const string SecretsFolder = "/etc/neoncloud/secrets";

        /// <summary>
        /// Path to the Neon Cluster state directory on the remote machine.
        /// </summary>
        public const string StateFolder = "/var/local/neoncloud";

        /// <summary>
        /// Path to the Neon Cluster setup scripts directory on the remote machine.
        /// </summary>
        public const string SetupFolder = "/opt/neonsetup";

        /// <summary>
        /// Path to the Neon Cluster Docker Compose scripts directory on the remote machine.
        /// </summary>
        public const string ComposeFolder = "/opt/neoncompose";
    }
}
