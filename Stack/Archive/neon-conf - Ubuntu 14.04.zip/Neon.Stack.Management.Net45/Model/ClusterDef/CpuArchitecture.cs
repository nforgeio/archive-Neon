﻿//-----------------------------------------------------------------------------
// FILE:	    CpuArchitecture.cs
// CONTRIBUTOR: Jeff Lill
// COPYRIGHT:	Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.Contracts;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;

using Neon.Stack.Common;

namespace Neon.Stack.Management
{
    /// <summary>
    /// Enumerates the possible CPU architectures.
    /// </summary>
    public enum CpuArchitecture
    {
        /// <summary>
        /// Architecture is unknown.
        /// </summary>
        Unknown = 0,

        /// <summary>
        /// 32-bit Intel/AMD.
        /// </summary>
        x32,

        /// <summary>
        /// 64-bit Intel/AMD.
        /// </summary>
        x64,

        /// <summary>
        /// 32-bit ARM.
        /// </summary>
        ARM32,

        /// <summary>
        /// 64-bit ARM.
        /// </summary>
        ARM64
    }
}
