﻿//-----------------------------------------------------------------------------
// FILE:	    SchedulingStrategy.cs
// CONTRIBUTOR: Jeff Lill
// COPYRIGHT:	Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.

using System;

namespace Neon.Stack.Management
{
    /// <summary>
    /// Enumerates the supported Swarm container scheduling strategies.
    /// </summary>
    /// <remarks>
    /// <para>
    /// Docker Swarm supports multiple basic strategies for deciding
    /// which node will be scheduled to run a container.  This is a cluster
    /// wide setting.  You can find more information at:
    /// </para>
    /// <para>
    /// The <see cref="Spread"/> and <see cref="Binpack"/> strategies select a node 
    /// according it's available CPU, its RAM, and the number of containers 
    /// it has. The <see cref="Random"/> strategy uses no computation. It selects 
    /// nodes at random and is primarily intended for debugging.
    /// </para>
    /// <para>
    /// https://docs.docker.com/swarm/scheduler/strategy/
    /// </para>
    /// </remarks>
    public enum SchedulingStrategy
    {
        /// <summary>
        /// Optimizes for the node with the least number of containers.  This
        /// is the default for Neon clusters.
        /// </summary>
        /// <remarks>
        /// Using the <see cref="Spread"/> strategy results in containers spread 
        /// thinly over many machines. The advantage of this strategy is that if
        /// a node goes down you only lose a few containers.
        /// </remarks>
        Spread,

        /// <summary>
        /// Optimizes for the node which is already most packed.
        /// </summary>
        /// <remarks>
        /// The <see cref="Binpack"/> strategy avoids fragmentation because it 
        /// leaves room for bigger containers on unused machines. The strategic 
        /// advantage of <see cref="Binpack"/> is that you use fewer machines 
        /// as Swarm tries to pack as many containers as it can on a node.
        /// </remarks>
        Binpack,

        /// <summary>
        /// Chooses a node at random, regardless of their available CPU or RAM.
        /// </summary>
        /// <remarks>
        /// This strategy is primarily intended for debugging purposes.
        /// </remarks>
        Random
    }
}
