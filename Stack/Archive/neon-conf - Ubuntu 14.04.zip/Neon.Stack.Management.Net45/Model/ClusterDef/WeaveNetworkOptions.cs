﻿//-----------------------------------------------------------------------------
// FILE:	    WeaveNetworkOptions.cs
// CONTRIBUTOR: Jeff Lill
// COPYRIGHT:	Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.Contracts;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;

using Neon.Stack.Common;
using Neon.Stack.Net;

namespace Neon.Stack.Management
{
    /// <summary>
    /// Describes the Weave overlay networking options for a Neon Cluster.
    /// </summary>
    public class WeaveNetworkOptions
    {
        private const bool      defaultEnabled = false;
        private const string    defaultVersion = "1.5.0";

        /// <summary>
        /// Default constructor.
        /// </summary>
        public WeaveNetworkOptions()
        {
        }

        /// <summary>
        /// Returns the name of the build-in Weave overlay network.
        /// </summary>
        [JsonIgnore]
        public string Name { get; private set; } = "weave";

        /// <summary>
        /// Indicates whether Weave overlay networking is enabled.
        /// This currently defaults to <c>false</c> due to a Docker
        /// plugin design flaw that does not ensure that the plugins
        /// are started before dependant containers.
        /// </summary>
        [JsonProperty(Required = Required.Default, DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate)]
        [DefaultValue(defaultEnabled)]
        public bool Enabled { get; set; } = defaultEnabled;

        /// <summary>
        /// The version of Weave networking to be installed.  This defaults to a reasonable
        /// recent version.
        /// </summary>
        [JsonProperty(Required = Required.Default, DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate)]
        [DefaultValue(defaultVersion)]
        public string Version { get; set; } = defaultVersion;

        /// <summary>
        /// The shared key used by Weave to encrypt network traffic between cluster nodes.
        /// This key must be 16-bytes Base64 encoded.  No encryption will be performed if 
        /// if this is <c>null</c> or empty.
        /// </summary>
        /// <remarks>
        /// <note>
        /// Suitable keys may be generated via <b>neon-conf generate-key</b>.
        /// </note>
        /// <note>
        /// Weave is somewhat less restrictive on the key requirements: it doesn't require
        /// Base64 encoding and there is no length restriction.  Neon clusters enforce
        /// Base64 to make keys easy to pass as command line arguments and is standardizing
        /// on 16 bytes for consistency.
        /// </note>
        /// </remarks>
        [JsonProperty(Required = Required.Default, DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate)]
        [DefaultValue(null)]
        public string EncryptionKey { get; set; } = null;

        /// <summary>
        /// The Weave proxy API port.
        /// </summary>
        [JsonIgnore]
        public int ProxyPort
        {
            get { return NetworkPort.WeaveProxy; }
        }

        /// <summary>
        /// Validates the options definition and also ensures that all <c>null</c> properties are
        /// initialized to their default values.
        /// </summary>
        /// <param name="clusterDefinition">The cluster definition.</param>
        /// <exception cref="ClusterDefinitionException">Thrown if the definition is not valid.</exception>
        [Pure]
        public void Validate(ClusterDefinition clusterDefinition)
        {
            Covenant.Requires<ArgumentNullException>(clusterDefinition != null);

            Version version;

            try
            {
                if (string.IsNullOrWhiteSpace(Version))
                {
                    throw new Exception();
                }

                version = new Version(Version);
            }
            catch
            {
                throw new ClusterDefinitionException($"Invalid version [{nameof(Version)}={Version}].");
            }

            if (version < new Version("1.5.0"))
            {
                throw new ClusterDefinitionException($"Weave network version [{nameof(Version)}={Version}] is too old.  This must be >= [1.5.0].");
            }

            ClusterDefinition.VerifyEncryptionKey(EncryptionKey);
        }

        /// <summary>
        /// Returns a deep clone of the current instance.
        /// </summary>
        /// <returns>The clone.</returns>
        public WeaveNetworkOptions Clone()
        {
            return new WeaveNetworkOptions()
            {
                Version       = this.Version,
                Enabled       = this.Enabled,
                Name          = this.Name,
                EncryptionKey = this.EncryptionKey
            };
        }
    }
}
