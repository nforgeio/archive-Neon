﻿//-----------------------------------------------------------------------------
// FILE:	    EnvironmentType.cs
// CONTRIBUTOR: Jeff Lill
// COPYRIGHT:	Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.

using System;

namespace Neon.Stack.Management
{
    /// <summary>
    /// Enumerates the types of cluster operating environments.
    /// </summary>
    public enum EnvironmentType
    {
        /// <summary>
        /// Unspecified.
        /// </summary>
        Unknown = 0,

        /// <summary>
        /// Development environment.
        /// </summary>
        Development,

        /// <summary>
        /// Test environment.
        /// </summary>
        Test,

        /// <summary>
        /// Staging environment.
        /// </summary>
        Stage,

        /// <summary>
        /// Production environment.
        /// </summary>
        Production
    }
}
