﻿//-----------------------------------------------------------------------------
// FILE:	    VaultOptions.cs
// CONTRIBUTOR: Jeff Lill
// COPYRIGHT:	Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.Contracts;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;

using Neon.Stack.Common;
using Neon.Stack.Net;

namespace Neon.Stack.Management
{
    /// <summary>
    /// Describes the HashiCorp Vault options for a Neon Cluster.
    /// </summary>
    public class VaultOptions
    {
        private const bool      defaultEnabled     = false;
        private const string    defaultVersion     = "0.5.2";
        private const bool      defaultTlsDisabled = true;

        /// <summary>
        /// Default constructor.
        /// </summary>
        public VaultOptions()
        {
        }

        /// <summary>
        /// Indicates whether Vault is to be enabled on the cluster.
        /// </summary>
        [JsonProperty(Required = Required.Default, DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate)]
        [DefaultValue(defaultEnabled)]
        public bool Enabled { get; set; } = defaultEnabled;

        /// <summary>
        /// The version of the <b>neoncloud/vault</b> image to be installed.  
        /// This defaults to a reasonable recent version.
        /// </summary>
        /// <remarks>
        /// <note>
        /// <para>
        /// Only versions of Vault that have been uploaded to AWS S3 like the
        /// example below below are supported.
        /// </para>
        /// <para>
        /// https://s3-us-west-2.amazonaws.com/neon-research/images/vault-0.5.2.zip
        /// </para>
        /// </note>
        /// </remarks>
        [JsonProperty(Required = Required.Default, DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate)]
        [DefaultValue(defaultVersion)]
        public string Version { get; set; } = defaultVersion;

        /// <summary>
        /// Specifies whether TLS encryption and authtication should be disabled.
        /// This is enabled by default.
        /// </summary>
        [JsonProperty(Required = Required.Default, DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate)]
        [DefaultValue(defaultTlsDisabled)]
        public bool TlsDisabled { get; set; } = defaultTlsDisabled;

        /// <summary>
        /// Returns the Vault port.
        /// </summary>
        [JsonIgnore]
        public int Port
        {
            get { return NetworkPort.Vault; }
        }

        /// <summary>
        /// Validates the options definition and also ensures that all <c>null</c> properties are
        /// initialized to their default values.
        /// </summary>
        /// <param name="clusterDefinition">The cluster definition.</param>
        /// <exception cref="ClusterDefinitionException">Thrown if the definition is not valid.</exception>
        [Pure]
        public void Validate(ClusterDefinition clusterDefinition)
        {
            Covenant.Requires<ArgumentNullException>(clusterDefinition != null);

            if (!Enabled)
            {
                return;
            }

            if (string.IsNullOrWhiteSpace(Version))
            {
                throw new ClusterDefinitionException($"Invalid version [{nameof(Version)}={Version}].");
            }

            if (!clusterDefinition.Consul.Enabled)
            {
                throw new ClusterDefinitionException("[Consul] must be enabled for [Vault]..");
            }
        }

        /// <summary>
        /// Returns a deep clone of the current instance.
        /// </summary>
        /// <returns>The clone.</returns>
        public VaultOptions Clone()
        {
            return new VaultOptions()
            {
                Enabled     = this.Enabled,
                Version     = this.Version,
                TlsDisabled = this.TlsDisabled
            };
        }
    }
}
