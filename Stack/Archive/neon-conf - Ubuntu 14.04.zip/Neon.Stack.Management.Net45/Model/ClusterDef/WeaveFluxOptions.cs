﻿//-----------------------------------------------------------------------------
// FILE:	    WeaveFluxOptions.cs
// CONTRIBUTOR: Jeff Lill
// COPYRIGHT:	Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.Contracts;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;

using Neon.Stack.Common;

namespace Neon.Stack.Management
{
    /// <summary>
    /// Describes the Weave Flux options for a Neon Cluster.
    /// </summary>
    public class WeaveFluxOptions
    {
        private const bool      defaultEnabled = false;
        private const string    defaultVersion = "0.2";

        /// <summary>
        /// Default constructor.
        /// </summary>
        public WeaveFluxOptions()
        {
        }

        /// <summary>
        /// Indicates whether Weave overlay networking is to be enabled.
        /// This defaults to <c>true</c>.
        /// </summary>
        [JsonProperty(Required = Required.Default, DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate)]
        [DefaultValue(defaultEnabled)]
        public bool Enabled { get; set; } = defaultEnabled;

        /// <summary>
        /// The version of Weave Flux to be installed.  This defaults to a reasonable
        /// recent version.
        /// </summary>
        [JsonProperty(Required = Required.Default, DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate)]
        [DefaultValue(defaultVersion)]
        public string Version { get; set; } = defaultVersion;

        /// <summary>
        /// The version of Weave FluxCtl to be installed.  This defaults to the
        /// same <see cref="Version"/> specified for the Flux deamon but may
        /// be overridden if necessary.
        /// </summary>
        [JsonProperty(Required = Required.Default, DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate)]
        [DefaultValue(null)]
        public string CtlVersion { get; set; } = null;

        /// <summary>
        /// Validates the options definition and also ensures that all <c>null</c> properties are
        /// initialized to their default values.
        /// </summary>
        /// <param name="clusterDefinition">The cluster definition.</param>
        /// <exception cref="ClusterDefinitionException">Thrown if the definition is not valid.</exception>
        [Pure]
        public void Validate(ClusterDefinition clusterDefinition)
        {
            Covenant.Requires<ArgumentNullException>(clusterDefinition != null);

            if (Enabled && !clusterDefinition.Weave.Network.Enabled)
            {
                throw new ClusterDefinitionException("[Weave Flux] requires that [Weave Network] be enabled for the cluster.");
            }

            if (Enabled && !clusterDefinition.Etcd.Enabled)
            {
                throw new ClusterDefinitionException("[Weave Flux] requires that [Etcd] be enabled for the cluster.");
            }

            if (string.IsNullOrWhiteSpace(Version))
            {
                throw new ClusterDefinitionException($"Invalid version [{nameof(Version)}={Version}].");
            }

            if (string.IsNullOrWhiteSpace(CtlVersion))
            {
                CtlVersion = Version;
            }
        }

        /// <summary>
        /// Returns a deep clone of the current instance.
        /// </summary>
        /// <returns>The clone.</returns>
        public WeaveFluxOptions Clone()
        {
            return new WeaveFluxOptions()
            {
                Version = this.Version,
                Enabled = this.Enabled
            };
        }
    }
}
