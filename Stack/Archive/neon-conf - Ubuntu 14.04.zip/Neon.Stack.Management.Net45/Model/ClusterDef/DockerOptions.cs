﻿//-----------------------------------------------------------------------------
// FILE:	    DockerOptions.cs
// CONTRIBUTOR: Jeff Lill
// COPYRIGHT:	Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.Contracts;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;

using Neon.Stack.Common;
using Neon.Stack.Net;

namespace Neon.Stack.Management
{
    /// <summary>
    /// Describes the Docker options for a Neon Cluster.
    /// </summary>
    public class DockerOptions
    {
        private const string defaultComposeVersion = "1.7.0";

        /// <summary>
        /// Default constructor.
        /// </summary>
        public DockerOptions()
        {
        }

        /// <summary>
        /// Returns the Docker API port.
        /// </summary>
        [JsonIgnore]
        public int Port
        {
            get { return NetworkPort.Docker; }
        }

        /// <summary>
        /// The version Docker Comnpose to be installed.  This defaults to a reasonable
        /// recent version.
        /// </summary>
        [JsonProperty(Required = Required.Default, DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate)]
        [DefaultValue(defaultComposeVersion)]
        public string ComposeVersion { get; set; } = defaultComposeVersion;

        /// <summary>
        /// Validates the options definition and also ensures that all <c>null</c> properties are
        /// initialized to their default values.
        /// </summary>
        /// <param name="clusterDefinition">The cluster definition.</param>
        /// <exception cref="ClusterDefinitionException">Thrown if the definition is not valid.</exception>
        [Pure]
        public void Validate(ClusterDefinition clusterDefinition)
        {
            Covenant.Requires<ArgumentNullException>(clusterDefinition != null);

            if (string.IsNullOrWhiteSpace(ComposeVersion))
            {
                ComposeVersion = defaultComposeVersion;
            }
        }

        /// <summary>
        /// Returns a deep clone of the current instance.
        /// </summary>
        /// <returns>The clone.</returns>
        public DockerOptions Clone()
        {
            return new DockerOptions()
            {
                ComposeVersion = this.ComposeVersion
            };
        }
    }
}
