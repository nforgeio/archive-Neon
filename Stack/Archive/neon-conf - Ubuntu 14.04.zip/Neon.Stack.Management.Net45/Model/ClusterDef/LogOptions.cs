﻿//-----------------------------------------------------------------------------
// FILE:	    LogOptions.cs
// CONTRIBUTOR: Jeff Lill
// COPYRIGHT:	Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.Contracts;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;

using Neon.Stack.Common;
using Neon.Stack.Net;

namespace Neon.Stack.Management
{
    /// <summary>
    /// Describes the logging options for a Neon Cluster.
    /// </summary>
    /// <remarks>
    /// <para>
    /// Neon Clusters support sophisticated logging out-of-the-box using the Treasure Data
    /// <b>td-agent</b> and <b>ElasticSearch/Logstash/Kibana ELK)</b>.  The basic idea is that 
    /// log events  are captured on the cluster nodes using Fluentd and then these events are 
    /// forwarded to cluster level <b>td-agent</b> aggregators to be then forwarded on to 
    /// archive/dashboard solutions such as the built-in ElasticSearch/Kabana one and or to 
    /// other solutions such as Splunk, Treasure Data, etc.
    /// </para>
    /// <para>
    /// Once a cluster is provisioned, you can deploy the <b>Neon ELK</b> log repository and dashboard
    /// as cluster containers or provision another solution.  Neon ELK is simply a deployment of
    /// the worldclass ElasticSearch/Logstash/Kibana stack (although we don't actually use Logstash).
    /// </para>
    /// <para>
    /// Each cluster deploys three types of <b>td-agent</b> instances:
    /// </para>
    /// <list type="table">
    /// <item>
    ///     <term><b>td-agent-os</b></term>
    ///     <description>
    ///     This runs as a daemon on the host operating system of each cluster node.  It is
    ///     reponsible for capturing host level logs and system statistics, typically by examining
    ///     the contents of the [/var/logs/*] folders.  Log events are then forwarded to the
    ///     <b>td-agent-node</b> instance running as a Docker container.
    ///     </description>
    ///     <term><b>td-agent-node</b></term>
    ///     <description>
    ///     <para>
    ///     This runs as a Docker container on on every node.  This container is reponsible for
    ///     forwarding any events it receives to downstream aggregators listening at
    ///     <see cref="CollectorAddress"/>.
    ///     </para>
    ///     <para>
    ///     The local Docker daemon will be configured to forward logs to this container
    ///     as will the local <b>td-agent-os</b> instance.
    ///     </para>
    ///     </description>
    ///     <term><b>neon.log-collector</b></term>
    ///     <description>
    ///     <para>
    ///     This runs as a service on the local Swarm cluster.  It is resonsible for aggregating
    ///     event forwarded by the <b>td-agent-node</b> instances running on each cluster 
    ///     node and then forwarding them on to a <b>Neon ELK</b> instance running in the local
    ///     cluster and/or on to other logging aggregators.
    ///     </para>
    ///     <note>
    ///     This service will be load balanced via the Weave network DNS using the
    ///     <b>log-collector.neon.cluster.local</b> host name.
    ///     </note>
    ///     </description>
    /// </item>
    /// </list>
    /// </remarks>
    public class LogOptions
    {
        private const bool      defaultEnabled               = true;
        private const string    defaultTDAgentOSVersion      = "2";
        private const string    defaultTDAgentNodeImage      = "neoncloud/td-agent:latest";
        private const string    defaultTDAgentCollectorImage = "neoncloud/td-agent:latest";
        private const string    defaultElasticsearchImage    = "neoncloud/elasticsearch:latest";
        private const string    defaultCollectorAddress      = "log-collector.neon.cluster.local:24224";
        private const int       defaultEsInstances           = 1;
        private const int       defaultEsShards              = 8;
        private const int       defaultEsReplicas            = 1;
        private const int       defaultKibanaInstances       = 1;
        private const int       defaultCollectorInstances    = 1;
        
        /// <summary>
        /// Default constructor.
        /// </summary>
        public LogOptions()
        {
        }

        /// <summary>
        /// Indicates whether logging is to be enabled on the cluster.
        /// This defaults to <c>true</c>.
        /// </summary>
        [JsonProperty(Required = Required.Default, DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate)]
        [DefaultValue(defaultEnabled)]
        public bool Enabled { get; set; } = defaultEnabled;

        /// <summary>
        /// The version of <b>td-agent</b> to be installed installed on cluster manager and worker hosts.
        /// This defaults to a reasonable recent version.
        /// </summary>
        [JsonProperty(Required = Required.Default, DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate)]
        [DefaultValue(defaultTDAgentOSVersion)]
        public string TDAgentVersion { get; set; } = defaultTDAgentOSVersion;

        /// <summary>
        /// Identifies the <b>td-agent</b> container image to be run locally on each manager and worker node.  This container
        /// acts as the entry point to the cluster's log aggregation pipeline.  This defaults to <b>neoncloud/td-agent:latest</b>.
        /// </summary>
        [JsonProperty(Required = Required.Default, DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate)]
        [DefaultValue(defaultTDAgentNodeImage)]
        public string TDAgentNodeImage { get; set; } = defaultTDAgentNodeImage;

        /// <summary>
        /// Identifies the <b>td-agent</b> container image to be run on the cluster, acting as the downstream event 
        /// aggregator for all of the cluster nodes.  This defaults to <b>neoncloud/td-agent:latest</b>.
        /// </summary>
        [JsonProperty(Required = Required.Default, DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate)]
        [DefaultValue(defaultTDAgentCollectorImage)]
        public string TDAgentCollectorImage { get; set; } = defaultTDAgentCollectorImage;

        /// <summary>
        /// Identifies the <b>Elasticsearch</b> container image to be deployed on the cluster to persist
        /// cluster log events.  This defaults to <b>neoncloud/elasticsearch:latest</b>.
        /// </summary>
        [JsonProperty(Required = Required.Default, DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate)]
        [DefaultValue(defaultElasticsearchImage)]
        public string ElasticsearchImage { get; set; } = defaultElasticsearchImage;

        /// <summary>
        /// Returns the IP address the [td-agent-node] will listen on.
        /// </summary>
        [JsonIgnore]
        public string TDAgentNodeBindIP
        {
            get { return "127.0.0.1"; }
        }

        /// <summary>
        /// Returns the IP address the [td-agent-os] will listen on.
        /// </summary>
        [JsonIgnore]
        public string TDAgentOsBindIP
        {
            get { return "127.0.0.2"; }
        }

        /// <summary>
        /// The port where <b>td-agent</b>s listens for log events sent 
        /// via TCP or UDP.
        /// </summary>
        [JsonIgnore]
        public int TDAgentForwardPort
        {
            get { return NetworkPort.TDAgentForward; }
        }

        /// <summary>
        /// The port HTTP or UDP.
        /// </summary>
        [JsonIgnore]
        public int TDAgentHttpPort
        {
            get { return NetworkPort.TDAgentHttp; }
        }

        /// <summary>
        /// <para>
        /// Describes where the <b>td-agent-node</b> image should forward received log events.  This
        /// is expressed as <b><i>host</i>:<i>port</i></b>, where <b><i>host</i></b> is the
        /// DNS host name or IP address and <b><i>port</i></b> is the TCP/UDP port number.
        /// </para>
        /// <para>
        /// This defaults to <b>log-collector.neon.cluster.local:24224</b>.
        /// </para>
        /// </summary>
        [JsonProperty(Required = Required.Default, DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate)]
        [DefaultValue(defaultCollectorAddress)]
        public string CollectorAddress { get; set; } = defaultCollectorAddress;

        /// <summary>
        /// The number of Elasticsearch instances to be deployed to store the
        /// cluster logs.  This defaults to <b>1</b>.
        /// </summary>
        [JsonProperty(Required = Required.Default, DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate)]
        [DefaultValue(defaultEsInstances)]
        public int EsInstances { get; set; } = defaultEsInstances;

        /// <summary>
        /// The number of Elasticsearch shards to be configured.  This essentially specifies
        /// the ultimate scalablity of the logging cluster.  This defaults to <b>8</b>.
        /// </summary>
        [JsonProperty(Required = Required.Default, DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate)]
        [DefaultValue(defaultEsShards)]
        public int EsShards { get; set; } = defaultEsShards;

        /// <summary>
        /// The number of times Elasticsearch will replicate data for
        /// fault tolerance.  This defaults to <b>1</b>.
        /// </summary>
        [JsonProperty(Required = Required.Default, DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate)]
        [DefaultValue(defaultEsReplicas)]
        public int EsReplicas { get; set; } = defaultEsReplicas;

        /// <summary>
        /// This is used to customize the placement of the Elasticsearch containers 
        /// on nodes in your cluster.
        /// </summary>
        /// <remarks>
        /// <para>
        /// You may specify zero or more placement constraints using standard 
        /// Docker Swarm style expressions referencing built-in or custom node labels.
        /// </para>
        /// <para>
        /// This defaults to an empty list, which indicates that NeonCloud will
        /// choose where to locate the containers.
        /// </para>
        /// </remarks>
        public List<string> EsConstraints { get; set; } = new List<string>();

        /// <summary>
        /// The number of TD-Agent based log collector instances to be deployed to receive 
        /// log events from host nodes, perform any transformations and then persist
        /// the events to the Elasticsearch instances.  This defaults to <b>1</b>.
        /// </summary>
        [JsonProperty(Required = Required.Default, DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate)]
        [DefaultValue(defaultCollectorInstances)]
        public int CollectorInstances { get; set; } = defaultCollectorInstances;

        /// <summary>
        /// This is used to customize the placement of the TD-AGENT log event
        /// collector containers on nodes in your cluster.
        /// </summary>
        /// <remarks>
        /// <para>
        /// You may specify zero or more placement constraints using standard 
        /// Docker Swarm style expressions referencing built-in or custom node labels.
        /// </para>
        /// <para>
        /// This defaults to an empty list, which indicates that NeonCloud will
        /// choose where to locate the containers.
        /// </para>
        /// </remarks>
        public List<string> CollectorConstraints { get; set; } = new List<string>();

        /// <summary>
        /// The number Kibana dashboard instances to be deployed.  This defaults to <b>1</b>.
        /// </summary>
        [JsonProperty(Required = Required.Default, DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate)]
        [DefaultValue(defaultKibanaInstances)]
        public int KibanaInstances { get; set; } = defaultKibanaInstances;

        /// <summary>
        /// This is used to customize the placement of the Kibana containers 
        /// on nodes in your cluster.
        /// </summary>
        /// <remarks>
        /// <para>
        /// You may specify zero or more placement constraints using standard 
        /// Docker Swarm style expressions referencing built-in or custom node labels.
        /// </para>
        /// <para>
        /// This defaults to an empty list, which indicates that NeonCloud will
        /// choose where to locate the containers.
        /// </para>
        /// </remarks>
        public List<string> KibanaConstraints { get; set; } = new List<string>();

        /// <summary>
        /// Validates the options definition and also ensures that all <c>null</c> properties are
        /// initialized to their default values.
        /// </summary>
        /// <param name="clusterDefinition">The cluster definition.</param>
        /// <exception cref="ClusterDefinitionException">Thrown if the definition is not valid.</exception>
        [Pure]
        public void Validate(ClusterDefinition clusterDefinition)
        {
            Covenant.Requires<ArgumentNullException>(clusterDefinition != null);

            if (!Enabled)
            {
                return;
            }

            if (!clusterDefinition.Consul.Enabled)
            {
                throw new ClusterDefinitionException("To enable cluster logging, you also need to enable Consul.");
            }

            if (string.IsNullOrWhiteSpace(TDAgentVersion))
            {
                throw new ClusterDefinitionException($"Invalid [{nameof(TDAgentVersion)}={TDAgentVersion}].");
            }

            if (string.IsNullOrWhiteSpace(TDAgentNodeImage))
            {
                throw new ClusterDefinitionException($"Invalid [{nameof(TDAgentNodeImage)}={TDAgentNodeImage}].");
            }

            if (string.IsNullOrWhiteSpace(TDAgentCollectorImage))
            {
                throw new ClusterDefinitionException($"Invalid [{nameof(TDAgentCollectorImage)}={TDAgentCollectorImage}].");
            }

            if (string.IsNullOrWhiteSpace(CollectorAddress))
            {
                throw new ClusterDefinitionException($"Invalid [{nameof(CollectorAddress)}={CollectorAddress}].");
            }

            if (EsInstances <= 0)
            {
                throw new ClusterDefinitionException($"Invalid [{nameof(EsInstances)}={EsInstances}]: This must be >= 1.");
            }

            if (EsShards <= 0)
            {
                throw new ClusterDefinitionException($"Invalid [{nameof(EsShards)}={EsShards}]: This must be >= 1.");
            }

            if (EsReplicas <= 0)
            {
                throw new ClusterDefinitionException($"Invalid [{nameof(EsReplicas)}={EsReplicas}]: This must be >= 1.");
            }

            if (CollectorInstances <= 0)
            {
                throw new ClusterDefinitionException($"Invalid [{nameof(CollectorInstances)}={CollectorInstances}]: This must be >= 1.");
            }

            // Verify that there are enough nodes satisfying the Elasticsearch and TD-Agent collector constraints.

            var nodes = clusterDefinition.FilterWorkers(EsConstraints).ToArray();

            var nodeCount = clusterDefinition.FilterWorkers(EsConstraints).Count();

            if (nodeCount < EsInstances)
            {
                throw new ClusterDefinitionException($"Unable to deploy [{EsInstances}] Elasticsearch containers.  Only [{nodeCount}] node(s) satisfy the constraints.");
            }

            nodeCount = clusterDefinition.FilterWorkers(CollectorConstraints).Count();

            if (nodeCount < CollectorInstances)
            {
                throw new ClusterDefinitionException($"Unable to deploy [{CollectorInstances}] TD-Agent containers.  Only [{nodeCount}] node(s) satisfy the constraints.");
            }
        }

        /// <summary>
        /// Returns a deep clone of the current instance.
        /// </summary>
        /// <returns>The clone.</returns>
        public LogOptions Clone()
        {
            return new LogOptions()
            {
                Enabled              = this.Enabled,
                TDAgentVersion       = this.TDAgentVersion,
                TDAgentCollectorImage  = this.TDAgentCollectorImage,
                TDAgentNodeImage     = this.TDAgentNodeImage,
                CollectorAddress     = this.CollectorAddress,
                EsInstances         = this.EsInstances,
                EsShards             = this.EsShards,
                EsReplicas           = this.EsReplicas,
                EsConstraints        = new List<string>(this.EsConstraints),
                CollectorInstances  = this.CollectorInstances,
                CollectorConstraints = new List<string>(this.CollectorConstraints)
            };
        }
    }
}
