﻿//-----------------------------------------------------------------------------
// FILE:	    NetworkOptions.cs
// CONTRIBUTOR: Jeff Lill
// COPYRIGHT:	Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.Contracts;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;

using Neon.Stack.Common;
using Neon.Stack.Net;

namespace Neon.Stack.Management
{
    /// <summary>
    /// Describes the Docker networking options for a Neon Cluster.
    /// </summary>
    public class NetworkOptions
    {
        private const string defaultSubnet = "10.64.0.0/16";

        /// <summary>
        /// Returns the name of the default Neon Cluster overlay network.
        /// </summary>
        [JsonIgnore]
        public string Name { get; private set; } = "cluster.overlay";

        /// <summary>
        /// Returns the IP address for the DNS server Docker provisions for overlay networks.
        /// </summary>
        [JsonIgnore]
        public string Dns { get; private set; } = "127.0.0.11";     // This appears to be hardcoded by Docker.

        /// <summary>
        /// The DNS label used when containers and services are registered with the Docker
        /// or Weave network DNS.  This returns <b>cluster</b> which means that a container 
        /// named <b>foo</b> will be registered as <b>foo.cluster.local</b>.
        /// </summary>
        [JsonIgnore]
        public string DomainLabel { get; private set; } = ClusterDefinition.DefaultDomainLabel;

        /// <summary>
        /// Specifies the subnet upon which the Docker or Weave overlay network will allocate 
        /// IP addresses to Docker containers in CIDR notation.
        /// </summary>
        /// <remarks>
        /// <para>
        /// Overlay networks manages the IP addresses within the subnet specified and 
        /// automatically assigns address to Docker containers as they are started and
        /// returns addresses back to the pool as they are stopped.  This is specified 
        /// in CIDR notation as described here:
        /// </para>
        /// <para>
        /// https://en.wikipedia.org/wiki/Classless_Inter-Domain_Routing#CIDR_notation
        /// </para>
        /// <para>
        /// This defaults to <b>10.64.0.0/16</b> which provides a pool of 64K addresses.
        /// </para>
        /// </remarks>
        [JsonProperty(Required = Required.Default, DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate)]
        [DefaultValue(defaultSubnet)]
        public string Subnet { get; set; } = defaultSubnet;

        /// <summary>
        /// Validates the options definition and also ensures that all <c>null</c> properties are
        /// initialized to their default values.
        /// </summary>
        /// <param name="clusterDefinition">The cluster definition.</param>
        /// <exception cref="ClusterDefinitionException">Thrown if the definition is not valid.</exception>
        [Pure]
        public void Validate(ClusterDefinition clusterDefinition)
        {
            Covenant.Requires<ArgumentNullException>(clusterDefinition != null);

            NetworkCidr cidr;

            if (string.IsNullOrWhiteSpace(Subnet))
            {
                Subnet = defaultSubnet;
            }
            else if (!NetworkCidr.TryParse(Subnet, out cidr))
            {
                throw new ClusterDefinitionException($"Network.Subnet [{nameof(Subnet)}={Subnet}] is not valid.");
            }
        }

        /// <summary>
        /// Returns a deep clone of the current instance.
        /// </summary>
        /// <returns>The clone.</returns>
        public NetworkOptions Clone()
        {
            return new NetworkOptions()
            {
                Name        = this.Name,
                Dns         = this.Dns,
                DomainLabel = this.DomainLabel,
                Subnet      = this.Subnet,
            };
        }

    }
}
