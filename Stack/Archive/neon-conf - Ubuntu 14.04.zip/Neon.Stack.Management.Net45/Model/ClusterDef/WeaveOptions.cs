﻿//-----------------------------------------------------------------------------
// FILE:	    WeaveOptions.cs
// CONTRIBUTOR: Jeff Lill
// COPYRIGHT:	Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.Contracts;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;

using Neon.Stack.Common;

namespace Neon.Stack.Management
{
    /// <summary>
    /// Describes the Weave.works related options for a Neon Cluster.
    /// </summary>
    public class WeaveOptions
    {
        /// <summary>
        /// Default constructor.
        /// </summary>
        public WeaveOptions()
        {
        }

        /// <summary>
        /// The Weave overlay networking options.
        /// </summary>
        [JsonProperty(Required = Required.Default, DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate)]
        [DefaultValue(null)]
        public WeaveNetworkOptions Network { get; set; } = new WeaveNetworkOptions();

        /// <summary>
        /// The Weave Scope topology dashboard options.
        /// </summary>
        [JsonProperty(Required = Required.Default, DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate)]
        [DefaultValue(null)]
        public WeaveScopeOptions Scope { get; set; } = new WeaveScopeOptions();

        /// <summary>
        /// The Weave Flux load balancer options.
        /// </summary>
        [JsonProperty(Required = Required.Default, DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate)]
        [DefaultValue(null)]
        public WeaveFluxOptions Flux { get; set; } = new WeaveFluxOptions();

        /// <summary>
        /// Validates the options definition and also ensures that all <c>null</c> properties are
        /// initialized to their default values.
        /// </summary>
        /// <param name="clusterDefinition">The cluster definition.</param>
        /// <exception cref="ClusterDefinitionException">Thrown if the definition is not valid.</exception>
        [Pure]
        public void Validate(ClusterDefinition clusterDefinition)
        {
            Covenant.Requires<ArgumentNullException>(clusterDefinition != null);

            Network = Network ?? new WeaveNetworkOptions();
            Scope   = Scope ?? new WeaveScopeOptions();
            Flux    = Flux ?? new WeaveFluxOptions();

            Network.Validate(clusterDefinition);
            Scope.Validate(clusterDefinition);
            Flux.Validate(clusterDefinition);
        }

        /// <summary>
        /// Returns a deep clone of the current instance.
        /// </summary>
        /// <returns>The clone.</returns>
        public WeaveOptions Clone()
        {
            return new WeaveOptions()
            {
                Network = this.Network.Clone(),
                Scope   = this.Scope.Clone(),
                Flux    = this.Flux.Clone()
            };
        }
    }
}
