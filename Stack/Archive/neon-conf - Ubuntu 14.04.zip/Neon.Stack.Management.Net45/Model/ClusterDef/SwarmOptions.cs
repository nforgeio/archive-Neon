﻿//-----------------------------------------------------------------------------
// FILE:	    SwarmOptions.cs
// CONTRIBUTOR: Jeff Lill
// COPYRIGHT:	Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.Contracts;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;

using Neon.Stack.Common;
using Neon.Stack.Net;

namespace Neon.Stack.Management
{
    /// <summary>
    /// Describes the Docker Swarm related options for a Neon Cluster.
    /// </summary>
    public class SwarmOptions
    {
        private const string defaultVersion = "1.2.1-rc1";

        /// <summary>
        /// Default constructor.
        /// </summary>
        public SwarmOptions()
        {
        }

        /// <summary>
        /// The version of Docker Swarm to be installed.  This defaults to a reasonable
        /// recent version.
        /// </summary>
        [JsonProperty(Required = Required.Default, DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate)]
        [DefaultValue(defaultVersion)]
        public string Version { get; set; } = defaultVersion;

        /// <summary>
        /// Specifies the strategy Docker Swarm will use assign containers to nodes.  This
        /// defaults to <see cref="SchedulingStrategy.Spread"/>.
        /// </summary>
        /// <remarks>
        /// <para>
        /// Docker Swarm supports multiple basic strategies for deciding
        /// which node will be scheduled to run a container.  This is a cluster
        /// wide setting.  You can find more information at:
        /// </para>
        /// <para>
        /// The <see cref="SchedulingStrategy.Spread"/> and <see cref="SchedulingStrategy.Binpack"/>
        /// strategies select a node according to it's available CPU, its RAM, and the number of containers 
        /// it has.  The <see cref="SchedulingStrategy.Random"/> strategy uses no computation. It selects
        /// nodes at random and is primarily intended for debugging.
        /// </para>
        /// <para>
        /// https://docs.docker.com/swarm/scheduler/strategy/
        /// </para>
        /// </remarks>
        [JsonProperty(Required = Required.Default, DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate)]
        [DefaultValue(SchedulingStrategy.Spread)]
        public SchedulingStrategy Strategy { get; set; } = SchedulingStrategy.Spread;

        /// <summary>
        /// Advanced command line options for the Docker Swarm Manager service deployed to
        /// the manager nodes.
        /// </summary>
        /// <remarks>
        /// <note>
        /// This should be used only if you really know what you're doing.  Malformed
        /// or incorrect options may result in a failed cluster deployment.
        /// </note>
        /// <para>
        /// See the Swarm command line reference for more information:
        /// </para>
        /// <para>
        /// https://docs.docker.com/swarm/reference/manage/
        /// </para>
        /// </remarks>
        [JsonProperty(Required = Required.Default, DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate)]
        [DefaultValue(null)]
        public string AdvancedManager { get; set; }

        /// <summary>
        /// Advanced command line options for the Docker Swarm Agent service deployed to
        /// all nodes.
        /// </summary>
        /// <remarks>
        /// <note>
        /// This should be used only if you really know what you're doing.  Malformed
        /// or incorrect options may result in a failed cluster deployment.
        /// </note>
        /// <para>
        /// See the Swarm command line reference for more information:
        /// </para>
        /// <para>
        /// https://docs.docker.com/swarm/reference/join/
        /// </para>
        /// </remarks>
        [JsonProperty(Required = Required.Default, DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate)]
        [DefaultValue(null)]
        public string AdvancedAgent { get; set; }

        /// <summary>
        /// The Swarm Manager port.
        /// </summary>
        [JsonIgnore]
        public int Port
        {
            get { return NetworkPort.Swarm; }
        }

        /// <summary>
        /// Validates the options definition and also ensures that all <c>null</c> properties are
        /// initialized to their default values.
        /// </summary>
        /// <param name="clusterDefinition">The cluster definition.</param>
        /// <exception cref="ClusterDefinitionException">Thrown if the definition is not valid.</exception>
        [Pure]
        public void Validate(ClusterDefinition clusterDefinition)
        {
            Covenant.Requires<ArgumentNullException>(clusterDefinition != null);

            if (string.IsNullOrWhiteSpace(Version))
            {
                throw new ClusterDefinitionException($"Invalid version [{nameof(Version)}={Version}].");
            }
        }

        /// <summary>
        /// Returns a deep clone of the current instance.
        /// </summary>
        /// <returns>The clone.</returns>
        public SwarmOptions Clone()
        {
            return new SwarmOptions()
            {
                Version         = this.Version,
                Strategy        = this.Strategy,
                AdvancedManager = this.AdvancedManager,
                AdvancedAgent   = this.AdvancedAgent
            };
        }
    }
}
