﻿//-----------------------------------------------------------------------------
// FILE:	    ClusterStateQueryFlags.cs
// CONTRIBUTOR: Jeff Lill
// COPYRIGHT:	Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.

using System;

namespace Neon.Stack.Management
{
    /// <summary>
    /// Flags used to control what state <see cref="ClusterState.Query"/> attempts
    /// to capture from the cluster.
    /// </summary>
    [Flags]
    public enum ClusterStateQueryFlags
    {
        /// <summary>
        /// Queries each manager node.
        /// </summary>
        Managers = 0x00000001,

        /// <summary>
        /// Queries the Consul status for each manager node (this implies <see cref="Managers"/>).
        /// </summary>
        Consul = 0x00000002 | Managers,

        /// <summary>
        /// Queries the Swarm status for each manager node (this implies <see cref="Managers"/>).
        /// </summary>
        Swarm = 0x00000004 | Managers,

        /// <summary>
        /// Queries the status for all nodes.
        /// </summary>
        Nodes = 0x0001000 | Managers,

        /// <summary>
        /// Queries for all status.
        /// </summary>
        All = -1
    }
}
