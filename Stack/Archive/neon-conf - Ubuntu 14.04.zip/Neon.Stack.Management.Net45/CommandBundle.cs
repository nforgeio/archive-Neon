﻿//-----------------------------------------------------------------------------
// FILE:	    CommandBundle.cs
// CONTRIBUTOR: Jeff Lill
// COPYRIGHT:	Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using Neon.Stack.Common;

namespace Neon.Stack.Management
{
    /// <summary>
    /// Describes a collection of files to be uploaded to a Linux server
    /// along with the to be executed after the files have been unpacked.
    /// </summary>
    /// <remarks>
    /// <para>
    /// This class is intended for use with the <see cref="NodeManagementProxy{TMetadata}.RunCommand(CommandBundle)"/>
    /// and  <see cref="NodeManagementProxy{TMetadata}.SudoCommand(CommandBundle)"/> methods for situations where
    /// one or more files need to be uploaded to a NeonCloud host node and be used when a command is executed.
    /// </para>
    /// <para>
    /// A good example of this is performing a Docker Compose command on the cluster.  In this case, we need to
    /// upload the <b>docker-compose.yml</b> file along with any files it references and then we we'll want to
    /// execute the <b>docker-compose</b> CLI.
    /// </para>
    /// <para>
    /// To use this class, construct an instance passing the command and arguments to be executed.  The command be 
    /// an absolute reference to an executable in folders such as <b>/bin</b> or <b>/usr/local/bin</b>, an executable
    /// somewhere on the current PATH, or relative to the files unpacked from the bundle.  The current working directory
    /// will be set to the folder where the bundle was unpacked, so you can reference local executables like
    /// <b>./MyExecutable</b>.
    /// </para>
    /// <para>
    /// Once a bundle is constructed, you will add <see cref="CommandFile"/> instances specifying the
    /// file data you want to include.  These include the relative path to the file to be uploaded as well
    /// as its text or binary data.  You may also indicate whether each file is to be marked as executable.
    /// </para>
    /// </remarks>
    public class CommandBundle : List<CommandFile>
    {
        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="command">The command.</param>
        /// <param name="args">The command arguments.</param>
        public CommandBundle(string command, params object[] args)
        {
            Covenant.Requires<ArgumentNullException>(!string.IsNullOrWhiteSpace(command));
            Covenant.Requires<ArgumentNullException>(args != null);

            this.Command = command;
            this.Args    = args;
        }

        /// <summary>
        /// Returns the command to be executed after the bundle has been unpacked.
        /// </summary>
        public string Command { get; private set; }

        /// <summary>
        /// Returns the command arguments.
        /// </summary>
        public object[] Args { get; private set;}

        /// <summary>
        /// Verifies that the bundle is valid.
        /// </summary>
        /// <exception cref="InvalidOperationException">Thrown when the valid is not valid.</exception>
        public void Validate()
        {
            if (Count == 0)
            {
                throw new InvalidOperationException($"Invalid [{nameof(CommandBundle)}]: No files have been added.");
            }
        }
    }
}
