﻿//-----------------------------------------------------------------------------
// FILE:	    TargetOS.cs
// CONTRIBUTOR: Jeff Lill
// COPYRIGHT:	Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Neon.Stack.Common;
using Neon.Stack.Management;

namespace Neon.Stack.Management
{
    /// <summary>
    /// Enumerates the possible target operating systems.
    /// </summary>
    public enum TargetOS
    {
        /// <summary>
        /// Ubuntu 14.04 LTS.
        /// </summary>
        Ubuntu_14_04,

        /// <summary>
        /// Ubuntu 16.04 LTS.
        /// </summary>
        Ubuntu_16_04
    }
}
