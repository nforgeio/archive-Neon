﻿//-----------------------------------------------------------------------------
// FILE:	    RunOption.cs
// CONTRIBUTOR: Jeff Lill
// COPYRIGHT:	Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using Neon.Stack.Common;

using Renci.SshNet;

namespace Neon.Stack.Management
{
    /// <summary>
    /// Enumerates the possible options to use when executing a remote
    /// command on a <see cref="NodeManagementProxy{T}"/>.  These options may be 
    /// combined using the bitwise OR operator.
    /// </summary>
    [Flags]
    public enum RunOption
    {
        /// <summary>
        /// No options are set.
        /// </summary>
        None = 0x00000000,

        /// <summary>
        /// Puts the <see cref="NodeManagementProxy{T}"/> into the faulted state when the command
        /// returns a non-zero exit code.
        /// </summary>
        FaultOnError = 0x00000001,

        /// <summary>
        /// Runs the command even if the <see cref="NodeManagementProxy{T}"/> is in the faulted state.
        /// </summary>
        RunWhenFaulted = 0x00000002,

        /// <summary>
        /// Logs command output only if the command returns a non-zero exit code.
        /// </summary>
        LogOnErrorOnly = 0x00000004,

        /// <summary>
        /// Logs the command standard output (standard error output is logged by default).
        /// </summary>
        LogOutput = 0x00000008,

        /// <summary>
        /// Ignore the <see cref="NodeManagementProxy{TMetadata}.RemotePath"/> property.
        /// </summary>
        IgnoreRemotePath = 0x00000010,
    }
}
