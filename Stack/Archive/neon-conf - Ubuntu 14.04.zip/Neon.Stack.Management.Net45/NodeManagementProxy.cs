﻿//-----------------------------------------------------------------------------
// FILE:	    NodeManagementProxy.cs
// CONTRIBUTOR: Jeff Lill
// COPYRIGHT:	Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using Neon.Stack.Common;
using Neon.Stack.IO;
using Neon.Stack.Net;
using Neon.Stack.Retry;
using Neon.Stack.Time;

using ICSharpCode.SharpZipLib.Zip;

using Renci.SshNet;

namespace Neon.Stack.Management
{
    /// <summary>
    /// Provides remote access to a Neon cluster host node for management purposes.
    /// </summary>
    /// <typeparam name="TMetadata">
    /// Defines the metadata type the application wishes to associate with the server.
    /// You may specify <c>object</c> when no additional metadata is required.
    /// </typeparam>
    /// <threadsafety instance="false"/>
    /// <remarks>
    /// <para>
    /// Construct an instance to connect to a specific cluster node.  You may specify
    /// <typeparamref name="TMetadata"/> to associate application specific information
    /// or state with the instance.
    /// </para>
    /// <para>
    /// This class includes methods to invoke Linux commands on the node as well as
    /// methods to issue Docker commands against the local node or the Swarm cluster.
    /// Methods are also provided to upload and download files.
    /// </para>
    /// <para>
    /// Call <see cref="Dispose()"/> or <see cref="Disconnect()"/> to close the connection.
    /// </para>
    /// </remarks>
    public class NodeManagementProxy<TMetadata> : IDisposable
        where TMetadata : class
    {
        //---------------------------------------------------------------------
        // Local types

        /// <summary>
        /// Describes the results of a Bash command executed on the remote server.
        /// </summary>
        public class CommandResult
        {
            /// <summary>
            /// Returns the original command line.
            /// </summary>
            public string Command { get; internal set; }

            /// <summary>
            /// Returns the command exit code.
            /// </summary>
            public int ExitCode { get; internal set; }

            /// <summary>
            /// Returns <c>true</c> if the command exit code was zero, 
            /// <b>false</b> otherwise.
            /// </summary>
            public bool Success
            {
                get { return ExitCode == 0; }
            }

            /// <summary>
            /// Indicates whether the command failed because the server is faulted.
            /// </summary>
            public bool ServerIsFaulted { get; internal set; }

            /// <summary>
            /// Returns the command output.
            /// </summary>
            public string Output { get; internal set; } = string.Empty;

            /// <summary>
            /// Creates a <see cref="TextReader"/> over the command's standard output.
            /// </summary>
            public TextReader OutputReader()
            {
                return new StringReader(Output);
            }

            /// <summary>
            /// Returns a brief message suitable for including in a related exception message.
            /// </summary>
            public string ErrorSummary
            {
                get
                {
                    if (Success)
                    {
                        return string.Empty;
                    }

                    return $"[exitcode={ExitCode}: {Command}";
                }
            }
        }

        //---------------------------------------------------------------------
        // Implementation

        private object          syncLock   = new object();
        private bool            isDisposed = false;
        private SshCredentials  credentials;
        private SshClient       sshClient;
        private ScpClient       scpClient;
        private TextWriter      logWriter;
        private bool            isReady;
        private string          status;
        private bool            hasUploadFolder;

        /// <summary>
        /// Constructs a <see cref="NodeManagementProxy{TMetadata}"/>.
        /// </summary>
        /// <param name="name">The display name for the server.</param>
        /// <param name="host">The IP address or FQDN for the server.</param>
        /// <param name="credentials">The credentials to be used for establishing SSH connections.</param>
        /// <param name="logWriter">The optional <see cref="TextWriter"/> where operation logs will be written.</param>
        /// <exception cref="ArgumentNullException">
        /// Thrown if <paramref name="name"/> or <paramref name="host"/> are <c>null</c> or empty or 
        /// if <paramref name="credentials"/> is <c>null</c>.
        /// </exception>
        public NodeManagementProxy(string name, string host, SshCredentials credentials, TextWriter logWriter = null)
        {
            Covenant.Requires<ArgumentNullException>(!string.IsNullOrEmpty(name));
            Covenant.Requires<ArgumentNullException>(!string.IsNullOrEmpty(host));
            Covenant.Requires<ArgumentNullException>(credentials != null);

            this.Name           = name;
            this.DnsName        = host;
            this.credentials    = credentials;
            this.logWriter      = logWriter;

            this.sshClient      = null;
            this.scpClient      = null;
            this.Datacenter     = "dc1";
            this.SshPort        = NetworkPort.SSH;
            this.Status         = string.Empty;
            this.IsReady        = false;
            this.ConnectTimeout = TimeSpan.FromSeconds(10);
            this.FileTimeout    = TimeSpan.FromSeconds(60);
        }

        /// <summary>
        /// Finalizer.
        /// </summary>
        ~NodeManagementProxy()
        {
            Dispose(false);
        }

        /// <summary>
        /// Releases all associated resources (e.g. any open server connections).
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Releases all associated resources (e.g. any open server connections).
        /// </summary>
        /// <param name="disposing">Pass <c>true</c> if we're disposing, <c>false</c> if we're finalizing.</param>
        protected virtual void Dispose(bool disposing)
        {
            lock (syncLock)
            {
                Disconnect();

                isDisposed = true;
            }
        }

        /// <summary>
        /// Closes any open connections to the Linux server but leaves open the
        /// opportunity to reconnect later.
        /// </summary>
        /// <remarks>
        /// <note>
        /// This is similar to what dispose does <see cref="Dispose()"/> but dispose does
        /// not allow reconnection.
        /// </note>
        /// <para>
        /// This command is useful situations where the client application may temporarily
        /// lose contact with the server if for example, when it is rebooted or the network
        /// configuration changes.
        /// </para>
        /// </remarks>
        public void Disconnect()
        {
            lock (syncLock)
            {
                if (sshClient != null)
                {
                    if (sshClient.IsConnected)
                    {
                        sshClient.Dispose();
                    }

                    sshClient = null;
                }

                if (scpClient != null)
                {
                    if (scpClient.IsConnected)
                    {
                        scpClient.Dispose();
                    }

                    scpClient = null;
                }
            }
        }

        /// <summary>
        /// Returns the display name for the server.
        /// </summary>
        public string Name { get; private set; }

        /// <summary>
        /// Returns the host IP address or FQDN of the server.
        /// </summary>
        public string DnsName { get; private set; }

        /// <summary>
        /// Identifies the datacenter server is located within.  This defaults to <b>dc1</b>.
        /// </summary>
        public string Datacenter { get; set; }

        /// <summary>
        /// The SSH port.  This defaults to <b>22</b>.
        /// </summary>
        public int SshPort { get; set; }

        /// <summary>
        /// The connection attempt timeout.  This defaults to <b>10</b> seconds.
        /// </summary>
        public TimeSpan ConnectTimeout { get; set; }

        /// <summary>
        /// The file operation timeout.  This defaults to <b>60</b> seconds.
        /// </summary>
        public TimeSpan FileTimeout { get; set; }

        /// <summary>
        /// The PATH to use on the remote server when executing commands in the
        /// session or <c>null</c>/empty to run commands without a path.  This
        /// defaults to the standard Linux path.
        /// </summary>
        /// <remarks>
        /// <note>
        /// When you modify this, be sure to use a colon (<b>:</b>) to separate 
        /// multiple directories as required.
        /// </note>
        /// </remarks>
        public string RemotePath { get; set; } = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin";

        /// <summary>
        /// The current server status.
        /// </summary>
        /// <remarks>
        /// <para>
        /// This property is intended to be used by management tools to indicate the state
        /// of the server for UX purposes.  This property will be set by some methods such
        /// as <see cref="WaitForBoot"/> but can also be set explicitly by tools when they
        /// have an operation in progress on the server.
        /// </para>
        /// <note>
        /// This will return <b>*** FAULTED ***</b> if the <see cref="IsFaulted"/>=<c>true</c>.
        /// </note>
        /// </remarks>
        public string Status
        {
            get
            {
                if (IsFaulted)
                {
                    return "*** FAULTED ***";
                }
                else
                {
                    return status;
                }
            }

            set
            {
                if (!string.IsNullOrEmpty(value) && value != status)
                {
                    if (IsFaulted)
                    {
                        LogLine($"*** STATUS[*FAULTED*]: {value}");
                    }
                    else
                    {
                        LogLine($"*** STATUS: {value}");
                    }
                }

                status = value;
            }
        }

        /// <summary>
        /// Indicates that the server is in a state where it is ready for the next operation
        /// to be initiated.
        /// </summary>
        /// <remarks>
        /// <note>
        /// This will always return <c>false</c> if the server has faulted (<see cref="IsFaulted"/>=<c>true</c>).
        /// </note>
        /// </remarks>
        public bool IsReady
        {
            get
            {
                return !IsFaulted && isReady;
            }

            set { isReady = value; }
        }

        /// <summary>
        /// Indicates that the server is in a faulted state because one or more operations
        /// have failed.
        /// </summary>
        public bool IsFaulted { get; private set; }

        /// <summary>
        /// Applications may use this to associate metadata with the instance.
        /// </summary>
        public TMetadata Metadata { get; set; }

        /// <summary>
        /// Shutdown the server.
        /// </summary>
        public void Shutdown()
        {
            Status = "shutting down...";
            SudoCommand("shutdown -h 0");
            Disconnect();

            // Give the server a chance to stop.

            Thread.Sleep(TimeSpan.FromSeconds(10));
            Status = "stopped";
        }

        /// <summary>
        /// Reboot the server.
        /// </summary>
        /// <param name="wait">Optionally wait for the server to reboot (defaults to <c>true</c>).</param>
        public void Reboot(bool wait = true)
        {
            Status = "rebooting...";
            SudoCommand("shutdown -r 0");
            Disconnect();

            // Give the server a chance to stop.

            Thread.Sleep(TimeSpan.FromSeconds(10));

            if (wait)
            {
                WaitForBoot();
            }
        }

        /// <summary>
        /// Writes text to the operation log.
        /// </summary>
        /// <param name="text">The text.</param>
        private void Log(string text)
        {
            if (logWriter != null)
            {
                logWriter.Write(text);
            }
        }

        /// <summary>
        /// Writes a line of text to the operation log.
        /// </summary>
        /// <param name="text">The text.</param>
        private void LogLine(string text)
        {
            if (logWriter != null)
            {
                logWriter.WriteLine(text);
                LogFlush();
            }
        }

        /// <summary>
        /// Flushes the log.
        /// </summary>
        private void LogFlush()
        {
            if (logWriter != null)
            {
                logWriter.Flush();
            }
        }

        /// <summary>
        /// Writes exception information to the operation log.
        /// </summary>
        /// <param name="message">The operation details.</param>
        /// <param name="e">The exception.</param>
        private void LogException(string message, Exception e)
        {
            LogLine($"*** ERROR: {message}: {NeonHelper.ExceptionError(e)}");
        }

        /// <summary>
        /// Puts the proxy into the faulted state.
        /// </summary>
        /// <param name="message">The optional message to be logged.</param>
        public void Fault(string message = null)
        {
            if (!string.IsNullOrEmpty(message))
            {
                Log("*** ERROR: " + message);
            }
            else
            {
                Log("*** ERROR: Unspecified FAULT");
            }

            IsFaulted = true;
        }

        /// <summary>
        /// Returns the connection information for SSH.NET.
        /// </summary>
        /// <returns>The connection information.</returns>
        private ConnectionInfo GetConnectionInfo()
        {
            return new ConnectionInfo(DnsName, SshPort, credentials.UserName, credentials.AuthenticationMethod)
            {
                Timeout = ConnectTimeout
            };
        }

        /// <summary>
        /// Waits for the server to boot by continuously attempting to establish an SSH session.
        /// </summary>
        /// <param name="timeout">The operation timeout (defaults to <b>5min</b>).</param>
        /// <returns>The tracking <see cref="Task"/>.</returns>
        /// <remarks>
        /// <para>
        /// The method will attempt to connect to the server every 10 seconds up to the specified
        /// timeout.  If it is unable to connect during this time, the exception thrown by the
        /// SSH client will be rethrown.
        /// </para>
        /// </remarks>
        public void WaitForBoot(TimeSpan? timeout = null)
        {
            Covenant.Requires<ArgumentException>(timeout != null ? timeout >= TimeSpan.Zero : true);

            var operationTimer = new PolledTimer(timeout ?? TimeSpan.FromMinutes(5));

            while (true)
            {
                var sshClient = new SshClient(GetConnectionInfo());

                try
                {
                    sshClient.Connect();
                    break;
                }
                catch (Exception e)
                {
                    if (sshClient.IsConnected)
                    {
                        sshClient.Dispose();
                    }

                    if (operationTimer.HasFired)
                    {
                        throw;
                    }

                    LogException($"*** WARNING: Wait for boot failed", e);

                    Thread.Sleep(TimeSpan.FromSeconds(5));
                }
            }

            Status = "online";
        }

        /// <summary>
        /// Ensures that an SSH connection has been established.
        /// </summary>
        private void EnsureSshConnection()
        {
            lock (syncLock)
            {
                if (isDisposed)
                {
                    throw new ObjectDisposedException(nameof(NodeManagementProxy<TMetadata>));
                }

                if (sshClient != null)
                {
                    return;
                }

                sshClient = new SshClient(GetConnectionInfo());

                try
                {
                    sshClient.Connect();
                }
                catch
                {
                    sshClient = null;
                    throw;
                }
            }
        }

        /// <summary>
        /// Ensures that an SCP connection has been established.
        /// </summary>
        private void EnsureScpConnection()
        {
            lock (syncLock)
            {
                if (isDisposed)
                {
                    throw new ObjectDisposedException(nameof(NodeManagementProxy<TMetadata>));
                }

                if (scpClient != null)
                {
                    return;
                }

                scpClient = new ScpClient(GetConnectionInfo())
                {
                    OperationTimeout = FileTimeout
                };

                try
                {
                    scpClient.Connect();
                }
                catch
                {
                    scpClient = null;
                    throw;
                }
            }
        }

        /// <summary>
        /// Returns the path to the user's home folder on the server.
        /// </summary>
        public string HomeFolderPath
        {
            get { return $"/home/{credentials.UserName}"; }
        }

        /// <summary>
        /// Returns the path to the users upload folder on the server.
        /// </summary>
        public string UploadFolderPath
        {
            get { return $"{HomeFolderPath}/upload"; }
        }

        /// <summary>
        /// Ensures that the [~/upload] folder exists on the server.
        /// </summary>
        private void EnsureUploadFolder()
        {
            if (!hasUploadFolder)
            {
                RunCommand($"mkdir -p {UploadFolderPath}", RunOption.LogOnErrorOnly | RunOption.IgnoreRemotePath);

                hasUploadFolder = true;
            }
        }

        /// <summary>
        /// Ensures that the configuration and setup folders required for a Neon host
        /// node exist and have the appropriate permissions.
        /// </summary>
        public void InitializeNeonFolders()
        {
            Status = "prepare: folders";

            SudoCommand($"mkdir -p {NodeHostFolder.ComposeFolder}", RunOption.LogOnErrorOnly);
            SudoCommand($"chmod 600 {NodeHostFolder.ComposeFolder}", RunOption.LogOnErrorOnly);

            SudoCommand($"mkdir -p {NodeHostFolder.ConfigFolder}", RunOption.LogOnErrorOnly);
            SudoCommand($"chmod 600 {NodeHostFolder.ConfigFolder}", RunOption.LogOnErrorOnly);

            SudoCommand($"mkdir -p {NodeHostFolder.SecretsFolder}", RunOption.LogOnErrorOnly);
            SudoCommand($"chmod 600 {NodeHostFolder.SecretsFolder}", RunOption.LogOnErrorOnly);

            SudoCommand($"mkdir -p {NodeHostFolder.StateFolder}", RunOption.LogOnErrorOnly);
            SudoCommand($"chmod 600 {NodeHostFolder.StateFolder}", RunOption.LogOnErrorOnly);

            SudoCommand($"mkdir -p {NodeHostFolder.SetupFolder}", RunOption.LogOnErrorOnly);
            SudoCommand($"chmod 600 {NodeHostFolder.SetupFolder}", RunOption.LogOnErrorOnly);
        }

        /// <summary>
        /// Downloads the a file from the Linux server and writes it out a stream.
        /// </summary>
        /// <param name="path">The source path of the file on the Linux server.</param>
        /// <param name="output">The output stream.</param>
        public void Download(string path, Stream output)
        {
            Covenant.Requires<ArgumentNullException>(!string.IsNullOrEmpty(path));
            Covenant.Requires<ArgumentNullException>(output != null);

            if (IsFaulted)
            {
                return;
            }

            LogLine($"*** Downloading: {path}");

            try
            {
                EnsureScpConnection();

                scpClient.Download(path, output);
            }
            catch (Exception e)
            {
                LogException("*** ERROR Downloading", e);
                throw;
            }
        }

        /// <summary>
        /// Uploads a binary stream to the Linux server and then writes it to the file system.
        /// </summary>
        /// <param name="input">The input stream.</param>
        /// <param name="path">The target path on the Linux server.</param>
        /// <param name="userPermissions">Indicates that the operation should be performed with user-level permissions.</param>
        /// <remarks>
        /// <note>
        /// <para>
        /// <b>Implementation Note:</b> The SSH.NET library we're using does not allow for
        /// files to be uploaded directly to arbitrary file system locations, even if the
        /// logged-in user has admin permissions.  The problem is that SSH.NET does not
        /// provide a way to use <b>sudo</b> to claim these higher permissions.
        /// </para>
        /// <para>
        /// The workaround is to create an upload folder in the user's home directory
        /// called <b>~/upload</b> and upload the file there first and then use SSH
        /// to move the file to its target location under sudo.
        /// </para>
        /// </note>
        /// </remarks>
        public void Upload(Stream input, string path, bool userPermissions = false)
        {
            Covenant.Requires<ArgumentNullException>(input != null);
            Covenant.Requires<ArgumentNullException>(!string.IsNullOrEmpty(path));

            if (IsFaulted)
            {
                return;
            }

            LogLine($"*** Uploading: {path}");

            try
            {
                EnsureUploadFolder();
                EnsureScpConnection();

                var uploadPath = $"{UploadFolderPath}/{LinuxPath.GetFileName(path)}";

                scpClient.Upload(input, uploadPath);

                if (userPermissions)
                {
                    RunCommand($"mkdir -p {LinuxPath.GetDirectoryName(path)}");
                    RunCommand($"mv {uploadPath} {path}", RunOption.LogOnErrorOnly);
                }
                else
                {
                    SudoCommand($"mkdir -p {LinuxPath.GetDirectoryName(path)}");
                    SudoCommand($"mv {uploadPath} {path}", RunOption.LogOnErrorOnly);
                }
            }
            catch (Exception e)
            {
                LogException("*** ERROR Uploading", e);
                throw;
            }
        }

        /// <summary>
        /// Uploads a text stream to the Linux server and then writes it to the file system,
        /// converting any CR-LF line endings to the Unix-style LF.
        /// </summary>
        /// <param name="textStream">The input stream.</param>
        /// <param name="path">The target path on the Linux server.</param>
        /// <param name="tabStop">Expands TABs into spaces when non-zero.</param>
        /// <param name="inputEncoding">The expected input text encoding (defaults to UTF-8).</param>
        /// <param name="outputEncoding">The expected output text encoding (defaults to UTF-8).</param>
        /// <remarks>
        /// <note>
        /// Any Unicode Byte Order Markers (BOM) at start of the input stream will be removed.
        /// </note>
        /// <note>
        /// <para>
        /// <b>Implementation Note:</b> The SSH.NET library we're using does not allow for
        /// files to be uploaded directly to arbitrary file system locations, even if the
        /// logged-in user has admin permissions.  The problem is that SSH.NET does not
        /// provide a way to use <b>sudo</b> to claim these higher permissions.
        /// </para>
        /// <para>
        /// The workaround is to create an upload folder in the user's home directory
        /// called <b>~/upload</b> and upload the file there first and then use SSH
        /// to move the file to its target location under sudo.
        /// </para>
        /// </note>
        /// </remarks>
        public void UploadText(Stream textStream, string path, int tabStop = 0, Encoding inputEncoding = null, Encoding outputEncoding = null)
        {
            Covenant.Requires<ArgumentNullException>(textStream != null);
            Covenant.Requires<ArgumentNullException>(!string.IsNullOrEmpty(path));

            inputEncoding  = inputEncoding ?? Encoding.UTF8;
            outputEncoding = outputEncoding ?? Encoding.UTF8;

            EnsureScpConnection();

            using (var reader = new StreamReader(textStream, inputEncoding))
            {
                using (var binaryStream = new MemoryStream(64 * 1024))
                {
                    foreach (var line in reader.Lines())
                    {
                        var convertedLine = line;

                        if (tabStop > 0)
                        {
                            convertedLine = NeonHelper.ExpandTabs(convertedLine, tabStop: tabStop);
                        }

                        binaryStream.Write(outputEncoding.GetBytes(convertedLine));
                        binaryStream.WriteByte((byte)'\n');
                    }

                    binaryStream.Position = 0;
                    Upload(binaryStream, path);
                }
            }
        }

        /// <summary>
        /// Uploads a Mono compatible executable to the server and generates a Bash script 
        /// that seamlessly executes it.
        /// </summary>
        /// <param name="sourcePath">The path to the source executable on the local machine.</param>
        /// <param name="targetName">The name for the target command on the server (without a folder path or file extension).</param>
        /// <param name="targetFolder">The optional target folder on the server (defaults to <b>/usr/local/bin</b>).</param>
        /// <param name="permissions">
        /// The Linux file permissions.  This defaults to <b>"700"</b> which grants only the current user
        /// read/write/execute permissions.
        /// </param>
        /// <remarks>
        /// <para>
        /// This method does the following:
        /// </para>
        /// <list type="number">
        /// <item>Uploads the executable to the target folder and names it <paramref name="targetName"/><b>.mono</b>.</item>
        /// <item>Creates a bash script in the target folder called <paramref name="targetName"/> that executes the Mono file.</item>
        /// <item>Makes the script executable.</item>
        /// </list>
        /// </remarks>
        public void UploadMonoExecutable(string sourcePath, string targetName, string targetFolder = "/usr/local/bin", string permissions = "700")
        {
            Covenant.Requires<ArgumentNullException>(!string.IsNullOrEmpty(sourcePath));
            Covenant.Requires<ArgumentNullException>(!string.IsNullOrEmpty(targetName));
            Covenant.Requires<ArgumentNullException>(!string.IsNullOrEmpty(targetFolder));

            using (var input = new FileStream(sourcePath, FileMode.Open, FileAccess.Read))
            {
                var binaryPath = LinuxPath.Combine(targetFolder, $"{targetName}.mono");

                Upload(input, binaryPath);

                // Set the permissions on the binary that match those we'll set
                // for the wrapping script, except stripping off the executable
                // flags.

                var binaryPermissions = new LinuxPermissions(permissions);

                binaryPermissions.OwnerExecute = false;
                binaryPermissions.GroupExecute = false;
                binaryPermissions.AllExecute   = false;

                SudoCommand($"chmod {binaryPermissions} {binaryPath}");
            }

            var scriptPath = LinuxPath.Combine(targetFolder, targetName);
            var script =
$@"#!/bin/bash
#------------------------------------------------------------------------------
# Seamlessly invokes the [{targetName}.mono] executable using the Mono
# runtime, passing any arguments along.

mono {scriptPath}.mono $@
";

            UploadText(new MemoryStream(Encoding.UTF8.GetBytes(script)), scriptPath, tabStop: 4);
            SudoCommand($"chmod {permissions} {scriptPath}");
        }

        /// <summary>
        /// Formats a Linux command and argument objects into a form suitable for passing
        /// to the <see cref="RunCommand(string, object[])"/> or <see cref="SudoCommand(string, object[])"/>
        /// methods.
        /// </summary>
        /// <param name="command">The command.</param>
        /// <param name="args">The arguments.</param>
        /// <returns>The formatted command string.</returns>
        /// <remarks>
        /// This method take care to convert empty arguments to "-" and to quote arguments with 
        /// embedded spaces.  The method also takes care to convert arguments with types like <c>bool</c> 
        /// into a Bash compatible canonical form.
        /// </remarks>
        private string FormatCommand(string command, params object[] args)
        {
            var sb = new StringBuilder();

            sb.Append(command);

            if (args != null)
            {
                foreach (var arg in args)
                {
                    sb.Append(' ');

                    if (arg == null)
                    {
                        sb.Append('-');
                    }
                    else if (arg is bool)
                    {
                        sb.Append((bool)arg ? "true" : "false");
                    }
                    else
                    {
                        var argString = arg.ToString();

                        if (string.IsNullOrWhiteSpace(argString))
                        {
                            argString = "-";
                        }
                        else if (argString.Contains(' '))
                        {
                            argString = "\"" + argString + "\"";
                        }

                        sb.Append(argString);
                    }
                }
            }

            return sb.ToString();
        }

        /// <summary>
        /// Uploads a command bundle to the server and unpacks it to a temporary folder
        /// in the user's home folder.
        /// </summary>
        /// <param name="bundle">The bundle.</param>
        /// <param name="userPermissions">Indicates whether the upload should be performed with user or root permissions.</param>
        /// <returns>The path to the folder where the bundle was unpacked.</returns>
        private string UploadBundle(CommandBundle bundle, bool userPermissions)
        {
            Covenant.Requires<ArgumentNullException>(bundle != null);

            bundle.Validate();

            var executePermissions = userPermissions ? 707 : 700;

            using (var ms = new MemoryStream())
            {
                using (var zip = ZipFile.Create(ms))
                {
                    zip.BeginUpdate();

                    // Add the bundle files files to the ZIP archive we're going to upload.

                    foreach (var file in bundle)
                    {
                        var data = file.Data;

                        if (data == null && file.Text != null)
                        {
                            data = Encoding.UTF8.GetBytes(file.Text);
                        }

                        zip.Add(new StaticBytesDataSource(data), file.Path);
                    }

                    // Generate the "__run.sh" script file that will set execute permissions and
                    // then execute the bundle command.

                    var sb = new StringBuilder();

                    sb.AppendLineLinux("#!/bin/sh");
                    sb.AppendLineLinux();

                    foreach (var file in bundle.Where(f => f.IsExecutable))
                    {
                        if (file.Path.Contains(' '))
                        {
                            sb.AppendLineLinux($"chmod {executePermissions} \"{file.Path}\"");
                        }
                        else
                        {
                            sb.AppendLineLinux($"chmod {executePermissions} {file.Path}");
                        }
                    }

                    sb.AppendLineLinux(FormatCommand(bundle.Command, bundle.Args));

                    zip.Add(new StaticStringDataSource(sb.ToString()), "__run.sh");

                    // Commit the changes to the ZIP stream.

                    zip.CommitUpdate();
                }

                // Upload the ZIP file to a temporary folder.

                var bundleFolder = $"{HomeFolderPath}/bundle-{DateTime.UtcNow.Ticks}";
                var zipPath      = LinuxPath.Combine(bundleFolder, "__bundle.zip");

                ms.Position = 0;
                Upload(ms, zipPath, userPermissions: true);

                // Unzip the bundle. 

                var result = RunCommand($"unzip {zipPath} -d {bundleFolder}");

                // Make [__run.sh] executable.

                result = SudoCommand($"chmod {executePermissions}", LinuxPath.Combine(bundleFolder, "__run.sh"));

                return bundleFolder;
            }
        }

        /// <summary>
        /// Runs a shell command on the Linux server.
        /// </summary>
        /// <param name="command">The command.</param>
        /// <param name="args">The optional command arguments.</param>
        /// <returns>The <see cref="CommandResult"/>.</returns>
        /// <remarks>
        /// <para>
        /// This method uses the <see cref="RunOption.FaultOnError"/> option which
        /// means that a command that returns non-zero exit code, the server into the 
        /// faulted state by setting <see cref="IsFaulted"/>=<c>true</c>.  This means 
        /// that <see cref="IsReady"/> will always return <c>false</c> afterwards and 
        /// subsequent calls to <see cref="RunCommand(string, object[])"/> and 
        /// <see cref="SudoCommand(string, object[])"/> will be ignored unless 
        /// <see cref="RunOption.RunWhenFaulted"/> is passed with the future command.
        /// </para>
        /// <para>
        /// You can override this behavior by passing an <see cref="RunOption"/> to
        /// the <see cref="RunCommand(string, RunOption, object[])"/> override.
        /// </para>
        /// </remarks>
        public CommandResult RunCommand(string command, params object[] args)
        {
            Covenant.Requires<ArgumentNullException>(!string.IsNullOrEmpty(command));

            return RunCommand(command, RunOption.FaultOnError, args);
        }

        /// <summary>
        /// Runs a shell command on the Linux server with <see cref="RunOption"/>s.
        /// </summary>
        /// <param name="command">The command.</param>
        /// <param name="options">The execution options.</param>
        /// <param name="args">The optional command arguments.</param>
        /// <returns>The <see cref="CommandResult"/>.</returns>
        /// <remarks>
        /// <para>
        /// The <paramref name="options"/> flags control how this command functions.
        /// If <see cref="RunOption.FaultOnError"/> is set, then commands that return
        /// a non-zero exit code will put the server into the faulted state by setting
        /// <see cref="IsFaulted"/>=<c>true</c>.  This means that <see cref="IsReady"/> will 
        /// always return <c>false</c> afterwards and subsequent calls to <see cref="RunCommand(string, object[])"/>
        /// and <see cref="SudoCommand(string, object[])"/> will be ignored unless 
        /// <see cref="RunOption.RunWhenFaulted"/> is passed with the future command. 
        /// <see cref="RunOption.LogOnErrorOnly"/> indicates that command output should
        /// be logged only for non-zero exit codes.
        /// </para>
        /// </remarks>
        public CommandResult RunCommand(string command, RunOption options, params object[] args)
        {
            Covenant.Requires<ArgumentNullException>(!string.IsNullOrEmpty(command));

            command = FormatCommand(command, args);

            if (!string.IsNullOrWhiteSpace(RemotePath) && (options & RunOption.IgnoreRemotePath) == 0)
            {
                command = $"export PATH={RemotePath} && {command}";
            }

            var runWhenFaulted = (options & RunOption.RunWhenFaulted) != 0;
            var logOnErrorOnly = (options & RunOption.LogOnErrorOnly) != 0;
            var faultOnError   = (options & RunOption.FaultOnError) != 0;

            if (IsFaulted && !runWhenFaulted)
            {
                return new CommandResult()
                {
                    Command         = command,
                    ExitCode        = 1,
                    ServerIsFaulted = true
                };
            }

            EnsureSshConnection();

            if (!logOnErrorOnly)
            {
                // Log the original command by stripping out the remote PATH
                // statement, if there is one.

                LogLine($"START: {command.Replace($"export PATH={RemotePath} && ", string.Empty)}");
            }

            var result        = sshClient.RunCommand(command);
            var logEnabled    = result.ExitStatus != 0 || !logOnErrorOnly;
            var commandResult = new CommandResult()
            {
                Command  = command,
                ExitCode = result.ExitStatus,
                Output   = result.Result
            };

            if ((result.ExitStatus != 0 && logOnErrorOnly) || (options & RunOption.LogOutput) != 0)
            {
                LogLine($"START: {command}");

                if ((options & RunOption.LogOutput) != 0)
                {
                    using (var reader = new StringReader(commandResult.Output))
                    {
                        foreach (var line in reader.Lines())
                        {
                            LogLine("    " + line);
                        }
                    }
                }
            }

            if (result.ExitStatus != 0 || !logOnErrorOnly || (options & RunOption.LogOutput) != 0)
            {
                using (var reader = new StreamReader(result.ExtendedOutputStream))
                {
                    var extendedWritten = false;

                    foreach (var line in reader.Lines())
                    {
                        if (!extendedWritten)
                        {
                            LogLine("EXTENDED");
                            extendedWritten = true;
                        }

                        LogLine("    " + line);
                    }
                }

                if (result.ExitStatus == 0)
                {
                    LogLine("END [OK]");
                }
                else
                {
                    LogLine($"END [ERROR={result.ExitStatus}]");
                }

                if (result.ExitStatus != 0)
                {
                    Status = $"ERROR[{result.ExitStatus}]";

                    if (faultOnError)
                    {
                        IsFaulted = true;
                    }
                }
            }

            return commandResult;
        }

        /// <summary>
        /// Runs a <see cref="CommandBundle"/> on the remote machine.
        /// </summary>
        /// <param name="bundle">The bundle.</param>
        /// <returns>The <see cref="CommandResult"/>.</returns>
        /// <remarks>
        /// <para>
        /// This method is indended for situations where one or more files need to be uploaded to a NeonCloud host node 
        /// and then be used when a command is executed.
        /// </para>
        /// <para>
        /// A good example of this is performing a Docker Compose command on the cluster.  In this case, we need to
        /// upload the <b>docker-compose.yml</b> file along with any files it references and then we we'll want to
        /// execute the <b>docker-compose</b> CLI.
        /// </para>
        /// <para>
        /// You'll need to construct a <see cref="CommandBundle"/> instance passing the command to be executed.  The command
        /// be an absolute reference to an executable in folders such as <b>/bin</b> or <b>/usr/local/bin</b>, an executable 
        /// somewhere on the current PATH, or relative to the files unpacked from the bundle.  The current working directory
        /// will be set to the folder where the bundle was unpacked, so you can reference local executables like
        /// <b>./MyExecutable</b>.
        /// </para>
        /// <para>
        /// Then add one or more <see cref="CommandFile"/> instances to your bundle, specifying the
        /// file data you want to include.  These include the relative path to the file to be uploaded as well
        /// as its text or binary data.  You may also indicate whether each file is to be marked as executable.
        /// </para>
        /// <note>
        /// This command requires that the <b>unzip</b> package be installed on the host.
        /// </note>
        /// </remarks>
        public CommandResult RunCommand(CommandBundle bundle)
        {
            Covenant.Requires<ArgumentNullException>(bundle != null);

            // Upload and extract the bundle and then run the "__run.sh" script.

            var bundleFolder = UploadBundle(bundle, userPermissions: true);
            var result       = RunCommand($"cd {bundleFolder} && ./__run.sh");

            // Remove the bundle files.

            RunCommand("rm -rf", bundleFolder);

            return result;
        }

        /// <summary>
        /// Runs a shell command on the Linux server under <b>sudo</b>.
        /// </summary>
        /// <param name="command">The command.</param>
        /// <param name="args">The optional command arguments.</param>
        /// <returns>The <see cref="CommandResult"/>.</returns>
        /// <remarks>
        /// <para>
        /// This method uses the <see cref="RunOption.FaultOnError"/> option which
        /// means that a command that returns non-zero exit code, the server into the 
        /// faulted state by setting <see cref="IsFaulted"/>=<c>true</c>.  This means 
        /// that <see cref="IsReady"/> will always return <c>false</c> afterwards and 
        /// subsequent command executions will be ignored unless  <see cref="RunOption.RunWhenFaulted"/>
        /// is specified for the future command.
        /// </para>
        /// <para>
        /// You can override this behavior by passing an <see cref="RunOption"/> to
        /// the <see cref="RunCommand(string, RunOption, object[])"/> override.
        /// </para>
        /// </remarks>
        public CommandResult SudoCommand(string command, params object[] args)
        {
            Covenant.Requires<ArgumentNullException>(!string.IsNullOrEmpty(command));

            return SudoCommand(command, RunOption.FaultOnError, args);
        }

        /// <summary>
        /// Runs a shell command on the Linux server under <b>sudo</b> with <see cref="RunOption"/>s.
        /// </summary>
        /// <param name="command">The command.</param>
        /// <param name="options">The execution options.</param>
        /// <param name="args">The optional command arguments.</param>
        /// <returns>The <see cref="CommandResult"/>.</returns>
        /// <remarks>
        /// <para>
        /// The <paramref name="options"/> flags control how this command functions.
        /// If <see cref="RunOption.FaultOnError"/> is set, then commands that return
        /// a non-zero exit code will put the server into the faulted state by setting
        /// <see cref="IsFaulted"/>=<c>true</c>.  This means that <see cref="IsReady"/> will 
        /// always return <c>false</c> afterwards and subsequent command executions will be 
        /// ignored unless  <see cref="RunOption.RunWhenFaulted"/> is specified for the 
        /// future command.
        /// </para>
        /// <para>
        /// <see cref="RunOption.LogOnErrorOnly"/> indicates that command output should
        /// be logged only for non-zero exit codes.
        /// </para>
        /// </remarks>
        public CommandResult SudoCommand(string command, RunOption options, params object[] args)
        {
            Covenant.Requires<ArgumentNullException>(!string.IsNullOrEmpty(command));

            command = FormatCommand(command, args);

            if (!string.IsNullOrWhiteSpace(RemotePath))
            {
                command = $"export PATH={RemotePath} && {command}";
            }

            return RunCommand($"sudo bash -c '{command}'", options | RunOption.IgnoreRemotePath);
        }

        /// <summary>
        /// Runs a <see cref="CommandBundle"/> under <b>sudo</b> on the remote machine.
        /// </summary>
        /// <param name="bundle">The bundle.</param>
        /// <returns>The <see cref="CommandResult"/>.</returns>
        /// <remarks>
        /// <para>
        /// This method is indended for situations where one or more files need to be uploaded to a NeonCloud host node 
        /// and then be used when a command is executed.
        /// </para>
        /// <para>
        /// A good example of this is performing a Docker Compose command on the cluster.  In this case, we need to
        /// upload the <b>docker-compose.yml</b> file along with any files it references and then we we'll want to
        /// execute the <b>docker-compose</b> CLI.
        /// </para>
        /// <para>
        /// You'll need to construct a <see cref="CommandBundle"/> instance passing the command to be executed.  The command
        /// be an absolute reference to an executable in folders such as <b>/bin</b> or <b>/usr/local/bin</b>, an executable 
        /// somewhere on the current PATH, or relative to the files unpacked from the bundle.  The current working directory
        /// will be set to the folder where the bundle was unpacked, so you can reference local executables like
        /// <b>./MyExecutable</b>.
        /// </para>
        /// <para>
        /// Then add one or more <see cref="CommandFile"/> instances to your bundle, specifying the
        /// file data you want to include.  These include the relative path to the file to be uploaded as well
        /// as its text or binary data.  You may also indicate whether each file is to be marked as executable.
        /// </para>
        /// <note>
        /// This command requires that the <b>unzip</b> package be installed on the host.
        /// </note>
        /// </remarks>
        public CommandResult SudoCommand(CommandBundle bundle)
        {
            Covenant.Requires<ArgumentNullException>(bundle != null);

            // Upload and extract the bundle and then run the "__run.sh" script.

            var bundleFolder = UploadBundle(bundle, userPermissions: false);
            var result       = SudoCommand($"cd {bundleFolder} && /bin/bash ./__run.sh");

            // Remove the bundle files.

            SudoCommand("rm -rf", bundleFolder);

            return result;
        }

        /// <summary>
        /// The path to the <b>Docker CLI</b> on the remote machine.  This
        /// is used by the <see cref="DockerCommand(string, object[])"/> and 
        /// <see cref="DockerCommand(string, RunOption, object[])"/> 
        /// methods.
        /// </summary>
        /// <remarks>
        /// <para>
        /// This defaults to the normal Docker install location at:
        /// </para>
        /// <para>
        /// <b>/usr/bin/docker</b>
        /// </para>
        /// </remarks>
        public string DockerPath { get; set; } = "/usr/bin/docker";

        /// <summary>
        /// Runs a <b>Docker</b> command against the <b>local node</b> under <b>sudo</b>.
        /// </summary>
        /// <param name="command">The Docker command.</param>
        /// <param name="args">The arguments.</param>
        /// <returns>The <see cref="CommandResult"/>.</returns>
        /// <remarks>
        /// <para>
        /// This method uses the <see cref="RunOption.FaultOnError"/> option which
        /// means that a command that returns non-zero exit code, the server into the 
        /// faulted state by setting <see cref="IsFaulted"/>=<c>true</c>.  This means 
        /// that <see cref="IsReady"/> will always return <c>false</c> afterwards and 
        /// subsequent command executions will be ignored unless <see cref="RunOption.RunWhenFaulted"/>
        /// is specified for the future command.
        /// </para>
        /// <para>
        /// You can override this behavior by passing an <see cref="RunOption"/> to
        /// the <see cref="DockerCommand(string, RunOption, object[])"/> override.
        /// </para>
        /// </remarks>
        public CommandResult DockerCommand(string command, params object[] args)
        {
            Covenant.Requires<ArgumentNullException>(!string.IsNullOrWhiteSpace(command));

            return SudoCommand($"{DockerPath} {command}", args);
        }

        /// <summary>
        /// Runs a <b>Docker</b> command against the <b>local node</b> under <b>sudo</b> 
        /// with <see cref="RunOption"/>s.
        /// </summary>
        /// <param name="command">The Docker command.</param>
        /// <param name="options">The execution options.</param>
        /// <param name="args">The arguments.</param>
        /// <returns>The <see cref="CommandResult"/>.</returns>
        /// <returns>The <see cref="CommandResult"/>.</returns>
        /// <remarks>
        /// <para>
        /// The <paramref name="options"/> flags control how this command functions.
        /// If <see cref="RunOption.FaultOnError"/> is set, then commands that return
        /// a non-zero exit code will put the server into the faulted state by setting
        /// <see cref="IsFaulted"/>=<c>true</c>.  This means that <see cref="IsReady"/> will always
        /// return <c>false</c> afterwards and subsequent command executions will be ignored unless 
        /// <see cref="RunOption.RunWhenFaulted"/> is specified for the future command. 
        /// </para>
        /// <para>
        /// <see cref="RunOption.LogOnErrorOnly"/> indicates that command output should
        /// be logged only for non-zero exit codes.
        /// </para>
        /// </remarks>
        public CommandResult DockerCommand(string command, RunOption options, params object[] args)
        {
            Covenant.Requires<ArgumentNullException>(!string.IsNullOrWhiteSpace(command));

            return SudoCommand($"{DockerPath} {command}", options, args);
        }

        /// <summary>
        /// The path to the <b>Swarm</b> alias script on the remote machine.  This is used
        /// by the <see cref="SwarmCommand(string, object[])"/> and <see cref="SwarmCommand(string, RunOption, object[])"/> 
        /// methods.
        /// </summary>
        /// <remarks>
        /// <para>
        /// The <b>neon-conf</b> tool installs a script that forwards commands to the
        /// Docker CLI with the host set to a Swarm manager.  This path defaults to:
        /// </para>
        /// <para>
        /// <b>/usr/local/bin/swarm</b>
        /// </para>
        /// </remarks>
        public string SwarmPath { get; set; } = "/usr/local/bin/docker-swarm";

        /// <summary>
        /// Runs a <b>Docker</b> command against the <b>Swarm cluster</b> under <b>sudo</b>.
        /// </summary>
        /// <param name="command">The Docker command.</param>
        /// <param name="args">The arguments.</param>
        /// <returns>The <see cref="CommandResult"/>.</returns>
        /// <remarks>
        /// <note>
        /// Swarm commands may be issued to either manager or worker nodes.  Manager nodes
        /// will handle these locally and worker nodes will forward the command to a manager.
        /// </note>
        /// <para>
        /// This method uses the <see cref="RunOption.FaultOnError"/> option which
        /// means that a command that returns non-zero exit code, the server into the 
        /// faulted state by setting <see cref="IsFaulted"/>=<c>true</c>.  This means 
        /// that <see cref="IsReady"/> will always return <c>false</c> afterwards and 
        /// subsequent command executions will be ignored unless <see cref="RunOption.RunWhenFaulted"/>
        /// is specified for the future command.
        /// </para>
        /// <para>
        /// You can override this behavior by passing an <see cref="RunOption"/> to
        /// the <see cref="DockerCommand(string, RunOption, object[])"/> override.
        /// </para>
        /// </remarks>
        public CommandResult SwarmCommand(string command, params object[] args)
        {
            Covenant.Requires<ArgumentNullException>(!string.IsNullOrWhiteSpace(command));

            return SudoCommand($"{SwarmPath} {command}", args);
        }

        /// <summary>
        /// Runs a <b>Docker</b> command against the <b>Swarm cluster</b> under <b>sudo</b> 
        /// with <see cref="RunOption"/>s.
        /// </summary>
        /// <param name="command">The Docker command.</param>
        /// <param name="options">The execution options.</param>
        /// <param name="args">The arguments.</param>
        /// <returns>The <see cref="CommandResult"/>.</returns>
        /// <returns>The <see cref="CommandResult"/>.</returns>
        /// <remarks>
        /// <note>
        /// Swarm commands may be issued to either manager or worker nodes.  Manager nodes
        /// will handle these locally and worker nodes will forward the command to a manager.
        /// </note>
        /// <para>
        /// The <paramref name="options"/> flags control how this command functions.
        /// If <see cref="RunOption.FaultOnError"/> is set, then commands that return
        /// a non-zero exit code will put the server into the faulted state by setting
        /// <see cref="IsFaulted"/>=<c>true</c>.  This means that <see cref="IsReady"/> will always
        /// return <c>false</c> afterwards and subsequent command executions will be ignored unless 
        /// <see cref="RunOption.RunWhenFaulted"/> is specified for the future command. 
        /// </para>
        /// <para>
        /// <see cref="RunOption.LogOnErrorOnly"/> indicates that command output should
        /// be logged only for non-zero exit codes.
        /// </para>
        /// </remarks>
        public CommandResult SwarmCommand(string command, RunOption options, params object[] args)
        {
            Covenant.Requires<ArgumentNullException>(!string.IsNullOrWhiteSpace(command));

            return SudoCommand($"{SwarmPath} {command}", options, args);
        }
    }
}
