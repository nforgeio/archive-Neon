﻿//-----------------------------------------------------------------------------
// FILE:	    ComposeLogServices.cs
// CONTRIBUTOR: Jeff Lill
// COPYRIGHT:	Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.Contracts;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using Newtonsoft;
using Newtonsoft.Json;

using Neon.Stack.Common;
using Neon.Stack.IO;
using Neon.Stack.Management;

// $hack(jeff.lill):
//
// The Weave network plugin doesn't work due to a Docker design flaw.
// Docker provides no way to prioritize launching plugin containers
// before containers that depend on them and to make matters worse,
// Docker won't attempt to restart a container that depends on a 
// plugin that hasn't been loaded yet.
//
// A consequence of this is that Compose v2 files won't work, even
// with the Weave API proxy.  This happens because Compose v2 will
// create an explicit default network.
//
// This means that we need to generate Compose v1 files until this
// is addressed.

namespace NeonConf
{
    /// <summary>
    /// Generates Docker Compose files for cluster logging related services from
    /// resource templates.
    /// </summary>
    public static class ComposeLogServices
    {
        //---------------------------------------------------------------------
        // Local types

        /// <summary>
        /// Information about a required named volume.
        /// </summary>
        public class VolumeInfo
        {
            /// <summary>
            /// The volume name.
            /// </summary>
            public string Name { get; set; }

            /// <summary>
            /// The node where the volume is to be created.
            /// </summary>
            public NodeDefinition Node { get; set; }
        }

        /// <summary>
        /// Includes the information required to deploy services.
        /// </summary>
        public class DeploymentInfo
        {
            /// <summary>
            /// The Docker Compose project name.
            /// </summary>
            public string ProjectName { get; set; }

            /// <summary>
            /// Describes the required named volumes.
            /// </summary>
            public List<VolumeInfo> Volumes { get; set; } = new List<VolumeInfo>();

            /// <summary>
            /// The Docker Compose file that deploys the services.
            /// </summary>
            public string ComposeFile { get; set; }
        }

        //---------------------------------------------------------------------
        // Implementation

        /// <summary>
        /// Appends the <b>Networks:</b> section to a Docker Compose file builder.
        /// </summary>
        /// <param name="clusterDefinition">The cluster definition.</param>
        /// <param name="sbCompose">The <see cref="StringBuilder"/>.</param>
        private static void AppendComposeNetworks(ClusterDefinition clusterDefinition, StringBuilder sbCompose)
        {
            var networkName = clusterDefinition.Weave.Network.Enabled ? clusterDefinition.Weave.Network.Name : clusterDefinition.Network.Name;

            sbCompose.AppendLineLinux();
            sbCompose.AppendLineLinux("networks:");
            sbCompose.AppendLineLinux();
            sbCompose.AppendLineLinux("    clusternet:");
            sbCompose.AppendLineLinux("         external:");
            sbCompose.AppendLineLinux($"             name: {networkName}");
        }

        /// <summary>
        /// Returns the information required to deploy the Elasticsearch nodes
        /// used to host a cluster's log event data.
        /// </summary>
        /// <param name="clusterDefinition">The cluster definition.</param>
        /// <returns>A <see cref="DeploymentInfo"/> instance.</returns>
        public static DeploymentInfo ElasticsearchDeployment(ClusterDefinition clusterDefinition)
        {
            Covenant.Requires<ArgumentNullException>(clusterDefinition != null);
            Covenant.Requires<ArgumentException>(clusterDefinition.Log.Enabled);

            var deployment = new DeploymentInfo() { ProjectName = "neon-log-es" };
            var sbCompose  = new StringBuilder();

            // NOTE: We're generating the output with Linux-style line endings.

            sbCompose.AppendLineLinux("version: '2'");

            //-----------------------------------------------------------------
            // Generate the named volume definitions.

            var eligibleEsNodes = clusterDefinition.FilterWorkers(clusterDefinition.Log.EsConstraints).ToList();

            Covenant.Assert(eligibleEsNodes.Count >= clusterDefinition.Log.EsInstances);

            for (int instance = 0; instance < clusterDefinition.Log.EsInstances; instance++)
            {
                deployment.Volumes.Add(
                    new VolumeInfo()
                    {
                        Name = $"{deployment.ProjectName}_{instance + 1}",
                        Node = eligibleEsNodes[instance]
                    });
            }

            sbCompose.AppendLineLinux();
            sbCompose.AppendLineLinux("volumes:");
            sbCompose.AppendLineLinux();

            foreach (var volume in deployment.Volumes)
            {
                sbCompose.AppendLineLinux($"    {volume.Name}:");
                sbCompose.AppendLineLinux($"        external: true");
            }

            //-----------------------------------------------------------------
            // Generate the Weave network definitions.

            AppendComposeNetworks(clusterDefinition, sbCompose);

            //-----------------------------------------------------------------
            // Generate a service definition from the [Properties.LogCompose.elasticsearch]
            // template for each requested Elasticsearch node.

            sbCompose.AppendLineLinux();
            sbCompose.AppendLineLinux("services:");

            for (int instance = 0; instance < clusterDefinition.Log.EsInstances; instance++)
            {
                var volume       = deployment.Volumes[instance];
                var instanceName = $"{deployment.ProjectName}_{instance + 1}";

                // Process the template.

                using (var reader = new PreprocessReader(Properties.LogCompose.elasticsearch))
                {
                    reader.Indent         = 4;
                    reader.LineEnding     = LineEnding.LF;
                    reader.RemoveComments = true;
                    reader.RemoveBlank    = true;

                    reader.Set("node", volume.Node.Name);
                    reader.Set("cluster_name", deployment.ProjectName);
                    reader.Set("instance_name", instanceName);
                    reader.Set("dns_domain", ClusterDefinition.ReservedDomain);
                    reader.Set("data_volume", $"{volume.Name}");
                    reader.Set("image", clusterDefinition.Log.ElasticsearchImage);
                    reader.Set("shard_count", clusterDefinition.Log.EsShards);
                    reader.Set("replica_count", clusterDefinition.Log.EsReplicas);
                    reader.Set("quorum", clusterDefinition.Log.EsInstances/2 + 1);

                    // NOTE: 
                    //
                    // The built-in Docker overlay network doesn't support multicast
                    // and the Weave plugin doesn't currently work due to Docker design
                    // flaws, so we're going to configure unicast discovery and use the
                    // first Elasticsearch node as the bootstrap seed.

                    reader.Set("multicast", "false");
                    reader.Set("bootstrap", $"{deployment.ProjectName}_1");

                    sbCompose.AppendLineLinux();
                    sbCompose.Append(reader.ReadToEnd());
                }

                // Reference the overlay network and configure DNS aliases for the common
                // service name as well as the specific instance.

                sbCompose.AppendLineLinux("        networks:");
                sbCompose.AppendLineLinux("            clusternet:");
                sbCompose.AppendLineLinux("                aliases:");
                sbCompose.AppendLineLinux($"                    - {deployment.ProjectName}");

                // Append the Weave related network properties if we're using the Weave plugin.

                if (clusterDefinition.Weave.Network.Enabled)
                {
                    sbCompose.AppendLineLinux("        dns: ${NEON_NET_DNS}");
                    sbCompose.AppendLineLinux("        dns_search: ${NEON_NET_DNSSEARCH}");
                }
            }

            deployment.ComposeFile = sbCompose.ToString();

            return deployment;
        }
    }
}
