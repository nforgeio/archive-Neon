﻿//-----------------------------------------------------------------------------
// FILE:	    Program.cs
// CONTRIBUTOR: Jeff Lill
// COPYRIGHT:	Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.Contracts;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Neon.Stack;
using Neon.Stack.Common;
using Neon.Stack.Management;

namespace NeonConf
{
    /// <summary>
    /// This tool is used to configure the nodes of a Neon Docker Swarm cluster.
    /// See <b>~/Stack/Dock/Ubuntu-14.04 Cluster Deploy.docx</b> for more information.
    /// </summary>
    /// <remarks>
    /// <para>
    /// This tool implements the following commands:
    /// </para>
    /// <list type="table">
    /// <item>
    ///     <term><b>help</b></term>
    ///     <description>
    ///     Displays help for a command.
    ///     </description>
    /// </item>
    /// <item>
    ///     <term><b>generate-key</b></term>
    ///     <description>
    ///     <para>
    ///     Generates a unique 16-byte Base64 encoded encryption key suitable
    ///     for encrypting Consul and Weave network traffic.
    ///     </para>
    ///     <para>
    ///     See <see cref="GenerateKeyCommand"/>.
    ///     </para>
    ///     </description>
    /// </item>
    /// <item>
    ///     <term><b>sample-def</b></term>
    ///     <description>
    ///     <para>
    ///     Writes a sample cluster definition to standard output.
    ///     </para>
    ///     <para>
    ///     See <see cref="SampleDefCommand"/>.
    ///     </para>
    ///     </description>
    /// </item>
    /// <item>
    ///     <term><b>prep-node</b></term>
    ///     <description>
    ///     <para>
    ///     Prepares a near virgin Ubuntu server instance to be ready to host a
    ///     Neon cluster.  This is typically used to prepare a template virtual
    ///     machine or PXE boot image.
    ///     </para>
    ///     <para>
    ///     See <see cref="PrepNodeCommand"/>.
    ///     </para>
    ///     </description>
    /// </item>
    /// <item>
    ///     <term><b>setup-cluster</b></term>
    ///     <description>
    ///     <para>
    ///     Configures a Neon cluster as specified by a cluster definition file.
    ///     </para>
    ///     <para>
    ///     See <see cref="SetupClusterCommand"/>.
    ///     </para>
    ///     </description>
    /// </item>
    /// <item>
    ///     <term><b>update-tools</b></term>
    ///     <description>
    ///     <para>
    ///     Updates the Neon setup scripts and tools on a cluster or specified
    ///     set of servers.
    ///     </para>
    ///     <para>
    ///     See <see cref="UpdateToolsCommand"/>.
    ///     </para>
    ///     </description>
    /// </item>
    /// <item>
    ///     <term><b>validate-clusterdef</b></term>
    ///     <description>
    ///     <para>
    ///     Validates a cluster definition file.
    ///     </para>
    ///     <para>
    ///     See <see cref="ValidateDefCommand"/>.
    ///     </para>
    ///     </description>
    /// </item>
    /// </list>
    /// </remarks>
    public static class Program
    {
        /// <summary>
        /// Program entry point.
        /// </summary>
        /// <param name="args">The command line arguments.</param>
        public static void Main(string[] args)
        {
            string usage = $@"
Neon Docker Cluster Configuration Tool: neon-conf [v{Build.Version}]
{Build.Copyright}

usage:

neon-conf [OPTIONS] COMMAND [arg...]

neon-conf help              COMMAND
neon-conf check-health      DEFINITION-PATH
neon-conf generate-key
neon-conf prep-node         SERVER1 [ SERVER2... ]
neon-conf sample-def
neon-conf setup-cluster     DEFINITION-PATH
neon-conf update-tools      DEFINITION-PATH
neon-conf update-tools      SERVER1 [ SERVER2... ]
neon-conf validate-def      DEFINITION-PATH

    -u=USER, --user=USER                - Server admin user name
    -p=PASSWORD, --password=PASSWORD    - Server admin password
    --os=ubuntu=14.04                   - Target host OS (default)
    --os=ubuntu=16.04
    --log=LOG-FOLDER                    - Local log folder
    -q, --quiet                         - Disables logging
    -m=COUNT, --max-parallel=COUNT      - Maximum number of nodes to be 
                                          configured in parallel the
                                          default is 3
    -w=SECONDS, --wait=SECONDS          - Seconds to delay for cluster
                                          stablization.. Defaults to 60.
";
            Console.WriteLine();

            try
            {
                ICommand command;

                CommandLine = new CommandLine(args);

                CommandLine.DefineOption("-u", "--user");
                CommandLine.DefineOption("-p", "--password");
                CommandLine.DefineOption("-os").Default = "ubuntu=14.04";
                CommandLine.DefineOption("-q", "--quiet");
                CommandLine.DefineOption("-m", "--max-parallel").Default = "3";
                CommandLine.DefineOption("-w", "--wait").Default = "60";

                if (CommandLine.Arguments.Length == 0)
                {
                    Console.WriteLine(usage);
                    Program.Exit(0);
                }

                var commands = new List<ICommand>()
                {
                    new CheckHealthCommand(),
                    new GenerateKeyCommand(),
                    new SampleDefCommand(),
                    new PrepNodeCommand(),
                    new SetupClusterCommand(),
                    new UpdateToolsCommand(),
                    new ValidateDefCommand()
                };

                if (CommandLine.Arguments[0] == "help")
                {
                    if (CommandLine.Arguments.Length == 1)
                    {
                        Console.WriteLine(usage);
                        Program.Exit(0);
                    }

                    command = commands.SingleOrDefault(c => c.Name == CommandLine.Arguments[1]);

                    if (command == null)
                    {
                        Console.Error.WriteLine($"Invalid command: {CommandLine.Arguments[1]}");
                        Console.Error.WriteLine(usage);
                        Program.Exit(1);
                    }

                    command.Help();
                    Program.Exit(0);
                }

                // Process the common command line options.

                var os = CommandLine.GetOption("--os", "ubuntu-14.04").ToLowerInvariant();

                switch (os)
                {
                    case "ubuntu-14.04":

                        TargetOS = TargetOS.Ubuntu_14_04;
                        break;

                    case "ubuntu-16.04":

                        TargetOS = TargetOS.Ubuntu_16_04;
                        break;

                    default:

                        Console.Error.WriteLine($"[--os={os}] is not a supported target operating system.");
                        Program.Exit(1);
                        break;
                }

                UserName = CommandLine.GetOption("--user");
                Password = CommandLine.GetOption("--password");
                LogPath  = CommandLine.GetOption("--log", Path.Combine(".", "log"));

                if (CommandLine.HasOption("-quiet"))
                {
                    LogPath = null;
                }
                else
                {
                    LogPath = Path.GetFullPath(LogPath);

                    Directory.CreateDirectory(LogPath);
                }

                string  maxParallelOption = CommandLine.GetOption("--max-parallel");
                int     maxParallel;

                if (!int.TryParse(maxParallelOption, out maxParallel) || maxParallel <= 1)
                {
                    Console.Error.WriteLine($"[--max-parallel={maxParallelOption}] option is not valid.");
                    Program.Exit(1);
                }

                Program.MaxParallel = maxParallel;

                string  waitSecondsOption = CommandLine.GetOption("--wait");
                double  waitSeconds;

                if (!double.TryParse(waitSecondsOption, out waitSeconds) || waitSeconds < 0)
                {
                    Console.Error.WriteLine($"[--wait={waitSecondsOption}] option is not valid.");
                    Program.Exit(1);
                }

                Program.WaitSeconds = waitSeconds;

                if (CommandLine.Arguments.Length == 0)
                {
                    Console.Error.Write("Error: The [command] argument is required.");
                    Console.Error.WriteLine(string.Empty);
                    Console.Error.WriteLine(usage);
                    Program.Exit(1);
                }

                // Locate and run the command.

                command = commands.SingleOrDefault(c => c.Name == CommandLine.Arguments[0]);

                if (command == null)
                {
                    Console.Error.WriteLine($"Invalid command: {CommandLine.Arguments[0]}");
                    Program.Exit(1);
                }

                if (command.NeedsCredentials)
                {
                    while (string.IsNullOrWhiteSpace(UserName))
                    {
                        Console.Write("username: ");
                        UserName = Console.ReadLine();
                    }

                    while (string.IsNullOrEmpty(Password))
                    {
                        Console.Write("password: ");

                        Password = NeonHelper.ReadConsolePassword();
                    }

                    Console.Clear();
                    Console.WriteLine();
                }

                command.Run(CommandLine);
            }
            catch (Exception e)
            {
                Console.Error.WriteLine($"{NeonHelper.ExceptionError(e)}");
                Console.Error.WriteLine(string.Empty);
                Program.Exit(1);
            }

            Program.Exit(0);
        }

        /// <summary>
        /// Exits the program returning the specified process exit code.
        /// </summary>
        /// <param name="exitCode">The exit code.</param>
        public static void Exit(int exitCode)
        {
           Environment.Exit(exitCode);
        }

        /// <summary>
        /// Returns the <see cref="CommandLine"/>.
        /// </summary>
        public static CommandLine CommandLine { get; private set; }

        /// <summary>
        /// Returns the target operating system.
        /// </summary>
        public static TargetOS TargetOS { get; private set; }

        /// <summary>
        /// Returns the admin user name.
        /// </summary>
        public static string UserName { get; private set; }

        /// <summary>
        /// Returns the admin user password.
        /// </summary>
        public static string Password { get; private set; }

        /// <summary>
        /// Returns the log folder path or <c>null</c> for quiet mode.
        /// </summary>
        public static string LogPath { get; private set; }

        /// <summary>
        /// The maximum number of nodes to be configured in parallel.
        /// </summary>
        public static int MaxParallel { get; private set; }

        /// <summary>
        /// The seconds to wait for cluster stablization.
        /// </summary>
        public static double WaitSeconds { get; private set; }

        /// <summary>
        /// Creates a <see cref="NodeManagementProxy{TMetadata}"/> for the specified host and server name,
        /// configuring logging and the credentials as specified by the global command
        /// line options.
        /// </summary>
        /// <param name="host">The host IP address or FQDN.</param>
        /// <param name="name">The optional host name (defaults to <paramref name="host"/>).</param>
        /// <typeparam name="TMetadata">Defines the metadata type the command wishes to associate with the sewrver.</typeparam>
        /// <returns>The <see cref="NodeManagementProxy{TMetadata}"/>.</returns>
        public static NodeManagementProxy<TMetadata> CreateNodeManagementProxy<TMetadata>(string host, string name = null)
            where TMetadata : class
        {
            Covenant.Requires<ArgumentNullException>(!string.IsNullOrEmpty(host));

            name = name ?? host;

            var logWriter = (TextWriter)null;

            if (LogPath != null)
            {
                logWriter = new StreamWriter(Path.Combine(LogPath, name + ".log"));
            }

            var proxy = new NodeManagementProxy<TMetadata>(name, host, SshCredentials.FromUserPassword(UserName, Password), logWriter);

            proxy.RemotePath += $":{NodeHostFolder.SetupFolder}";

            return proxy;
        }

        /// <summary>
        /// Returns the folder holding the Linux resource files for the target operating system.
        /// </summary>
        public static ResourceFiles.Folder LinuxFolder
        {
            get
            {
                switch (Program.TargetOS)
                {
                    case TargetOS.Ubuntu_14_04:

                        return ResourceFiles.Linux.GetFolder("Ubuntu-14.04");

                    case TargetOS.Ubuntu_16_04:

                        return ResourceFiles.Linux.GetFolder("Ubuntu-16.04");

                    default:

                        throw new NotImplementedException($"Unexpected [{Program.TargetOS}] target operating system.");
                }
            }
        }

        /// <summary>
        /// Returns the file path to the currently running executable.
        /// </summary>
        public static string PathToExecutable
        {
            get
            {
                // $hack(jeff.lill):
                //
                // This is a bit of hack.  There are two cases:
                //
                //      1. The tool is being run in the debugger, in which case
                //         we're not running the standalone executable that has
                //         all of the referenced assemblies merged in.  We can
                //         tell this if the file name begins with an underscore (_).
                //     
                //         In this case, we're going to reference the fully merged
                //         executable built in the post-build script and written
                //         to %NR_BUILD%\bin.
                //
                //      2. The tool is running from the fully merged executable.
                //         This will happen when running on the command line or
                //         on a Linux box.

                var path = Process.GetCurrentProcess().MainModule.FileName;

                if (Path.GetFileName(path).StartsWith("_"))
                {
                    path = Path.Combine(BuildEnvironment.BuildArtifactPath, "neon-conf.exe");
                }

                return path;
            }
        }
    }
}
