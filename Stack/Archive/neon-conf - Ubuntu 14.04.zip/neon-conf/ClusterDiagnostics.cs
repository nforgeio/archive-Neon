﻿//-----------------------------------------------------------------------------
// FILE:	    ClusterDiagnostics.cs
// CONTRIBUTOR: Jeff Lill
// COPYRIGHT:	Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.Contracts;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

using Newtonsoft;
using Newtonsoft.Json;

using EtcdNet;

using Neon.Stack.Common;
using Neon.Stack.Docker;
using Neon.Stack.Management;

// $todo(jeff.lill): Verify that there are no unexpected nodes in the cluster.

namespace NeonConf
{
    /// <summary>
    /// Methods to verify that cluster nodes are configured and functioning properly.
    /// </summary>
    public static class ClusterDiagnostics
    {
        /// <summary>
        /// Verifies that a cluster manager node is healthy.
        /// </summary>
        /// <param name="server">The manager node.</param>
        /// <param name="clusterDefinition">The cluster definition.</param>
        public static void CheckClusterManager(NodeManagementProxy<NodeDefinition> server, ClusterDefinition clusterDefinition)
        {
            Covenant.Requires<ArgumentNullException>(server != null);
            Covenant.Requires<ArgumentException>(server.Metadata.Manager);
            Covenant.Requires<ArgumentNullException>(clusterDefinition != null);

            if (!server.IsFaulted)
            {
                CheckManagerNtp(server, clusterDefinition);
            }

            if (!server.IsFaulted)
            {
                CheckDocker(server, clusterDefinition);
            }

            if (!server.IsFaulted)
            {
                CheckHostTDAgent(server, clusterDefinition);
            }

            if (!server.IsFaulted)
            {
                CheckConsul(server, clusterDefinition);
            }

            if (!server.IsFaulted)
            {
                CheckEtcdManager(server, clusterDefinition);
            }

            if (!server.IsFaulted)
            {
                CheckSwarmManager(server, clusterDefinition);
            }

            if (!server.IsFaulted)
            {
                CheckWeaveNetwork(server, clusterDefinition);
            }

            if (!server.IsFaulted)
            {
                CheckWeaveFlux(server, clusterDefinition);
            }

            if (!server.IsFaulted)
            {
                CheckWeaveScope(server, clusterDefinition);
            }

            if (!server.IsFaulted)
            {
                CheckVault(server, clusterDefinition);
            }

            server.Status = "healthy";
        }

        /// <summary>
        /// Verifies that a cluster worker nodes is healthy.
        /// </summary>
        /// <param name="server">The server node.</param>
        /// <param name="clusterDefinition">The cluster definition.</param>
        public static void CheckClusterWorker(NodeManagementProxy<NodeDefinition> server, ClusterDefinition clusterDefinition)
        {
            Covenant.Requires<ArgumentNullException>(server != null);
            Covenant.Requires<ArgumentException>(server.Metadata.Worker);
            Covenant.Requires<ArgumentNullException>(clusterDefinition != null);

            if (!server.IsFaulted)
            {
                CheckWorkerNtp(server, clusterDefinition);
            }

            if (!server.IsFaulted)
            {
                CheckDocker(server, clusterDefinition);
            }

            if (!server.IsFaulted)
            {
                CheckHostTDAgent(server, clusterDefinition);
            }

            if (!server.IsFaulted)
            {
                CheckConsul(server, clusterDefinition);
            }

            if (!server.IsFaulted)
            {
                CheckEtcdWorker(server, clusterDefinition);
            }

            if (!server.IsFaulted)
            {
                CheckWeaveNetwork(server, clusterDefinition);
            }

            if (!server.IsFaulted)
            {
                CheckWeaveFlux(server, clusterDefinition);
            }

            if (!server.IsFaulted)
            {
                CheckVault(server, clusterDefinition);
            }

            server.Status = "healthy";
        }

        /// <summary>
        /// Verifies that a manager node's NTP health.
        /// </summary>
        /// <param name="server">The manager node.</param>
        /// <param name="clusterDefinition">The cluster definition.</param>
        private static void CheckManagerNtp(NodeManagementProxy<NodeDefinition> server, ClusterDefinition clusterDefinition)
        {
            // We're going to use [ntpq -p] to query the configured time sources.
            // We should get something back that looks like
            //
            //      remote           refid      st t when poll reach   delay   offset  jitter
            //      ==============================================================================
            //       LOCAL(0).LOCL.          10 l  45m   64    0    0.000    0.000   0.000
            //      * clock.xmission. .GPS.            1 u  134  256  377   48.939 - 0.549  18.357
            //      + 173.44.32.10    18.26.4.105      2 u  200  256  377   96.981 - 0.623   3.284
            //      + pacific.latt.ne 44.24.199.34     3 u  243  256  377   41.457 - 8.929   8.497
            //
            // For manager nodes, we're simply going to verify that we have at least one external 
            // time source answering.

            server.Status = "checking: NTP";

            using (var reader = server.SudoCommand("/usr/bin/ntpq -p", RunOption.LogOutput).OutputReader())
            {
                string line;

                // Column header and table bar lines.

                line = reader.ReadLine();
                if (string.IsNullOrWhiteSpace(line))
                {
                    server.Fault("NTP: Invalid [ntpq -p] response.");
                    return;
                }

                line = reader.ReadLine();
                if (string.IsNullOrWhiteSpace(line) || line[0] != '=')
                {
                    server.Fault("NTP: Invalid [ntpq -p] response.");
                    return;
                }

                // Count the lines starting that don't include [LOCAL(0).LOCL.], 
                // the local clock.

                var sourceCount = 0;

                for (line = reader.ReadLine(); line != null; line = reader.ReadLine())
                {
                    if (line.Length > 0 && !line.Contains(".LOCL."))
                    {
                        sourceCount++;
                    }
                }

                if (sourceCount == 0)
                {
                    server.Fault("NTP: No external sources are answering.");
                    return;
                }
            }
        }

        /// <summary>
        /// Verifies that a worker node's NTP health.
        /// </summary>
        /// <param name="server">The manager node.</param>
        /// <param name="clusterDefinition">The cluster definition.</param>
        private static void CheckWorkerNtp(NodeManagementProxy<NodeDefinition> server, ClusterDefinition clusterDefinition)
        {
            // We're going to use [ntpq -p] to query the configured time sources.
            // We should get something back that looks like
            //
            //           remote           refid      st t when poll reach   delay   offset  jitter
            //           ==============================================================================
            //            LOCAL(0).LOCL.          10 l  45m   64    0    0.000    0.000   0.000
            //           * 10.0.1.5        198.60.22.240    2 u  111  128  377    0.062    3.409   0.608
            //           + 10.0.1.7        198.60.22.240    2 u  111  128  377    0.062    3.409   0.608
            //           + 10.0.1.7        198.60.22.240    2 u  111  128  377    0.062    3.409   0.608
            //
            //
            // For worker nodes, we need to verify that each of the managers are answering
            // by confirming that their IP addresses are present.

            server.Status = "checking: NTP";

            var output = server.SudoCommand("/usr/bin/ntpq -p", RunOption.LogOutput).Output;

            foreach (var manager in clusterDefinition.SortedManagers)
            {
                if (!output.Contains(manager.Address.ToString()))
                {
                    server.Fault($"NTP: Manager [{manager.Name}/{manager.Address}] is not answering.");
                }
            }
        }

        /// <summary>
        /// Verifies Docker health.
        /// </summary>
        /// <param name="server">The server.</param>
        /// <param name="clusterDefinition">The cluster definition.</param>
        private static void CheckDocker(NodeManagementProxy<NodeDefinition> server, ClusterDefinition clusterDefinition)
        {
            server.Status = "checking: Docker";

            using (var docker = new DockerSettings(server.Metadata.Address, clusterDefinition.Docker.Port).CreateClient())
            {
                if (!docker.PingAsync().Result)
                {
                    server.Fault("Docker engine not ready");
                }
            }
        }

        /// <summary>
        /// Verifies TDAgent health on the host machines.
        /// </summary>
        /// <param name="server">The server.</param>
        /// <param name="clusterDefinition">The cluster definition.</param>
        private static void CheckHostTDAgent(NodeManagementProxy<NodeDefinition> server, ClusterDefinition clusterDefinition)
        {
            if (!clusterDefinition.Log.Enabled)
            {
                return;
            }

            server.Status = "checking: host [td-agent]";

            // We're simply going to submit a couple test events to the HTTP 
            // interface of [td-agent-os] and [td-agent-node] to verify that
            // they are running.

            server.RunCommand($"curl -X POST -d 'json={{\"probe\":\"td-agent-node\"}}' http://{clusterDefinition.Log.TDAgentNodeBindIP}:{clusterDefinition.Log.TDAgentHttpPort}/health-probe");
            server.RunCommand($"curl -X POST -d 'json={{\"probe\":\"td-agent-os\"}}' http://{clusterDefinition.Log.TDAgentOsBindIP}:{clusterDefinition.Log.TDAgentHttpPort}/health-probe");
        }

        /// <summary>
        /// Verifies manager Swarm health.
        /// </summary>
        /// <param name="server">The manager.</param>
        /// <param name="clusterDefinition">The cluster definition.</param>
        private static void CheckSwarmManager(NodeManagementProxy<NodeDefinition> server, ClusterDefinition clusterDefinition)
        {
            server.Status = "checking: Swarm";

            server.Status = "checking: Docker";

            using (var docker = new DockerSettings(server.Metadata.Address, clusterDefinition.Swarm.Port).CreateClient())
            {
                if (!docker.PingAsync().Result)
                {
                    server.Fault("Swarm manager not ready");
                }
            }
        }

        /// <summary>
        /// Verifies manager Weave network health.
        /// </summary>
        /// <param name="server">The manager.</param>
        /// <param name="clusterDefinition">The cluster definition.</param>
        private static void CheckWeaveNetwork(NodeManagementProxy<NodeDefinition> server, ClusterDefinition clusterDefinition)
        {
            if (!clusterDefinition.Weave.Network.Enabled)
            {
                return;
            }

            // Use [weave status] to verify the encryption configuration.  This command
            // will include one of the strings below, depending on whether encryption
            // is enabled:
            //
            //      Encryption: enabled
            //      Encryption: disabled

            server.Status = "checking: Weave encryption";

            var encryptionEnabled = server.SudoCommand("weave status").Output.Contains("Encryption: enabled");

            if (encryptionEnabled != !string.IsNullOrWhiteSpace(clusterDefinition.Weave.Network.EncryptionKey))
            {
                if (encryptionEnabled)
                {
                    server.Fault("Weave network: Encryption is not enabled.");
                }
                else
                {
                    server.Fault("Weave network: Encryption should not be enabled.");
                }

                return;
            }

            // Next, we're going to use the [weave status connections] command to view the
            // network connections.  We should see a connection to every other node in
            // the cluster.  The command output will look something like this:
            //
            //      <- 10.0.1.6:55420        established fastdp 5a:02:ca:e2:33:3e(manage-1)
            //      <- 10.0.1.7:46962        established fastdp fa:f6:72:53:58:32(manage-2)
            //      <- 10.0.1.10:52666       established fastdp e6:3e:cc:05:62:b9(node-0)
            //      <- 10.0.1.11:60304       established fastdp be:3e:42:c9:6c:f9(node-1)

            server.Status = "checking: Weave network";

            var fieldsRegex = new Regex(@"^[^0-9]*(?<address>[^:]+):[^\(]+\((?<node>[^\)]+)\)", RegexOptions.ExplicitCapture | RegexOptions.IgnoreCase);
            var connections = new Dictionary<string, Match>(StringComparer.InvariantCultureIgnoreCase);

            using (var reader = server.SudoCommand("weave status connections").OutputReader())
            {
                foreach (var line in reader.Lines())
                {
                    var match = fieldsRegex.Match(line);

                    if (!match.Success ||
                        !match.Groups["address"].Success ||
                        !match.Groups["node"].Success)
                    {
                        server.Fault("Weave network: Unexpected membership output.");
                        return;
                    }

                    connections.Add(match.Groups["node"].Value, match);
                }
            }

            // Verify that we have a connection to every other node.

            foreach (var node in clusterDefinition.SortedNodes)
            {
                if (node.Name == server.Name)
                {
                    continue; // Ignore ourselves
                }

                Match match;

                if (!connections.TryGetValue(node.Name, out match))
                {
                    server.Fault($"Weave network: No connection to [{node.Name}].");
                    return;
                }

                if (match.Groups["address"].Value != node.Address.ToString())
                {
                    server.Fault($"Weave network: Connection to [{node.Name}] is to address [{match.Groups["address"]} when [{node.Address}] was expected.");
                    return;
                }
            }
        }

        /// <summary>
        /// Verifies manager Weave Flux health.
        /// </summary>
        /// <param name="server">The manager.</param>
        /// <param name="clusterDefinition">The cluster definition.</param>
        private static void CheckWeaveFlux(NodeManagementProxy<NodeDefinition> server, ClusterDefinition clusterDefinition)
        {
            if (!clusterDefinition.Weave.Flux.Enabled)
            {
                return;
            }

            server.Status = "checking: Weave Flux";

            // We're going to use the [fluxctl info] command to view the Flux cluster
            // status.  The command responds with something like: 
            //
            //      HOSTS
            //      10.0.1.5
            //      10.0.1.10
            //      
            //      SERVICES
            //      ...
            //
            // We're going to read lines until we see "HOSTS" and then read lines with
            // host IP addresses up to the blank line.

            var hostAddresses = new HashSet<string>();
            var readingHosts  = false;

            using (var reader = server.SudoCommand("fluxctl info").OutputReader())
            {
                foreach (var line in reader.Lines())
                {
                    if (!readingHosts)
                    {
                        if (line.StartsWith("HOSTS"))
                        {
                            readingHosts = true;
                        }

                        continue;
                    }

                    if (string.IsNullOrWhiteSpace(line))
                    {
                        break;
                    }

                    hostAddresses.Add(line.Trim());
                }
            }

            // Verify that Flux reports the IP address for every node in
            // the cluster definition.

            foreach (var node in clusterDefinition.SortedNodes)
            {
                if (!hostAddresses.Contains(node.Address.ToString()))
                {
                    server.Fault($"Weave Flux: Node [{node.Name}/{node.Address}] is not listed.");
                    return;
                }
            }
        }

        /// <summary>
        /// Verifies manager Weave Scope health.
        /// </summary>
        /// <param name="server">The manager.</param>
        /// <param name="clusterDefinition">The cluster definition.</param>
        private static void CheckWeaveScope(NodeManagementProxy<NodeDefinition> server, ClusterDefinition clusterDefinition)
        {
            if (!clusterDefinition.Weave.Scope.Enabled)
            {
                return;
            }

            server.Status = "checking: Weave Scope";

            // We're simply going to verify that the Scope dashboard endpoint
            // returns some HTML.

            Task.Run(
                async () =>
                {
                    using (var client = new HttpClient())
                    {
                        try
                        {
                            var response = await client.GetAsync($"http://{server.Metadata.Address}:{clusterDefinition.Weave.Scope.Port}");

                            response.EnsureSuccessStatusCode();

                            if (!response.Content.Headers.ContentType.MediaType.Equals("text/html", StringComparison.InvariantCultureIgnoreCase))
                            {
                                server.Fault($"Weave Scope: Unexpected content-type [{response.Content.Headers.ContentType.MediaType}].");
                                return;
                            }
                        }
                        catch (Exception e)
                        {
                            server.Fault($"Weave Scope: {NeonHelper.ExceptionError(e)}");
                            return;
                        }
                    }

                }).Wait();
        }

        /// <summary>
        /// Verifies Consul health.
        /// </summary>
        /// <param name="server">The manager node.</param>
        /// <param name="clusterDefinition">The cluster definition.</param>
        private static void CheckConsul(NodeManagementProxy<NodeDefinition> server, ClusterDefinition clusterDefinition)
        {
            if (!clusterDefinition.Consul.Enabled)
            {
                return;
            }

            server.Status = "checking: Consul";

            // Verify that the daemon is running.

            var output = server.SudoCommand("service consul status", RunOption.LogOutput).Output;

            if (!output.StartsWith("consul start/running"))
            {
                server.Fault($"Consul deamon is not running.");
                return;
            }

            // Verify Consul membership by verifying the names and IP addresses of 
            // every node in the cluster are present and alive.  We're going to use
            // the [consul members] command which returns something like:
            //
            //      Node      Address         Status  Type    Build  Protocol  DC
            //      manage-0  10.0.1.5:8301   alive server    0.6.4  2         seattle
            //      node-0    10.0.1.10:8301  alive client    0.6.4  2         seattle

            var splitRegex = new Regex(@"^(?<node>\S+)(\s+)(?<address>\S+)(\s+)(?<status>\S+)(\s+)(?<type>\S+)(\s+)(?<build>\S+)(\s+)(?<protocol>\S+)(\s+)(?<dc>\S+)$", RegexOptions.ExplicitCapture);
            var members    = new Dictionary<string, Match>(StringComparer.InvariantCultureIgnoreCase);

            using (var reader = server.SudoCommand("consul members").OutputReader())
            {
                var lineNumber = 0;

                foreach (var line in reader.Lines())
                {
                    lineNumber++;

                    if (lineNumber == 1)
                    {
                        continue; // Skip the column headers in the first line.
                    }

                    var match = splitRegex.Match(line);

                    if (!match.Success || 
                        !match.Groups["node"].Success || 
                        !match.Groups["address"].Success || 
                        !match.Groups["status"].Success || 
                        !match.Groups["type"].Success)
                    {
                        server.Fault("Consul: Unexpected membership output.");
                    }

                    members.Add(match.Groups["node"].Value, match);
                }
            }

            foreach (var manager in clusterDefinition.SortedManagers)
            {
                Match match;

                if (!members.TryGetValue(manager.Name, out match))
                {
                    server.Fault($"Consul is not reporting that [{manager.Name}] is a member.");
                    return;
                }

                if (match.Groups["type"].Value != "server")
                {
                    server.Fault($"Consul is reporting that manager [{manager.Name}] is not a server.");
                    return;
                }

                if (match.Groups["status"].Value != "alive")
                {
                    server.Fault($"Consul is reporting that manager [{manager.Name}] is not alive.");
                    return;
                }
            }

            foreach (var worker in clusterDefinition.SortedWorkers)
            {
                Match match;

                if (!members.TryGetValue(worker.Name, out match))
                {
                    server.Fault($"Consul is not reporting that [{worker.Name}] is a member.");
                    return;
                }

                if (match.Groups["type"].Value != "client")
                {
                    server.Fault($"Consul is reporting that worker [{worker.Name}] is not a client.");
                    return;
                }

                if (match.Groups["status"].Value != "alive")
                {
                    server.Fault($"Consul is reporting that worker [{worker.Name}] is not alive.");
                    return;
                }
            }

            // Verify that the Consul web dashboard is running by pining the local endpoint and
            // ensuring it returns some HTML.

            Task.Run(
                async () =>
                {
                    using (var client = new HttpClient())
                    {
                        try
                        {
                            var response = await client.GetAsync($"http://{server.Metadata.Address}:{clusterDefinition.Consul.Port}/ui");

                            response.EnsureSuccessStatusCode();

                            if (!response.Content.Headers.ContentType.MediaType.Equals("text/html", StringComparison.InvariantCultureIgnoreCase))
                            {
                                server.Fault($"Consul Dashboard: Unexpected content-type [{response.Content.Headers.ContentType.MediaType}].");
                                return;
                            }
                        }
                        catch (Exception e)
                        {
                            server.Fault($"Consul Dashboard: {NeonHelper.ExceptionError(e)}");
                            return;
                        }
                    }

                }).Wait();
        }

        /// <summary>
        /// Verifies that Etcd is function properly at the specified location.
        /// </summary>
        /// <param name="url"></param>
        /// <returns><c>true</c> on success.</returns>
        private static bool CheckEtc(string url)
        {
            // This works by setting and then deleting a unique node 
            // named:
            //
            //      /neon/health-check/GUID.

            var options = new EtcdClientOpitions()
            {
                Urls = new string[] { url }
            };

            var client = new EtcdClient(options);

            try
            {
                Task.Run(
                    async () =>
                    {
                        var key = $"/neon/health-check/{Guid.NewGuid()}";

                        var response = await client.CreateNodeAsync(key, "test", 10);

                        if (response.Node.Key != key || response.Node.Value != "test")
                        {
                            throw new Exception();
                        }

                        response = await client.GetNodeAsync(key);

                        if (response.Node.Key != key || response.Node.Value != "test")
                        {
                            throw new Exception();
                        }

                        await client.DeleteNodeAsync(key);
                        return true;

                    }).Wait();

                return true;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Verifies Etcd health for a manager.
        /// </summary>
        /// <param name="server">The manager node.</param>
        /// <param name="clusterDefinition">The cluster definition.</param>
        private static void CheckEtcdManager(NodeManagementProxy<NodeDefinition> server, ClusterDefinition clusterDefinition)
        {
            if (!clusterDefinition.Etcd.Enabled)
            {
                return;
            }

            server.Status = "checking: Etcd";

            // Managers verify that Etcd is running on itself and the other managers.

            foreach (var manager in clusterDefinition.SortedManagers)
            {
                var targetUrl = $"http://{manager.Address}:{clusterDefinition.Etcd.Port}";

                if (!CheckEtc(targetUrl))
                {
                    server.Fault($"Etcd: Unable to contact Etcd at [{targetUrl}].");                    
                }
            }
        }

        /// <summary>
        /// Verifies Etcd health for a worker.
        /// </summary>
        /// <param name="server">The worker node.</param>
        /// <param name="clusterDefinition">The cluster definition.</param>
        private static void CheckEtcdWorker(NodeManagementProxy<NodeDefinition> server, ClusterDefinition clusterDefinition)
        {
            if (!clusterDefinition.Etcd.Enabled)
            {
                return;
            }

            server.Status = "checking: Etcd";

            // Worker verify that Etcd is running on itself and the managers.

            var targetUrl = $"http://{server.Metadata.Address}:{clusterDefinition.Etcd.Port}";

            if (!CheckEtc(targetUrl))
            {
                server.Fault($"Etcd: Unable to contact Etcd at [{targetUrl}].");
            }

            foreach (var manager in clusterDefinition.SortedManagers)
            {
                targetUrl = $"http://{manager.Address}:{clusterDefinition.Etcd.Port}";

                CheckEtc(targetUrl);
            }
        }

        /// <summary>
        /// Verifies Vault health for a node.
        /// </summary>
        /// <param name="server">The node.</param>
        /// <param name="clusterDefinition">The cluster definition.</param>
        private static void CheckVault(NodeManagementProxy<NodeDefinition> server, ClusterDefinition clusterDefinition)
        {
            if (!clusterDefinition.Vault.Enabled)
            {
                return;
            }

            server.Status = "checking: Vault";

            // This is a minimal health test that just verifies that Vault
            // is listening for requests.  We're going to ping the local
            // Vault instance at [/v1/sys/health].
            //
            // Note that this should return a 500 status code with some
            // JSON content.  The reason for this is because we have not
            // yet initialized and unsealed the vault.

            var targetUrl = $"http://{server.Metadata.Address}:{clusterDefinition.Vault.Port}/v1/sys/health?standbycode=200";

            using (var client = new HttpClient())
            {
                try
                {
                    var response = client.GetAsync(targetUrl).Result;

                    if (response.StatusCode != HttpStatusCode.OK && 
                        response.StatusCode != HttpStatusCode.InternalServerError)
                    {
                        server.Fault($"Vault: Unexpected HTTP response status [{(int) response.StatusCode}={response.StatusCode}]");
                        return;
                    }

                    if (!response.Content.Headers.ContentType.MediaType.Equals("application/json", StringComparison.InvariantCultureIgnoreCase))
                    {
                        server.Fault($"Vault: Unexpected content type [{response.Content.Headers.ContentType.MediaType}]");
                        return;
                    }
                }
                catch (Exception e)
                {
                    server.Fault($"Vault: {NeonHelper.ExceptionError(e)}");
                }
            }
        }
    }
}