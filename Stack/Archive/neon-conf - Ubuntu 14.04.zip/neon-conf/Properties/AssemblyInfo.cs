﻿//-----------------------------------------------------------------------------
// FILE:	    AssemblyInfo.cs
// CONTRIBUTOR: Jeff Lill
// COPYRIGHT:	Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.

using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("neon-conf")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration(Neon.Stack.Build.Configuration)]
[assembly: AssemblyCompany(Neon.Stack.Build.Company)]
[assembly: AssemblyProduct(Neon.Stack.Build.Product)]
[assembly: AssemblyCopyright(Neon.Stack.Build.Copyright)]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion(Neon.Stack.Build.Version)]
[assembly: AssemblyFileVersion(Neon.Stack.Build.Version)]

