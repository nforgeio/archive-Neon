#!/bin/bash
#------------------------------------------------------------------------------
# FILE:         setup-vault.sh
# CONTRIBUTOR:  Jeff Lill
# COPYRIGHT:    Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.
#
# NOTE: Variables formatted like $<name> will be expanded by [node-conf]
#       using the [PreprocessReader].
#
# Configures HashiCorp Vault secret server on all cluster nodes.

# Configure Bash strict mode so that the entire script will fail if 
# any of the commands fail.
#
#       http://redsymbol.net/articles/unofficial-bash-strict-mode/

set -euo pipefail

echo
echo "**********************************************" 1>&2
echo "** SETUP-VAULT.SH                           **" 1>&2
echo "**********************************************" 1>&2

# Load the cluster configuration and setup utilities.

. $<load-cluster-config>
. setup-utility.sh

# Ensure that setup is idempotent.

startsetup setup-vault

echo "*** BEGIN: Install Vault" 1>&2

# Install Weave Flux.

if ${NEON_VAULT_ENABLED} ; then

    #--------------------------------------------------------------------------
    # Stop the service if it's running.

    echo "***     Stopping Vault" 1>&2
    unsafeinvoke service vault stop

    #--------------------------------------------------------------------------
    # Download the Vault ZIP file to [/tmp] and then unzip and copy the binary
    # to [/usr/local/bin] and make it executable.

    echo "***     Downloading Vault" 1>&2

    curl -fsSL "${NEON_VAULT_DOWNLOAD}" -o /tmp/vault.zip
    unzip -o /tmp/vault.zip -d /tmp
    rm /tmp/vault.zip

    mv /tmp/vault /usr/local/bin/vault
    chmod 700 /usr/local/bin/vault

    #--------------------------------------------------------------------------
    # IMPORTANT:
    #
    # We need to prevent Vault memory from being swapped out to disk to prevent
    # secrets from appearing unencrypted in the file system (this is also why
    # we're not deploying Vault as a container).

    echo "***     Prevent memory swapping" 1>&2

    setcap cap_ipc_lock=+ep $(readlink -f /usr/local/bin/vault)

    #--------------------------------------------------------------------------
    # Generate the config file.

    echo "***     Generate config" 1>&2

    mkdir -p /etc/vault

    cat <<EOF > /etc/vault/vault.hcl
backend "consul" {

  address         = "${NEON_HOST_IP}:${NEON_CONSUL_PORT}"
  path            = "${NEON_VAULT_CONSUL_PATH}"
  scheme          = "http"
  tls_skip_verify = "true"
}

listener "tcp" {

  address         = "0.0.0.0:${NEON_VAULT_PORT}"
  tls_disable     = "${NEON_VAULT_TLS_DISABLED}"
}
EOF

    #--------------------------------------------------------------------------
    # Generate the Vault server scripts.

    echo "***     Generate server script" 1>&2

    cat <<EOF > /usr/local/bin/vault-server
#!/bin/bash
#------------------------------------------------------------------------------
# Starts Vault in SERVER mode.

. $<load-cluster-config-quiet>

vault server                     \\
    -config=/etc/vault/vault.hcl \\
    -log-level=info
EOF

    chmod 700 /usr/local/bin/vault-server

    #--------------------------------------------------------------------------
    # Generate the Vault Upstart config.

    echo "***     Generate Upstart config" 1>&2

    cat <<EOF > /etc/init/vault.conf
description "Vault server daemon"

start on (filesystem and net-device-up IFACE!=lo)
stop on runlevel [!2345]
limit nofile 524288 1048576
limit nproc 524288 1048576

respawn

kill timeout 20

pre-start script
    mkdir -p /var/log/vault
end script

script
    exec /usr/local/bin/vault-server >> /var/log/vault/vault.log 2>&1
end script

post-start script
end script
EOF

    #--------------------------------------------------------------------------
    # Start the service

    echo "***     Starting Vault" 1>&2

    safeinvoke service vault start

else
    echo "*** Vault is disabled" 1>&2
fi

echo "*** END: Install Vault" 1>&2

# Indicate that the script completed.

endsetup setup-vault


