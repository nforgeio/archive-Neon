#!/bin/bash
#------------------------------------------------------------------------------
# FILE:         setup-node.sh
# CONTRIBUTOR:  Jeff Lill
# COPYRIGHT:    Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.
#
# NOTE: This script must be run under SUDO.
#
# NOTE: Variables formatted like $<name> will be expanded by [node-conf]
#       using the [PreprocessReader].
#
# This script continues the configuration of a node VM by assigning its
# host name and adding it to a Docker cluster.
#
# Note: This should be called after the node has been initialized via
#       a direct call to [setup-prep-node.sh] or after it has been
#       cloned from another initialized node.

# Configure Bash strict mode so that the entire script will fail if 
# any of the commands fail.
#
#       http://redsymbol.net/articles/unofficial-bash-strict-mode/

set -euo pipefail

echo
echo "**********************************************" 1>&2
echo "** SETUP-NODE.SH                            **" 1>&2
echo "**********************************************" 1>&2

# Load the cluster configuration and setup utilities.

. $<load-cluster-config>
. setup-utility.sh

# Ensure that setup is idempotent.

startsetup setup-node

# Configure the host name (note that this assumes that the host name
# was originally configured as "ubuntu").

echo ${NEON_NODE_NAME} > /etc/hostname
sed -i "s/ubuntu/${NEON_NODE_NAME}/g" /etc/hosts

# Update the APT package index and then make sure we have some common packages.

apt-get update -yq

# All Neon servers will be configured for UTC time.

timedatectl set-timezone UTC

# Enable system statistics collection (e.g. Page Faults,...)

sed -i '/^ENABLED="false"/c\ENABLED="true"' /etc/default/sysstat

# Create the [/usr/local/bin/dockerized-service.sh] script.  This simply spins
# in a sleep loop, doing nothing.  The idea is that we'll use this as a
# stub process for Upstart to track while the actual service instance
# is running independently (e.g. as a Docker container).

# $todo(jeff.lill): 
#
# If we wanted to get fancy here, we could have this script poll for status
# of the docker container and exit if it's not running.  This way Upstart
# could try to respawn it automatically.

cat <<EOF > /usr/local/bin/dockerized-service.sh
#!/bin/bash
#------------------------------------------------------------------------------
# FILE:         dockerized-service.sh
# CONTRIBUTOR:  Jeff Lill
# COPYRIGHT:    Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.
#
# This script simply spins in a sleep loop, doing nothing.  The idea is that 
# we'll use this as a stub process for Upstart to track while the actual service
# instance is running independently as a Docker container).
#
# Usage: dockerized-service.sh SERVICENAME

. $<load-cluster-config-quiet>

while true 
do
    sleep 30
done
EOF

chmod 700 /usr/local/bin/dockerized-service.sh

#--------------------------------------------------------------------------
# We need to modify [/etc/default/grub] to avoid a Docker warning:
#
#       WARNING: No swap limit support
#
# We're going to change this line:
#
#       GRUB_CMDLINE_LINUX=""
#
# to:
#
#       GRUB_CMDLINE_LINUX="swapaccount=1" 
#
# NOTE: This will require a reboot to take effect.

sed -i 's!^GRUB_CMDLINE_LINUX=""$!GRUB_CMDLINE_LINUX="swapaccount=1"!g' /etc/default/grub
update-grub

#--------------------------------------------------------------------------
# Edit [/etc/sysctl.conf] on worker nodes so that Linux will avoid swapping
# RAM to disk.

if ! ${NEON_MANAGER} ; then

    if ! grep NeonCloud /etc/sysctl.conf ; then

        cat <<EOF >> /etc/sysctl.conf

###################################################################
# NeonCloud settings

vm.swappiness = 0
EOF
    fi
    
fi

# Indicate that the script completed.

endsetup setup-node
