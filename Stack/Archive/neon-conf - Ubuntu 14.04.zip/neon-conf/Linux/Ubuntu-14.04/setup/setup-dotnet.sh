#!/bin/bash
#------------------------------------------------------------------------------
# FILE:         setup-dotnet.sh
# CONTRIBUTOR:  Jeff Lill
# COPYRIGHT:    Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.
#
# NOTE: This script must be run under SUDO.
#
# NOTE: Variables formatted like $<name> will be expanded by [node-conf]
#       using the [PreprocessReader].
#
# This script handles the installation of the .NET Execution Engines (DNX) for
# for .NET Core.
#
#   http://docs.asp.net/en/latest/getting-started/installing-on-linux.html
#

# Configure Bash strict mode so that the entire script will fail if 
# any of the commands fail.
#
#       http://redsymbol.net/articles/unofficial-bash-strict-mode/

set -euo pipefail

echo
echo "**********************************************" 1>&2
echo "** SETUP-DOTNET.SH                          **" 1>&2
echo "**********************************************" 1>&2

# Load the cluster configuration and setup utilities.

. $<load-cluster-config>
. setup-utility.sh

# Ensure that setup is idempotent.

startsetup setup-dotnet

if ${NEON_DOTNET_ENABLED} ; then

    echo "*** BEGIN: Install Dotnet Core" 1>&2

    # $todo(jeff.lill): .NET Core isn't ready for prime time yet.

    echo "***     .NET Core is not ready for prime time." 1>&2

    echo "*** END: Install Dotnet Core" 1>&2
else
    echo "*** .NET Core installation is disabled" 1>&2
fi

endsetup setup-dotnet
