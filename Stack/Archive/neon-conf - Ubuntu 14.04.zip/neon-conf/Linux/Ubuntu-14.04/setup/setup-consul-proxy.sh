#!/bin/bash
#------------------------------------------------------------------------------
# FILE:         setup-consul.sh
# CONTRIBUTOR:  Jeff Lill
# COPYRIGHT:    Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.
#
# NOTE: Variables formatted like $<name> will be expanded by [node-conf]
#       using the [PreprocessReader].
#
# This script configures [Consul] on a manager node.
#
# Arguments:
#
#       consul-key              - Consul encryption key (or "-" for none)

# Get the encryption key.  Note that we're going to replace "-" 
# arguments values with empty strings because Bash doesn't 
# do empty arguments.

if [ "${1}" == "-" ] ; then
    encryption_key=
else
    encryption_key=${1}
fi

# Configure Bash strict mode so that the entire script will fail if 
# any of the commands fail.
#
#       http://redsymbol.net/articles/unofficial-bash-strict-mode/

set -euo pipefail

echo
echo "**********************************************" 1>&2
echo "** SETUP-CONSUL-PROXY.SH                    **" 1>&2
echo "**********************************************" 1>&2

# Load the cluster configuration and setup utilities.

. $<load-cluster-config>
. setup-utility.sh

# Ensure that setup is idempotent.

startsetup setup-consul-proxy

if ${NEON_CONSUL_ENABLED} ; then

    #--------------------------------------------------------------------------
    # Stop the service if it's running.

    echo "***     Stopping Consul" 1>&2
    unsafeinvoke service consul stop

    #--------------------------------------------------------------------------
    # Download the Consul bits.

    curl -fsSL https://releases.hashicorp.com/consul/${NEON_CONSUL_VERSION}/consul_${NEON_CONSUL_VERSION}_linux_amd64.zip -o /tmp/consul.zip
    unzip -u /tmp/consul.zip -d /tmp
    cp /tmp/consul /usr/local/bin
    chmod 700 /usr/local/bin/consul

    rm /tmp/consul.zip
    rm /tmp/consul

    #--------------------------------------------------------------------------
    # Generate the Consul configuration file.

    echo "*** Generating Consul configuration file" 1>&2

    mkdir -p /etc/consul.d

    cat <<EOF > /etc/consul.d/consul.json 
{
    "skip_leave_on_interrupt": true,
    "leave_on_terminate": false
}
EOF

    #--------------------------------------------------------------------------
    # Make sure the data folder exists.

    mkdir -p /var/consul-data

    #--------------------------------------------------------------------------
    # Configure Consul encryption.

    if [ "${encryption_key}" != "" ] ; then

        echo "${encryption_key}" > ${NEON_SECRETS_FOLDER}/consul.key
        chmod 600 ${NEON_SECRETS_FOLDER}/consul.key

        encrypt_option="-encrypt \$(cat ${NEON_SECRETS_FOLDER}/consul.key)"
    else
        encrypt_option=""
    fi

    #--------------------------------------------------------------------------
    # Generate a script to start Consul in PROXY mode.

    echo "*** Generating Consul Proxy script" 1>&2

    cat <<EOF > /usr/local/bin/consul-proxy 
#!/bin/bash
#------------------------------------------------------------------------------
# Starts Consul in PROXY mode.

. $<load-cluster-config-quiet>

consul agent                       \\
    -client=0.0.0.0                \\
    -config-dir /etc/consul.d      \\
    -data-dir=/var/consul-data     \\
    -node=${NEON_NODE_NAME}        \\
    -bind=${NEON_HOST_IP}          \\
    -http-port=${NEON_CONSUL_PORT} \\
    -config-dir=/etc/consul.d      \\
    ${encrypt_option}              \\
    ${NEON_CONSUL_OPTIONS}         \\
    -ui                            \\
    -dc=${NEON_DATACENTER}
EOF

    chmod 700 /usr/local/bin/consul-proxy
    mkdir -p /etc/consul.d

    #--------------------------------------------------------------------------
    # Generate the Upstart Consul configuration file (PROXY mode).

    echo "*** Generating Consul Proxy Upstart config" 1>&2

    cat <<EOF > /etc/init/consul.conf 
description "Consul proxy daemon"

start on (filesystem and net-device-up IFACE!=lo)
stop on (runlevel [!2345] and stopped docker)
limit nofile 524288 1048576
limit nproc 524288 1048576

respawn

kill timeout 20

pre-start script
    mkdir -p /var/log/consul
end script

script
    exec /usr/local/bin/consul-proxy >> /var/log/consul/consul.log 2>&1
end script

post-start script
end script
EOF

    #--------------------------------------------------------------------------
    # Start the Consul service.

    echo "*** Starting Consul service" 1>&2
    safeinvoke service consul start

else
    echo "*** Consul-Proxy installation is disabled" 1>&2
fi

# Indicate that the script completed.

endsetup setup-consul-proxy
