#------------------------------------------------------------------------------
# FILE:         setup-network.sh
# CONTRIBUTOR:  Jeff Lill
# COPYRIGHT:    Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.
#
# NOTE: Variables formatted like $<name> will be expanded by [node-conf]
#       using the [PreprocessReader].
#
# Configures cluster networking.
#
# Arguments:
#
#       encryption-key  - a 16-byte Base64 encryption key or "-"

# Get the encryption key.  Note that we're going to replace "-" 
# arguments values with empty strings because Bash doesn't 
# do empty arguments.

if [ "${1}" == "-" ] ; then
    encryption_key=
else
    encryption_key=${1}
fi

# Configure Bash strict mode so that the entire script will fail if 
# any of the commands fail.
#
#       http://redsymbol.net/articles/unofficial-bash-strict-mode/

set -euo pipefail

echo
echo "**********************************************" 1>&2
echo "** SETUP-NETWORK.SH                         **" 1>&2
echo "**********************************************" 1>&2

# Load the cluster configuration and setup utilities.

. $<load-cluster-config>
. setup-utility.sh

# Ensure that setup is idempotent.

startsetup setup-network

# Configure Weave Networking.

if ${NEON_WEAVE_NET_ENABLED} ; then

    echo "*** BEGIN: Install Weave Network" 1>&2

    #--------------------------------------------------------------------------
    # Download Weave

    echo "***     Downloading Weave v${NEON_WEAVE_NET_VERSION}" 1>&2

    curl -fsSL https://github.com/weaveworks/weave/releases/download/v${NEON_WEAVE_NET_VERSION}/weave -o /usr/local/bin/weave
    verifyscript /usr/local/bin/weave
    chmod 700 /usr/local/bin/weave

    #--------------------------------------------------------------------------
    # Append network related variables to the environment.  We'll need these when
    # we're using the Weave Docker plugin.

    echo "***     Setting environment" 1>&2

    echo "NEON_NET_ARGS=--net=weave $(weave dns-args)" >> /etc/environment
    echo "NEON_NET_DNSSEARCH=${NEON_NETWORK_DNSDOMAIN}." >> /etc/environment

    dns_address=`echo $(weave dns-args) | egrep -o -e "[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}"`
    echo "NEON_NET_DNS=${dns_address}" >> /etc/environment

    #--------------------------------------------------------------------------
    # Configure Weave network encryption.

    echo "***     Configuring encryption" 1>&2

    if [ "${encryption_key}" != "" ] ; then

        encrypt_option="--password \${encryption_key}"
    else
        encrypt_option=""
    fi

    #--------------------------------------------------------------------------
    # Install: Weave router.
    #
    #   * We're going to have each manager peer with the other managers and
    #     set the consensus required to the number of managers.
    #
    #   * Worker nodes will be configured as observers.

    echo "***     Install Weave Router" 1>&2

    if ${NEON_MANAGER} ; then

        weave_peers=${NEON_MANAGER_PEERS[@]}
        ipalloc_init="--ipalloc-init consensus=${NEON_MANAGER_COUNT}"
    else

        weave_peers=${NEON_MANAGER_ADDRESSES[@]}
        ipalloc_init="--ipalloc-init observer"
    fi

    weave launch-router --ipalloc-range ${NEON_WEAVE_NET_SUBNET} ${encrypt_option} --dns-domain ${NEON_NETWORK_DNSDOMAIN} ${ipalloc_init} ${weave_peers}

    #--------------------------------------------------------------------------
    # Install: Weaveproxy.

    echo "***     Installing Weave Proxy" 1>&2

    weave launch-proxy -H ${NEON_HOST_IP}:${NEON_WEAVE_NET_PROXY_PORT}

    #--------------------------------------------------------------------------
    # Install: Weave network plugin.

    echo "***     Installing Weave Plugin" 1>&2
    weave launch-plugin

    #------------------------------------------------------------------------------
    # Create the [/usr/local/bin/docker-weave] utility script that runs a Docker CLI 
    # command against the Weave API proxy.

    cat <<EOF > /usr/local/bin/docker-weave
#!/bin/bash
#------------------------------------------------------------------------------
# FILE:         docker-weave
# CONTRIBUTOR:  Jeff Lill
# COPYRIGHT:    Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.
#
# This script runs a Docker CLI command against the local Weave API proxy.
#
# Usage: docker-weave DOCKER-COMMAND ARGS...

. $<load-cluster-config-quiet>

docker -H \${NEON_HOST_IP}:\${NEON_WEAVE_NET_PROXY_PORT} \$@
EOF

chown :docker /usr/local/bin/docker-weave
chmod 770 /usr/local/bin/docker-weave

    #--------------------------------------------------------------------------

    echo "*** END: Install Weave Network" 1>&2
else

    echo "*** BEGIN: Default network configuration" 1>&2

    #--------------------------------------------------------------------------
    # Append network related variables to the environment.  We'll need these when
    # we're using the Weave Docker plugin.

    echo "***     Setting environment" 1>&2

    echo "NEON_NET_ARGS=--net=${NEON_NETWORK_NAME}" >> /etc/environment
    echo "NEON_NET_DNSSEARCH=${NEON_NETWORK_DNSDOMAIN}." >> /etc/environment
    echo "NEON_NET_DNS=${NEON_NETWORK_OVERLAYDNS}" >> /etc/environment

    echo "*** END: Default network configuration" 1>&2
fi

# Indicate that the script completed.

endsetup setup-network
