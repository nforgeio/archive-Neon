#!/bin/bash
#------------------------------------------------------------------------------
# FILE:         setup-etcd-proxy.sh
# CONTRIBUTOR:  Jeff Lill
# COPYRIGHT:    Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.
#
# NOTE: Variables formatted like $<name> will be expanded by [node-conf]
#       using the [PreprocessReader].
#
# This script configures [Etcd-Proxy] on a worker node.
#
# Etcd will be deployed as a swarm container constrained to the current host.  We'll
# be deploying the [neoncloud/etcd:<version>] image.  The proxy will be configured 
# with references to each of the manager [Etcd] instances.

# Configure Bash strict mode so that the entire script will fail if 
# any of the commands fail.
#
#       http://redsymbol.net/articles/unofficial-bash-strict-mode/

set -euo pipefail

echo
echo "**********************************************" 1>&2
echo "** SETUP-ETCD-PROXY.SH                      **" 1>&2
echo "**********************************************" 1>&2

# Load the cluster configuration and setup utilities.

. $<load-cluster-config>
. setup-utility.sh

# Ensure that setup is idempotent.

startsetup setup-etcd-proxy

# Configure Etcd.

if ${NEON_ETCD_ENABLED} ; then

    echo "*** BEGIN: Install Etcd-Proxy" 1>&2

    #--------------------------------------------------------------------------
    # Stop and remove [etcd-proxy] container if it's present.
    
    echo "***     Stopping [etcd]" 1>&2
    unsafeinvoke docker stop etcd 
    unsafeinvoke docker rm etcd 

    #--------------------------------------------------------------------------
    # Generate the arguments we'll need to pass to Etcd.

    echo "***     Generating Etcd proxy parameters" 1>&2

    listen_client_urls="http://0.0.0.0:${NEON_ETCD_PORT}"

    initial_cluster=""
    index=0

    for item in "${NEON_MANAGER_NAMES[@]}"
    do
        if (( index > 0 )) ; then
            initial_cluster="${initial_cluster},"
        fi

        node_name=${NEON_MANAGER_NAMES[${index}]}
        node_address=${NEON_MANAGER_ADDRESSES[${index}]}
        node_url=${node_name}=http://${node_address}:${NEON_ETCD_PEER_PORT}
        initial_cluster=${initial_cluster}${node_url}
        (( index += 1 ))
    done

    #--------------------------------------------------------------------------
    echo "***     listen_client_urls = ${listen_client_urls}" 1>&2
    echo "***     initial_cluster    = ${initial_cluster}"    1>&2

    #--------------------------------------------------------------------------
    # Start the [etcd-proxy] container.

    echo "***     Starting the Etcd-Proxy container" 1>&2

    docker run -d                                      \
        --restart=always                               \
        --name=etcd-proxy                              \
        -p ${NEON_ETCD_PORT}:${NEON_ETCD_PORT}         \
        neoncloud/etcd:${NEON_ETCD_VERSION}            \
            -proxy on                                  \
            --name ${NEON_NODE_NAME}                   \
            --listen-client-urls ${listen_client_urls} \
            --initial-cluster ${initial_cluster} > /dev/null

    echo "*** END: Install Etcd-Proxy" 1>&2

else
    echo "*** Etcd-Proxy installation is disabled" 1>&2
fi

# Indicate that the script completed.

endsetup setup-etcd-proxy
