#------------------------------------------------------------------------------
# FILE:         setup-weave-scope.sh
# CONTRIBUTOR:  Jeff Lill
# COPYRIGHT:    Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.
#
# NOTE: Variables formatted like $<name> will be expanded by [node-conf]
#       using the [PreprocessReader].
#
# Configures Weave Scope.

# Configure Bash strict mode so that the entire script will fail if 
# any of the commands fail.
#
#       http://redsymbol.net/articles/unofficial-bash-strict-mode/

set -euo pipefail

echo
echo "**********************************************" 1>&2
echo "** SETUP-WEAVE-SCOPE.SH                     **" 1>&2
echo "**********************************************" 1>&2

# Load the cluster configuration and setup utilities.

. $<load-cluster-config>
. setup-utility.sh

# Ensure that setup is idempotent.

startsetup setup-weave-scope

# Configure Weave Scope.

if ${NEON_WEAVE_SCOPE_ENABLED} ; then

    #--------------------------------------------------------------------------
    # Stop the service if it's running.

    echo "***     Stopping Weave Scope" 1>&2
    unsafeinvoke service weave-scope stop
    unsafeinvoke docker stop neon.weave-scope 
    unsafeinvoke docker rm neon.weave-scope 

    #--------------------------------------------------------------------------
    # Install Weave Scope.

    echo "*** BEGIN: Installing Weave Scope" 1>&2

    curl -fsSL https://github.com/weaveworks/scope/releases/download/v${NEON_WEAVE_SCOPE_VERSION}/scope -o /usr/local/bin/scope
    verifyscript /usr/local/bin/scope
    chmod 700 /usr/local/bin/scope

    #--------------------------------------------------------------------------
    # Generate the Weave Scope Upstart config.

    if ${NEON_MANAGER} ; then

        # Manager nodes send Scope reports to the other managers.

        weave_peers=${NEON_MANAGER_PEERS[@]}
    else

        # Worker nodes send Scope reports to all managers.

        weave_peers=${NEON_MANAGER_ADDRESSES[@]}
    fi

    echo "***     Generating Weave Scope Upstart config" 1>&2

    cat <<EOF > /etc/init/weave-scope.conf 
description "Weave Scope daemon"

start on started docker
stop on stopping docker
limit nofile 524288 1048576
limit nproc 524288 1048576

kill timeout 20

pre-start script
    mkdir -p /var/log/weave
end script

script
    exec /usr/local/bin/dockerized-service.sh weave-scope
end script

post-start script
    echo "Starting: weave-scope" >> /var/log/weave/weave-scope.log
    /usr/local/bin/scope launch ${weave_peers} >> /var/log/weave/weave-scope.log 2>&1
end script

pre-stop script
    echo "Stopping: weave-scope" >> /var/log/weave/weave-scope.log
    /usr/local/bin/scope stop >> /var/log/weave/weave-scope.log 2>&1
end script
EOF

    #--------------------------------------------------------------------------
    # Start Scope

    echo "***     Starting Weave Scope" 1>&2
    safeinvoke service weave-scope start

    echo "*** END: Installing Weave Scope" 1>&2
else
    echo "*** Weave Scope is disabled" 1>&2
fi

# Indicate that the script completed.

endsetup setup-weave-scope
