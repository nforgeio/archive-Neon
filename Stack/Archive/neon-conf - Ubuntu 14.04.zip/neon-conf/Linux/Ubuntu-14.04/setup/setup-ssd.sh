#!/bin/bash
#------------------------------------------------------------------------------
# FILE:         setup-ssd.sh
# CONTRIBUTOR:  Jeff Lill
# COPYRIGHT:    Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.
#
# NOTE: This script must be run under SUDO.
#
# NOTE: Variables formatted like $<name> will be expanded by [node-conf]
#       using the [PreprocessReader].

# Configure Bash strict mode so that the entire script will fail if 
# any of the commands fail.
#
#       http://redsymbol.net/articles/unofficial-bash-strict-mode/

set -euo pipefail

echo
echo "**********************************************" 1>&2
echo "** SETUP-SSD.SH                             **" 1>&2
echo "**********************************************" 1>&2

# Load the cluster configuration and setup utilities.

. $<load-cluster-config>
. setup-utility.sh

# Ensure that setup is idempotent.

startsetup setup-ssd

if ${NEON_HOST_SSD} ; then

    echo "*** BEGIN: Tuning for SSD" 1>&2

    # This script works by generating the [/usr/local/tune-ssd.sh] script so that it
    # configures up to 8 [sd?] devices to:
    #
    #       * Use the [noop] scheduler
    #       * Indicate that the device does not rotate
    #       * Sets the read-ahead value
    #
    # Then the script modifies [/etc/rc.local] to execute the script during
    # system boot.

    read_ahead_size_kb=64

    # Generate [/usr/local/bin/tune-ssd.sh]

    rm -f /usr/local/bin/tune-ssd.sh

    echo "# This script is generated during setup by [setup-ssd.sh] to"                 > /usr/local/bin/tune-ssd.sh
    echo "# execute the commands necessary to properly tune any attached"              >> /usr/local/bin/tune-ssd.sh
    echo "# SSDs.  This will be called by [/etc/rc.local] during boot."                >> /usr/local/bin/tune-ssd.sh

    for DEVICE in sda sdb sdc sde sdf sdg sdh sdi
    do
        if [ -d /sys/block/$DEVICE ]; then
            echo " "                                                                   >> /usr/local/bin/tune-ssd.sh
            echo "# DEVICE: $DEVICE"                                                   >> /usr/local/bin/tune-ssd.sh
            echo "# ---------------"                                                   >> /usr/local/bin/tune-ssd.sh
            echo "echo noop > /sys/block/$DEVICE/queue/scheduler"                      >> /usr/local/bin/tune-ssd.sh
            echo "echo 0 > /sys/block/$DEVICE/queue/rotational"                        >> /usr/local/bin/tune-ssd.sh
            echo "echo ${read_ahead_size_kb} > /sys/block/$DEVICE/queue/read_ahead_kb" >> /usr/local/bin/tune-ssd.sh
        fi
    done

    chmod 700 /usr/local/bin/tune-ssd.sh

    # Modify [/etc/rc.local] if it doesn't already include a call to [tune-ssd.sh].

    if ! grep -q tune-ssd.sh /etc/rc.local ; then

        sed -i "s!^exit 0!/usr/local/bin/tune-ssd.sh!g" /etc/rc.local
        echo "exit 0" >> /etc/rc.local
    fi

    # Call the generated SSD optimization script to apply the changes to the 
    # current session.

    /usr/local/bin/tune-ssd.sh

    echo "*** END: Tuning for SSD" 1>&2
else
    echo "*** SSD tuning is disabled" 1>&2
fi

# Indicate that the script completed.

endsetup setup-ssd
