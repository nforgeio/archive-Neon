#!/bin/bash
#------------------------------------------------------------------------------
# FILE:         setup-swarm-manager.sh
# CONTRIBUTOR:  Jeff Lill
# COPYRIGHT:    Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.
#
# NOTE: This script must be run under SUDO.
#
# This script handles the configuration of a Docker Swarm Manager on a 
# Neon manager node.

# Configure Bash strict mode so that the entire script will fail if 
# any of the commands fail.
#
#       http://redsymbol.net/articles/unofficial-bash-strict-mode/

set -euo pipefail

echo
echo "**********************************************" 1>&2
echo "** SETUP-SWARM-MANAGER.SH                   **" 1>&2
echo "**********************************************" 1>&2

# Load the cluster configuration and setup utilities.

. $<load-cluster-config>
. setup-utility.sh

# Ensure that setup is idempotent.

startsetup setup-swarm-manager

#--------------------------------------------------------------------------
# Stop the service if it's running.

echo "***     Stopping Swarm Manager" 1>&2
unsafeinvoke docker stop swarm-manager 
unsafeinvoke docker rm swarm-manager

#------------------------------------------------------------------------------
# Configure the Docker Swarm Manager service.

echo "*** Generate Swarm Manager scripts" 1>&2

cat <<EOF > /usr/local/bin/swarm-manager 
#!/bin/bash
#------------------------------------------------------------------------------
# Starts the Docker Swarm manager.

. $<load-cluster-config-quiet>

docker run -d                                                      \\
    --name swarm-manager                                           \\
    --restart always                                               \\
    -p ${NEON_SWARM_MANAGER_PORT}:${NEON_SWARM_MANAGER_PORT}       \\
    swarm:${NEON_SWARM_VERSION}                                    \\
        manage                                                     \\
            -H :${NEON_SWARM_MANAGER_PORT}                         \\
            --replication                                          \\
            --advertise ${NEON_HOST_IP}:${NEON_SWARM_MANAGER_PORT} \\
            ${NEON_SWARM_OPTIONS}                                  \\
            ${NEON_SWARM_DISCOVERY}
EOF

chmod 700 /usr/local/bin/swarm-manager

# Start the Swarm manager.

echo "*** Starting Swarm-manager" 1>&2
safeinvoke swarm-manager

#------------------------------------------------------------------------------
# Create the [/usr/local/bin/docker-swarm] utility script that runs a Docker CLI 
# command against the local Swarm manager for manager nodes or against
# the first manager node for worker nodes.

cat <<EOF > /usr/local/bin/docker-swarm
#!/bin/bash
#------------------------------------------------------------------------------
# FILE:         docker-swarm
# CONTRIBUTOR:  Jeff Lill
# COPYRIGHT:    Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.
#
# This script runs a Docker CLI command against the local Swarm manager for
# manager nodes or on the first manager node for worker nodes.
#
# Usage: docker-swarm DOCKER-COMMAND ARGS...

. $<load-cluster-config-quiet>

if ${NEON_MANAGER} ; then
    manager_address=:${NEON_SWARM_MANAGER_PORT}
else
    manager_address=${NEON_MANAGER_ADDRESSES[0]}:${NEON_SWARM_MANAGER_PORT}
fi

docker -H \${manager_address} \$@
EOF

chown :docker /usr/local/bin/docker-swarm
chmod 770 /usr/local/bin/docker-swarm

# Indicate that the script completed.

endsetup setup-swarm-manager
