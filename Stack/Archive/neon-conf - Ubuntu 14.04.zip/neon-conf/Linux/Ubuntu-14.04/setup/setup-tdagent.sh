#!/bin/bash
#------------------------------------------------------------------------------
# FILE:         setup-tdagent.sh
# CONTRIBUTOR:  Jeff Lill
# COPYRIGHT:    Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.
#
# NOTE: Variables formatted like $<name> will be expanded by [node-conf]
#       using the [PreprocessReader].
#
# This script configures the Treasure Data agents that collect events
# from the local node and forward them on to the Neon logging pipeline.
#
# It installs the [td-agent-os] instance which runs as an Upstart
# deamon.  This is responsible for collecting host level events and
# system statistics.
#
# The script also deploys the [td-agent-node] container.  This is
# responsible for forwarding events on to the the Neon logging
# pipeline.  [td-agent-os] will be configured to forward events
# here as will Docker, for the local container logs.

# Configure Bash strict mode so that the entire script will fail if 
# any of the commands fail.
#
#       http://redsymbol.net/articles/unofficial-bash-strict-mode/

set -euo pipefail

echo
echo "**********************************************" 1>&2
echo "** SETUP-TDAGENT.SH                         **" 1>&2
echo "**********************************************" 1>&2

# Load the cluster configuration and setup utilities.

. $<load-cluster-config>
. setup-utility.sh

# Ensure that setup is idempotent.

startsetup setup-tdagent

if ${NEON_LOG_ENABLED} ; then

    echo "*** BEGIN: Install TD-AGENT" 1>&2

    #--------------------------------------------------------------------------
    # Install the [td-agent-os]

    echo "***     Installing [td-agent-os]" 1>&2

    curl -fsSL https://toolbelt.treasuredata.com/sh/install-ubuntu-trusty-td-agent${NEON_LOG_TDAGENT_OSVERSION}.sh | sh

    #--------------------------------------------------------------------------
    # Generate the [td-agent-os] config file and restart.

    echo "***     Configuring [td-agent-os]" 1>&2
    
    cat <<EOF > /etc/td-agent/td-agent.conf
#------------------------------------------------------------------------------
# Configures the [td-agent-os] instance to capture events from local system
# log files and forward these on to the local [td-agent-node] container.

#------------------------------------------------------------------------------
# Network listeners:
#
# It appears that TD-AGENT will open the standard TCP/UDP and HTTP listeners 
# even if no source sections for these are specified.  This will cause about
# port conflict with the [td-agent-node].  We're going to workaround This
# by binding the [td-agent-os] and [td-agent-node] to different local IPs.

<source>    
    type forward
    bind ${NEON_LOG_TDAGENT_OS_BIND_IP}
    port ${NEON_LOG_TDAGENT_FORWARD_PORT}
</source>

<source>    
    type http
    bind ${NEON_LOG_TDAGENT_OS_BIND_IP}
    port ${NEON_LOG_TDAGENT_HTTP_PORT}
</source>

# Test Script: Run this command to submit a test event.
#
# curl -X POST -d 'json={"action":"*** test ***"}' http://${NEON_LOG_TDAGENT_OS_BIND_IP}:${NEON_LOG_TDAGENT_HTTP_PORT}/test

#------------------------------------------------------------------------------
# Tail the Docker container logs.  Docker stores container information at
# [/var/lib/docker/containers/CONTAINER-ID] where CONTAINER-ID is ID for 
# each container.  The container log file is JSON formatted and will be
# named [CONTAINER-ID-json.log] within the folders.
#
# The rules below tail these files adds the [docker.container_id] property.
# 
# \$todo(jeff.lill):
#
# This isn't really what we need.  I'm probably going to have to write
# my own plugin.  I glanced at the code for [docker-tag-resolver]:
#
#       https://github.com/Dataman-Cloud/fluent-plugin-docker-tag-resolver
#
# It looked initially like it might work, but it doesn't tag events 
# in a usable form.  The problem is that any dots in container images,
# tags, names, and IDs will throw this off.  I'll probably need to
# munge this plugin in to replace periods in these fields with something
# else, or just add the new fields.
#
# I don't really know Ruby, but it  looks like this code queries Docker
# for all containers for each event processed: there's no caching.  This
# won't scale very well.
#
# I think I also want the events to be tagged with something like:
#
#       IMAGENAME:TAG
#
# so that [neon.log-collector] can be configured to correctly 
# parse events as they stream through.
#
# It looks like plugin development isn't too bad:
#
#       http://docs.fluentd.org/articles/plugin-development#filter-plugins

<source>
    type tail
    path /var/lib/docker/containers/*/*-json.log
    pos_file /var/log/td-agent/docker.pos
    time_format %Y-%m-%dT%H:%M:%S 
    tag docker.*
    format json
</source>

<filter docker.var.lib.docker.containers.*.*.log>
    type record_transformer
    <record>
        docker.container_id $\tag_parts[5]
    </record>
</filter>

#------------------------------------------------------------------------------
# Consul logs

<source>
    type tail
    path /var/log/consul/consul.log
    pos_file /var/log/td-agent/consul.log.pos
    tag neon.consul
    format /[ ]+(?<time>\d\d\d\d/\d\d/\d\d \d\d:\d\d:\d\d) \[(?<level>.*)\] (?<message>.*)$/
    time_format %Y/%m/%d %H:%M:%S
</source>

#------------------------------------------------------------------------------
# Augment all log events with information about the current node
# and cluster.

<filter **>
    type record_transformer
    <record>
        neon.datacenter "${NEON_DATACENTER}"
        neon.cluster "${NEON_CLUSTER}"
        neon.environment "${NEON_ENVIRONMENT}"
        neon.node "${NEON_NODE_NAME}"
        neon.nodeip "${NEON_HOST_IP}"
        neon.manager "${NEON_MANAGER}"
    </record>
</filter>

#------------------------------------------------------------------------------
# Forward all log events to the [td-agent-node] running in a container to have 
# it forward events on to the cluster aggregators.  The reason for this indirection
# is that [td-agent-node] will be running within the Weave network and/or Flux
# (if these are enabled) so the cluster aggregators can be dynamically 
# provisioned and load balanced.

<match **>
    type forward
    send_timeout 60s
    recover_wait 10s
    heartbeat_interval 1s
    phi_threshold 16
    hard_timeout 60s

    <server>
        name td-agent-node
        host ${NEON_LOG_TDAGENT_NODE_BIND_IP}
        port ${NEON_LOG_TDAGENT_FORWARD_PORT}
        weight 60
    </server>
</match>

#------------------------------------------------------------------------------
# Send to [/var/log/td-agent/trace.log] for testing.

<match **>
    type file
    path /var/log/td-agent/trace.log
    append true
    format json
    buffer_type memory
    flush_interval 1s
</match>
EOF

    cat <<EOF > /etc/default/td-agent
# Default TD-AGENT options.

TD_AGENT_OPTIONS=""
EOF

    echo "***     Restarting [td-agent-os]" 1>&2

    unsafeinvoke service td-agent restart

    #--------------------------------------------------------------------------
    # Generate the [/etc/neon-stack/td-agent-node] folder and config files.

    echo "***     Configuring [td-agent-node]" 1>&2
    
    mkdir -p /etc/neoncloud/td-agent-node
    mkdir -p /etc/neoncloud/td-agent-node/plugin

    cat <<EOF > /etc/neoncloud/td-agent-node/td-agent.conf
#------------------------------------------------------------------------------
# Configures the [td-agent-node] container to forward events to the cluster 
# level log aggregator after augmenting them with datacenter and node details.

#------------------------------------------------------------------------------
# Network listeners
#
# Note that the container only needs to accept local traffic from the [td-agent-os].

<source>    
    type forward
    port ${NEON_LOG_TDAGENT_FORWARD_PORT}
    bind 0.0.0.0
    port ${NEON_LOG_TDAGENT_FORWARD_PORT}
</source>

<source>    
    type http
    port ${NEON_LOG_TDAGENT_HTTP_PORT}
    bind 0.0.0.0
    port ${NEON_LOG_TDAGENT_HTTP_PORT}
</source>

# Test Script: Run this command on the host to submit a test event.
#
# curl -X POST -d 'json={"action":"*** test ***"}' http://${NEON_LOG_TDAGENT_NODE_BIND_IP}:${NEON_LOG_TDAGENT_HTTP_PORT}/test

#------------------------------------------------------------------------------
# Send to [/var/log/td-agent/trace.log] for testing.

<match **>
    type file
    path /var/log/td-agent/trace.log
    append true
    format json
    buffer_type memory
    flush_interval 1s
</match>
EOF

    #--------------------------------------------------------------------------
    # Start the [td-agent-node] container.
    #
    # Note that we're mapping the following host volumes:
    #
    #   /etc/neoncloud/td-agent-node    --> /etc/td-agent (read-only)
    #   -------------------------------------------------
    #   This is where the container will pick up its configuration.
    #
    #   /var/log/td-agent-node --> /var/log/td-agent
    #   --------------------------------------------
    #   We're going to map the TD-AGENT log folder in the container
    #   to the a host log folder so operators can manually examine
    #   these logs and so we can also configure log rotation.

    mkdir -p /var/log/td-agent-node

    echo "***     Run [td-agent-node] container" 1>&2
    
    docker run -d                                                                                                 \
        --restart=always                                                                                          \
        --name=td-agent-${NEON_NODE_NAME}                                                                         \
        -p ${NEON_LOG_TDAGENT_NODE_BIND_IP}:${NEON_LOG_TDAGENT_FORWARD_PORT}:${NEON_LOG_TDAGENT_FORWARD_PORT}     \
        -p ${NEON_LOG_TDAGENT_NODE_BIND_IP}:${NEON_LOG_TDAGENT_FORWARD_PORT}:${NEON_LOG_TDAGENT_FORWARD_PORT}/udp \
        -p ${NEON_LOG_TDAGENT_NODE_BIND_IP}:${NEON_LOG_TDAGENT_HTTP_PORT}:${NEON_LOG_TDAGENT_HTTP_PORT}           \
        -v /etc/neoncloud/td-agent-node:/etc/td-agent:ro                                                          \
        -v /var/log/td-agent-node:/var/log/td-agent                                                               \
        ${NEON_NET_ARGS}                                                                                          \
        ${NEON_LOG_TDAGENT_NODEIMAGE}                                                                             \
            --log /var/log/td-agent/td-agent-node.log
    
    echo "*** END: Install TD-AGENT" 1>&2
else
    echo "*** TD-AGENT installation is disabled" 1>&2
fi

# Indicate that the script completed.

endsetup setup-tdagent
