#!/bin/bash
#------------------------------------------------------------------------------
# FILE:         setup-weave-flux.sh
# CONTRIBUTOR:  Jeff Lill
# COPYRIGHT:    Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.
#
# NOTE: Variables formatted like $<name> will be expanded by [node-conf]
#       using the [PreprocessReader].
#
# Configures Weave Flux on the worker nodes.

# Configure Bash strict mode so that the entire script will fail if 
# any of the commands fail.
#
#       http://redsymbol.net/articles/unofficial-bash-strict-mode/

set -euo pipefail

echo
echo "**********************************************" 1>&2
echo "** SETUP-WEAVE-FLUX.SH                      **" 1>&2
echo "**********************************************" 1>&2

# Load the cluster configuration and setup utilities.

. $<load-cluster-config>
. setup-utility.sh

# Ensure that setup is idempotent.

startsetup setup-weave-flux

echo "*** BEGIN: Install Weave Flux" 1>&2

# Install Weave Flux.

if ${NEON_WEAVE_FLUX_ENABLED} ; then

    echo "***     Configuring Weave Flux" 1>&2

    #--------------------------------------------------------------------------
    # Stop and remove Flux container if it's present.
    
    echo "***     Stopping [neon.fluxd]" 1>&2
    unsafeinvoke docker stop neon.fluxd 
    unsafeinvoke docker rm neon.fluxd 

    #--------------------------------------------------------------------------
    # We're going to have Flux use the Etcd-proxy running on the local node.

    export HOST_IP=${NEON_HOST_IP}
    export ETCD_ADDRESS=http://127.0.0.1:${NEON_ETCD_PORT}

    echo "***     HOST_IP      = $HOST_IP"      1>&2
    echo "***     ETCD_ADDRESS = $ETCD_ADDRESS" 1>&2

    docker run -d                                      \
        --name "weavefluxd"                            \
        --restart always                               \
        --cap-add NET_ADMIN                            \
        --net host                                     \
        -e HOST_IP                                     \
        -e ETCD_ADDRESS                                \
        -v "/var/run/docker.sock:/var/run/docker.sock" \
        weaveworks/fluxd:${NEON_WEAVE_FLUX_VERSION}    \
            --network-mode=global

    #--------------------------------------------------------------------------
    # Pull the Fluxctl docker image.

    echo "***     Pull the [fluxctl] image" 1>&2

    docker pull weaveworks/fluxctl:${NEON_WEAVE_FLUXCTL_VERSION}

    #--------------------------------------------------------------------------
    # Generate the Fluxctl script.

    echo "***     Generating [fluxctl] script" 1>&2

    cat <<EOF > /usr/local/bin/fluxctl
#!/bin/bash
#------------------------------------------------------------------------------
# FILE:         fluxctl
# CONTRIBUTOR:  Jeff Lill
# COPYRIGHT:    Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.
#
# This script acts as the Weave Flux CLI by running the [weaveworks/fluxctl]
# container and forwarding the command line arguments.  The version of the
# container to be run will be obtained from the Neon cluster configuration.
#
# Usage: fluxctl [ OPTIONS ] FLUXCMD ARGS...

. $<load-cluster-config-quiet>

export ETCD_ADDRESS=http://\${NEON_HOST_IP}:\${NEON_ETCD_PORT}

docker -H :\${NEON_DOCKER_PORT}                           \\
    run --rm                                              \\
        -e ETCD_ADDRESS                                   \\
        weaveworks/fluxctl:\${NEON_WEAVE_FLUXCTL_VERSION} \\
        \$@
EOF

    chmod 700 /usr/local/bin/fluxctl

else
    echo "*** Weave Flux is disabled" 1>&2
fi

echo "*** END: Install Weave Flux" 1>&2

# Indicate that the script completed.

endsetup setup-weave-flux
