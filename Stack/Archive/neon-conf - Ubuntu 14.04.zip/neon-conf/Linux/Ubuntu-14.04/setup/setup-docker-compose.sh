#!/bin/bash
#------------------------------------------------------------------------------
# FILE:         setup-docker-compose.sh
# CONTRIBUTOR:  Jeff Lill
# COPYRIGHT:    Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.
#
# NOTE: This script must be run under SUDO.
#
# NOTE: Variables formatted like $<name> will be expanded by [node-conf]
#       using the [PreprocessReader].
#
# This script handles the installation of Docker Compose.

# Configure Bash strict mode so that the entire script will fail if 
# any of the commands fail.
#
#       http://redsymbol.net/articles/unofficial-bash-strict-mode/

set -euo pipefail

echo
echo "**********************************************" 1>&2
echo "** SETUP-DOCKER-COMPOSE.SH                  **" 1>&2
echo "**********************************************" 1>&2

# Load the cluster configuration and setup utilities.

. $<load-cluster-config>
. setup-utility.sh

# Ensure that setup is idempotent.

startsetup setup-docker-compose

#--------------------------------------------------------------------------
# Install Docker Compose

curl -fsSL https://github.com/docker/compose/releases/download/${NEON_DOCKER_COMPOSE_VERSION}/docker-compose-`uname -s`-`uname -m` > /usr/local/bin/docker-compose
chmod +x /usr/local/bin/docker-compose

#------------------------------------------------------------------------------
# Create the [/usr/local/bin/swarm-compose] utility script that runs a Docker 
# Compose command against the local Swarm manager for manager nodes or against
# the first manager node for worker nodes.

cat <<EOF > /usr/local/bin/swarm-compose
#!/bin/bash
#------------------------------------------------------------------------------
# FILE:         swarm-compose
# CONTRIBUTOR:  Jeff Lill
# COPYRIGHT:    Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.
#
# This script runs a Docker runs a Docker Compose command against the local 
# Swarm manager for manager nodes or on the first manager node for worker nodes.
#
# Usage: swarm-compose COMPOSE-COMMAND ARGS...

. $<load-cluster-config-quiet>

if ${NEON_MANAGER} ; then
    manager_address=:${NEON_SWARM_MANAGER_PORT}
else
    manager_address=${NEON_MANAGER_ADDRESSES[0]}:${NEON_SWARM_MANAGER_PORT}
fi

docker-compose -H \${manager_address} \$@
EOF

chown :docker /usr/local/bin/swarm-compose
chmod 770 /usr/local/bin/swarm-compose

# Indicate that the script completed.

endsetup setup-docker-compose
