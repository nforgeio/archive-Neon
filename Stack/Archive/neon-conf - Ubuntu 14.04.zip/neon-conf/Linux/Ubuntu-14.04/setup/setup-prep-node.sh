#!/bin/bash
#------------------------------------------------------------------------------
# FILE:         setup-prep-node.sh
# CONTRIBUTOR:  Jeff Lill
# COPYRIGHT:    Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.
#
# NOTE: This script must be run under SUDO.
#
# NOTE: Variables formatted like $<name> will be expanded by [node-conf]
#       using the [PreprocessReader].
#
# This script handles the configuration of a near-virgin Ubuntu 14.04 server 
# install into one suitable for deploying a Neon cluster upon.  This script 
# requires that:
#
#       * OpenSSH was installed
#       * Host name was left as the default: "ubuntu"
#       * SUDO be configured to not request passwords

# Configure Bash strict mode so that the entire script will fail if 
# any of the commands fail.
#
#       http://redsymbol.net/articles/unofficial-bash-strict-mode/

set -euo pipefail

echo
echo "**********************************************" 1>&2
echo "** SETUP-PREP-NODE.SH                       **" 1>&2
echo "**********************************************" 1>&2
echo

#------------------------------------------------------------------------------
# We need to configure things such that [apt-get] won't complain
# about being unable to initialize Dialog when called from 
# non-interactive SSH sessions.

echo "** Configuring Dialog" 1>&2

echo 'debconf debconf/frontend select Noninteractive' | debconf-set-selections

#------------------------------------------------------------------------------
# We need to modify how [getaddressinfo] handles DNS lookups 
# IPv4 lookups are preferred over IPv6.  This can cause
# performance problems because in most situations right now,
# the server would be doing 2 DNS queries, one for AAAA (IPv6) which
# will nearly always fail (at least until IPv6 is more prevalent)
# and then querying for the for A (IPv4) record.
#
# This can also cause issues when the server is behind a NAT.
# I ran into a situation where [apt-get update] started failing
# because one of the archives had an IPv6 address too.  Here'script
# a note about this issue:
#
#       http://ubuntuforums.org/showthread.php?t=2282646
#
# We're going to uncomment the line below in [gai.conf] and
# change it to the following line to prefer IPv4.
#
#       #precedence ::ffff:0:0/96  10
#       precedence ::ffff:0:0/96  100

sed -i 's!^#precedence ::ffff:0:0/96  10$!precedence ::ffff:0:0/96  100!g' /etc/gai.conf

#------------------------------------------------------------------------------
# Ensure that we have the latest packages including any 
# security updates.

echo "** Upgrading packages" 1>&2

apt-get update -yq
apt-get upgrade -yq

#------------------------------------------------------------------------------
# Update the Bash profile so the global environment variables will be loaded
# into Bash sessions.

cat <<EOF > /etc/profile.d/env.sh
. /etc/environment
EOF

#------------------------------------------------------------------------------
# [sudo] doesn't allow the subprocess it creates to inherit the environment 
# variables by default.  You need to use the [-E] option to accomplish this.
# 
# As a convienence, we're going to create an [sbash] script, that uses
# [sudo] to start Bash while inheriting the current environment.

cat <<EOF > /usr/bin/sbash
# Starts Bash with elevated permissions while also inheriting
# the current environment variables.

/usr/bin/sudo -E bash \$@
EOF

chmod a+x /usr/bin/sbash

#------------------------------------------------------------------------------
# Install some useful packages.

apt-get install -yq supervisor

#------------------------------------------------------------------------------
# We need to increase the number of file descriptors.  This is required by
# Fluentd and probably for other reasons.  We're simply going to overwrite 
# the default version of [/etc/security/limits.conf] with our own copy.

cat <<EOF > /etc/security/limits.conf
# /etc/security/limits.conf
#
#Each line describes a limit for a user in the form:
#
#<domain>        <type>  <item>  <value>
#
#Where:
#<domain> can be:
#        - a user name
#        - a group name, with @group syntax
#        - the wildcard *, for default entry
#        - the wildcard %, can be also used with %group syntax,
#                 for maxlogin limit
#        - NOTE: group and wildcard limits are not applied to root.
#          To apply a limit to the root user, <domain> must be
#          the literal username root.
#
#<type> can have the two values:
#        - "soft" for enforcing the soft limits
#        - "hard" for enforcing hard limits
#
#<item> can be one of the following:
#        - core - limits the core file size (KB)
#        - data - max data size (KB)
#        - fsize - maximum filesize (KB)
#        - memlock - max locked-in-memory address space (KB)
#        - nofile - max number of open files
#        - rss - max resident set size (KB)
#        - stack - max stack size (KB)
#        - cpu - max CPU time (MIN)
#        - nproc - max number of processes
#        - as - address space limit (KB)
#        - maxlogins - max number of logins for this user
#        - maxsyslogins - max number of logins on the system
#        - priority - the priority to run user process with
#        - locks - max number of file locks the user can hold
#        - sigpending - max number of pending signals
#        - msgqueue - max memory used by POSIX message queues (bytes)
#        - nice - max nice priority allowed to raise to values: [-20, 19]
#        - rtprio - max realtime priority
#        - chroot - change root to directory (Debian-specific)
#
#<domain>   <type>  <item>  <value>

# These settings are recommended for Fluentd:

root        soft    nofile  65536
root        hard    nofile  65536
*           soft    nofile  65536
*           hard    nofile  65536

# End of file
EOF

#------------------------------------------------------------------------------
# Fluentd also recommends tuning some Kernel network parameters.

cat <<EOF > /etc/sysctl.conf
#
# /etc/sysctl.conf - Configuration file for setting system variables
# See /etc/sysctl.d/ for additional system variables.
# See sysctl.conf (5) for information.
#

#kernel.domainname = example.com

# Uncomment the following to stop low-level messages on console
#kernel.printk = 3 4 1 3

##############################################################3
# Functions previously found in netbase
#

# Uncomment the next two lines to enable Spoof protection (reverse-path filter)
# Turn on Source Address Verification in all interfaces to
# prevent some spoofing attacks
#net.ipv4.conf.default.rp_filter=1
#net.ipv4.conf.all.rp_filter=1

# Uncomment the next line to enable TCP/IP SYN cookies
# See http://lwn.net/Articles/277146/
# Note: This may impact IPv6 TCP sessions too
#net.ipv4.tcp_syncookies=1

# Uncomment the next line to enable packet forwarding for IPv4
#net.ipv4.ip_forward=1

# Uncomment the next line to enable packet forwarding for IPv6
#  Enabling this option disables Stateless Address Autoconfiguration
#  based on Router Advertisements for this host
#net.ipv6.conf.all.forwarding=1


###################################################################
# Additional settings - these settings can improve the network
# security of the host and prevent against some network attacks
# including spoofing attacks and man in the middle attacks through
# redirection. Some network environments, however, require that these
# settings are disabled so review and enable them as needed.
#
# Do not accept ICMP redirects (prevent MITM attacks)
#net.ipv4.conf.all.accept_redirects = 0
#net.ipv6.conf.all.accept_redirects = 0
# _or_
# Accept ICMP redirects only for gateways listed in our default
# gateway list (enabled by default)
# net.ipv4.conf.all.secure_redirects = 1
#
# Do not send ICMP redirects (we are not a router)
#net.ipv4.conf.all.send_redirects = 0
#
# Do not accept IP source route packets (we are not a router)
#net.ipv4.conf.all.accept_source_route = 0
#net.ipv6.conf.all.accept_source_route = 0
#
# Log Martian Packets
#net.ipv4.conf.all.log_martians = 1


###################################################################
# Fluentd recommended settings:

net.ipv4.tcp_tw_recycle = 1
net.ipv4.tcp_tw_reuse = 1
net.ipv4.ip_local_port_range = 10240 65535
EOF

#------------------------------------------------------------------------------
# Update the APT package index and install some common packages.

apt-get update -yq
apt-get install -yq unzip curl nano sysstat dstat iotop iptraf apache2-utils daemon

#------------------------------------------------------------------------------
# Install Mono

echo "** Install Mono" 1>&2

apt-key adv --keyserver hkp://keyserver.ubuntu.com:80 --recv-keys 3FA7E0328081BFF6A14DA29AA6A19B38D3D831EF
echo "deb http://download.mono-project.com/repo/debian wheezy main" | tee /etc/apt/sources.list.d/mono-xamarin.list

apt-get update -yq
apt-get install -yq mono-complete
apt-get install -yq ca-certificates-mono

#------------------------------------------------------------------------------
# Clean some things up.

echo "** Cleanup" 1>&2

# Clear any cached [apt-get] related files.

apt-get autoclean -yq
rm -rf /var/lib/apt/lists/* 
rm -rf /var/cache/apt/archives/*

# Clear any DHCP leases to be super sure that cloned node
# VMs will obtain fresh IP addresses.

rm -f /var/lib/dhcp/*.leases

echo "**********************************************" 1>&2
