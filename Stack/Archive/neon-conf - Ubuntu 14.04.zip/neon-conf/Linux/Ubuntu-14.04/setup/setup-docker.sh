#!/bin/bash
#------------------------------------------------------------------------------
# FILE:         setup-docker.sh
# CONTRIBUTOR:  Jeff Lill
# COPYRIGHT:    Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.
#
# NOTE: This script must be run under SUDO.
#
# NOTE: Variables formatted like $<name> will be expanded by [node-conf]
#       using the [PreprocessReader].
#
# This script handles the installation of the Docker CLI.

# Configure Bash strict mode so that the entire script will fail if 
# any of the commands fail.
#
#       http://redsymbol.net/articles/unofficial-bash-strict-mode/

set -euo pipefail

echo
echo "**********************************************" 1>&2
echo "** SETUP-DOCKER.SH                          **" 1>&2
echo "**********************************************" 1>&2

# Load the cluster configuration and setup utilities.

. $<load-cluster-config>
. setup-utility.sh

# Ensure that setup is idempotent.

startsetup setup-docker

# Note we're going to delete the docker unique key file if present.  Docker will
# generate a unique key the first time it starts.  It's possible that a key
# might be left over if the OS image was cloned.  The Docker Swarm agent
# won't schedule containers on nodes with duplicate keys.

rm -f /etc/docker/key.json

#--------------------------------------------------------------------------
# Install Docker.

curl -fsSL https://get.docker.com/ | sh

#--------------------------------------------------------------------------
# We need to replace [/etc/default/docker] with the [/etc/default/docker.neon]
# file we uploaded and then restart Docker to pick up the changes.  We're
# going to keep a copy of the original file around as [docker.original] so
# we can replace it during an [apt-upgrade].
#
# The new default configuration exposes the docker API to the network and
# also configures the node's Docker labels.

if [ "$(fileexists /etc/default/docker.original)" != "true"  ] ; then
    cp /etc/default/docker /etc/default/docker.original
fi

cp /etc/default/docker.neon /etc/default/docker

#--------------------------------------------------------------------------
# We also need to modify the Upstart config to have Docker wait for Consul 
# to start so any containers with dependencies on Consul (like Swarm) will
# be happy from the get-go.

if [ "$(fileexists /etc/init/docker.conf.original)" != "true"  ] ; then
    cp /etc/init/docker.conf /etc/init/docker.conf.original
fi

sed -i 's!^start on .*$!start on started consul!g' /etc/init/docker.conf

# Restart to pick up the changes.

service docker restart

# Indicate that the script completed.

endsetup setup-docker
