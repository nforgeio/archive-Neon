#------------------------------------------------------------------------------
# FILE:         docker
# CONTRIBUTOR:  Jeff Lill
# COPYRIGHT:    Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.
#
# NeonCloud customized Docker Upstart options.

# Set DOCKER_OPTS to modify the daemon startup options.  First, we're
# going to set the basic options.
#
# We need to expose the Unix communication socket as a TCP network because
# the Weave proxy and Swarm (I think) are unable to access the Unix socket.
#
# We're also going to specify the advertise address and the backing store
# configure the Docker daemon labels.

$<docker.options>
