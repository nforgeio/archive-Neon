#!/bin/bash
#------------------------------------------------------------------------------
# FILE:         neoncloud.conf.sh
# CONTRIBUTOR:  Jeff Lill
# COPYRIGHT:    Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.
# REQUIRES:     
#
# WARNING: This script is generated and managed by the [neon-conf] tool and
#          MUST NOT BE MODIFIED by hand unless you really know what you're doing.
#
# NOTE: Variables formatted like $<name> will be expanded by [node-conf]
#       using the [PreprocessReader].
#
# This script defines the current configuration of the Neon Cluster as is
# currently known to this node.  [neon-conf] generates this during initial
# cluster deployment and may modify it as the cluster is reconfigured.
#
# This script also loads and exports environment variables from [/etc/environment]
# so they will be available to scripts invoked remotely by [neon-conf].
#
# Usage: neoncloud.conf.sh [ --echo-summary ]

if [ "${1-none}" == "--echo-summary" ] ; then
    summary=true
else
    summary=false
fi

#------------------------------------------------------------------------------
# This describes the format of this file as defined by the version of
# [neon-conf] last deployed to the cluster.  This is used to ensure
# that older versions of the tool won't try to reconfigure clusters
# deployed with a format it won't understand and also allow for newer
# version of [neon-conf] to upgrade older clusters.

NEON_CLUSTER_SCHEMA=$<cluster.schema>

#------------------------------------------------------------------------------
# Bash does not run interactively when called remotely via SSH.  This means
# that the global environment variables won't be loaded.  We need to do this
# ourselves.
#
# NOTE: We need to parse this rather than just running this file as a script 
#       because we need to export these variables for subprocesses.

while IFS='' read -r line || [[ -n "$line" ]]; 
do

    name=$(cut -d '=' -f 1 <<< "$line")
    value=$(cut -d '=' -f 2- <<< "$line")

    if [ "$name" != "" ] ; then
        declare -x "$name=$value"
    fi

done < /etc/environment

#------------------------------------------------------------------------------
# Describe important host machine folders.

export NEON_COMPOSE_FOLDER=$<neon.folders.compose>
export NEON_CONFIG_FOLDER=$<neon.folders.config>
export NEON_SECRETS_FOLDER=$<neon.folders.secrets>
export NEON_SETUP_FOLDER=$<neon.folders.setup>
export NEON_STATE_FOLDER=$<neon.folders.state>

export PATH=${PATH}:${NEON_SETUP_FOLDER}

#------------------------------------------------------------------------------
# Describe the cluster manager nodes.  You can use the [getmanager] function
# below to retrieve node information using a zero-based index.
#
# You can access node properties using array syntax like:
#
#       ${managernode[name]}
#       ${managernode[address]}

export NEON_MANAGER_COUNT=$<nodes.manager.count>

$<nodes.managers>
#------------------------------------------------------------------------------
# Specify component specific settings

# NTP time sources to be configured on manager and worker nodes.

export NEON_NTP_MANAGER_SOURCES=( $<ntp.manager.sources> )
export NEON_NTP_WORKER_SOURCES=( $<ntp.worker.sources> )

# Docker settings

export NEON_DOCKER_PORT=$<docker.port>
export NEON_DOCKER_COMPOSE_VERSION=$<docker.compose.version>

# Consul settings

export NEON_CONSUL_ENABLED=$<consul.enabled>
export NEON_CONSUL_VERSION=$<consul.version>
export NEON_CONSUL_OPTIONS=$<consul.options>
export NEON_CONSUL_PORT=$<consul.port>

# Network settings

export NEON_NETWORK_NAME=$<network.name>
export NEON_NETWORK_DNSDOMAIN=$<network.dnsdomain>
export NEON_NETWORK_DNSDOMAIN_NEON=$<network.dnsdomain.neon>
export NEON_NETWORK_OVERLAYDNS=$<network.dns>

# Weave settings

export NEON_WEAVE_NET_ENABLED=$<weave.net.enabled>
export NEON_WEAVE_NET_VERSION=$<weave.net.version>
export NEON_WEAVE_NET_SUBNET=$<weave.net.subnet>
export NEON_WEAVE_NET_PROXY_PORT=$<weave.net.proxyport>

export NEON_WEAVE_FLUX_ENABLED=$<weave.flux.enabled>
export NEON_WEAVE_FLUX_VERSION=$<weave.flux.version>
export NEON_WEAVE_FLUXCTL_VERSION=$<weave.flux.ctlversion>

export NEON_WEAVE_SCOPE_ENABLED=$<weave.scope.enabled>
export NEON_WEAVE_SCOPE_VERSION=$<weave.scope.version>
export NEON_WEAVE_SCOPE_PORT=$<weave.scope.port>

# Etcd settings

export NEON_ETCD_ENABLED=$<etcd.enabled>
export NEON_ETCD_VERSION=$<etcd.version>
export NEON_ETCD_PORT=$<etcd.port>
export NEON_ETCD_PEER_PORT=$<etcd.peerport>

# Swarm settings

export NEON_SWARM_VERSION=$<swarm.version>
export NEON_SWARM_OPTIONS=$<swarm.options>
export NEON_SWARM_MANAGER_PORT=$<swarm.manager.port>
export NEON_SWARM_ADVERTISE_PORT=$<swarm.advertise.port>
export NEON_SWARM_DISCOVERY=$<swarm.discovery>

# Vault settings

export NEON_VAULT_ENABLED=$<vault.enabled>
export NEON_VAULT_VERSION=$<vault.version>
export NEON_VAULT_DOWNLOAD=$<vault.download>
export NEON_VAULT_PORT=$<vault.port>
export NEON_VAULT_CONSUL_PATH=$<vault.consulpath>
export NEON_VAULT_TLS_DISABLED=$<vault.tlsdisabled>

# Log settings

export NEON_LOG_ENABLED=$<log.enabled>
export NEON_LOG_TDAGENT_OSVERSION=$<log.tdagent.osversion>
export NEON_LOG_TDAGENT_NODEIMAGE=$<log.tdagent.nodeimage>
export NEON_LOG_TDAGENT_CLUSTERIMAGE=$<log.tdagent.clusterimage>
export NEON_LOG_TDAGENT_NODE_BIND_IP=$<log.tdagent.node.bindip>
export NEON_LOG_TDAGENT_OS_BIND_IP=$<log.tdagent.os.bindip>
export NEON_LOG_TDAGENT_FORWARD_PORT=$<log.tdagent.forwardport>
export NEON_LOG_TDAGENT_HTTP_PORT=$<log.tdagent.httpport>
export NEON_LOG_COLLECTOR=$<log.collector>

# Misc settings

export NEON_DOTNET_ENABLED=$<dotnet.enabled>
export NEON_DOTNET_VERSION=$<dotnet.version>

# Echo the configuration to STDERR if requested.

if $summary ; then
    echo "NEON_CLUSTER_SCHEMA            = ${NEON_CLUSTER_SCHEMA}" 1>&2
    echo 1>&2
    echo "NEON_NODE_NAME                 = ${NEON_NODE_NAME}" 1>&2
    echo "NEON_HOST_DNSNAME              = ${NEON_HOST_DNSNAME}" 1>&2
    echo "NEON_HOST_IP                   = ${NEON_HOST_IP}" 1>&2
    echo "NEON_HOST_SSD                  = ${NEON_HOST_SSD}" 1>&2
    echo "NEON_MANAGER                   = ${NEON_MANAGER}" 1>&2
    echo "NEON_CLUSTER                   = ${NEON_CLUSTER}" 1>&2
    echo "NEON_DATACENTER                = ${NEON_DATACENTER}" 1>&2
    echo "NEON_ENVIRONMENT               = ${NEON_ENVIRONMENT}" 1>&2
    echo 1>&2
    echo "NEON_COMPOSE_FOLDER            = ${NEON_COMPOSE_FOLDER}" 1>&2
    echo "NEON_CONFIG_FOLDER             = ${NEON_CONFIG_FOLDER}" 1>&2
    echo "NEON_SECRETS_FOLDER            = ${NEON_SECRETS_FOLDER}" 1>&2
    echo "NEON_STATE_FOLDER              = ${NEON_STATE_FOLDER}" 1>&2
    echo "NEON_SETUP_FOLDER              = ${NEON_SETUP_FOLDER}" 1>&2
    echo "PATH                           = ${PATH}" 1>&2
    echo 1>&2
    echo "NEON_MANAGER_COUNT             = ${NEON_MANAGER_COUNT}" 1>&2
$<nodes.manager.summary>
    echo "NEON_MANAGER_NAMES             = ${NEON_MANAGER_NAMES[@]}" 1>&2
    echo "NEON_MANAGER_ADDRESSES         = ${NEON_MANAGER_ADDRESSES[@]}" 1>&2
    echo "NEON_MANAGER_PEERS             = ${NEON_MANAGER_PEERS[@]}" 1>&2
    echo 1>&2
    echo "NEON_NTP_MANAGER_SOURCES       = ${NEON_NTP_MANAGER_SOURCES}" 1>&2
    echo "NEON_NTP_WORKER_SOURCES        = ${NEON_NTP_WORKER_SOURCES}" 1>&2
    echo 1>&2
    echo "NEON_DOCKER_PORT               = ${NEON_DOCKER_PORT}" 1>&2
    echo "NEON_DOCKER_COMPOSE_VERSION    = ${NEON_DOCKER_COMPOSE_VERSION}" 1>&2
    echo 1>&2
    echo "NEON_CONSUL_ENABLED            = ${NEON_CONSUL_ENABLED}" 1>&2
    echo "NEON_CONSUL_VERSION            = ${NEON_CONSUL_VERSION}" 1>&2
    echo "NEON_CONSUL_OPTIONS            = ${NEON_CONSUL_OPTIONS}" 1>&2
    echo "NEON_CONSUL_PORT               = ${NEON_CONSUL_PORT}" 1>&2
    echo 1>&2
    echo "NEON_NETWORK_NAME              = ${NEON_NETWORK_NAME}" 1>&2
    echo "NEON_NETWORK_DNSDOMAIN         = ${NEON_NETWORK_DNSDOMAIN}" 1>&2
    echo "NEON_NETWORK_DNSDOMAIN_NEON    = ${NEON_NETWORK_DNSDOMAIN_NEON}" 1>&2
    echo "NEON_NETWORK_OVERLAYDNS        = ${NEON_NETWORK_OVERLAYDNS}" 1>&2
    echo 1>&2
    echo "NEON_WEAVE_NET_ENABLED         = ${NEON_WEAVE_NET_ENABLED}" 1>&2
    echo "NEON_WEAVE_NET_VERSION         = ${NEON_WEAVE_NET_VERSION}" 1>&2
    echo "NEON_WEAVE_NET_SUBNET          = ${NEON_WEAVE_NET_SUBNET}" 1>&2
    echo "NEON_WEAVE_NET_PROXY_PORT      = ${NEON_WEAVE_NET_PROXY_PORT}" 1>&2
    echo 1>&2
    echo "NEON_WEAVE_FLUX_ENABLED        = ${NEON_WEAVE_FLUX_ENABLED}" 1>&2
    echo "NEON_WEAVE_FLUX_VERSION        = ${NEON_WEAVE_FLUX_VERSION}" 1>&2
    echo "NEON_WEAVE_FLUXCTL_VERSION     = ${NEON_WEAVE_FLUXCTL_VERSION}" 1>&2
    echo 1>&2
    echo "NEON_WEAVE_SCOPE_ENABLED       = ${NEON_WEAVE_SCOPE_ENABLED}" 1>&2
    echo "NEON_WEAVE_SCOPE_VERSION       = ${NEON_WEAVE_SCOPE_VERSION}" 1>&2
    echo "NEON_WEAVE_SCOPE_PORT          = ${NEON_WEAVE_SCOPE_PORT}" 1>&2
    echo 1>&2
    echo "NEON_ETCD_ENABLED              = ${NEON_ETCD_ENABLED}" 1>&2
    echo "NEON_ETCD_VERSION              = ${NEON_ETCD_VERSION}" 1>&2
    echo "NEON_ETCD_PORT                 = ${NEON_ETCD_PORT}" 1>&2
    echo "NEON_ETCD_PEER_PORT            = ${NEON_ETCD_PEER_PORT}" 1>&2
    echo 1>&2
    echo "NEON_SWARM_VERSION             = ${NEON_SWARM_VERSION}" 1>&2
    echo "NEON_SWARM_OPTIONS             = ${NEON_SWARM_OPTIONS}" 1>&2
    echo "NEON_SWARM_MANAGER_PORT        = ${NEON_SWARM_MANAGER_PORT}" 1>&2
    echo "NEON_SWARM_ADVERTISE_PORT      = ${NEON_SWARM_ADVERTISE_PORT}" 1>&2
    echo "NEON_SWARM_DISCOVERY           = ${NEON_SWARM_DISCOVERY}" 1>&2
    echo 1>&2
    echo "NEON_VAULT_ENABLED             = ${NEON_VAULT_ENABLED}" 1>&2
    echo "NEON_VAULT_VERSION             = ${NEON_VAULT_VERSION}" 1>&2
    echo "NEON_VAULT_DOWNLOAD            = ${NEON_VAULT_DOWNLOAD}" 1>&2
    echo "NEON_VAULT_PORT                = ${NEON_VAULT_PORT}" 1>&2
    echo "NEON_VAULT_CONSUL_PATH         = ${NEON_VAULT_CONSUL_PATH}" 1>&2
    echo "NEON_VAULT_TLS_DISABLED        = ${NEON_VAULT_TLS_DISABLED}" 1>&2
    echo 1>&2
    echo "NEON_LOG_ENABLED               = ${NEON_LOG_ENABLED}" 1>&2
    echo "NEON_LOG_TDAGENT_OSVERSION     = ${NEON_LOG_TDAGENT_OSVERSION}" 1>&2
    echo "NEON_LOG_TDAGENT_NODEIMAGE     = ${NEON_LOG_TDAGENT_NODEIMAGE}" 1>&2
    echo "NEON_LOG_TDAGENT_CLUSTERIMAGE  = ${NEON_LOG_TDAGENT_CLUSTERIMAGE}" 1>&2
    echo "NEON_LOG_TDAGENT_NODE_BIND_IP  = ${NEON_LOG_TDAGENT_NODE_BIND_IP}" 1>&2
    echo "NEON_LOG_TDAGENT_OS_BIND_IP    = ${NEON_LOG_TDAGENT_OS_BIND_IP}" 1>&2
    echo "NEON_LOG_TDAGENT_FORWARD_PORT  = ${NEON_LOG_TDAGENT_FORWARD_PORT}" 1>&2
    echo "NEON_LOG_TDAGENT_HTTP_PORT     = ${NEON_LOG_TDAGENT_HTTP_PORT}" 1>&2
    echo "NEON_LOG_COLLECTOR             = ${NEON_LOG_COLLECTOR}" 1>&2
    echo 1>&2
    echo "NEON_DOTNET_ENABLED            = ${NEON_DOTNET_ENABLED}" 1>&2
    echo "NEON_DOTNET_VERSION            = ${NEON_DOTNET_VERSION}" 1>&2
    echo 1>&2
fi

#------------------------------------------------------------------------------
# Define some useful global script functions.  Note that the special comments:
#
#       #<<<BEGIN-FUNCTIONS
#
#       #<<<END-FUNCTIONS
#
# are here to allow [neon-conf] to easily replace these with updated functions
# when necessary, in the future.

#------------------
#<<<BEGIN-FUNCTIONS

# Returns the manager information for a manager node based on its zero based
# index.  The result will be returned in the $MANAGE_NODE variable.
#
# Usage: getmanager INDEX

function getmanager
{
    eval MANAGE_NODE=$NEON_MANAGER_$1
}

#<<<END-FUNCTIONS
#------------------
