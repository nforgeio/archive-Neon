﻿//-----------------------------------------------------------------------------
// FILE:	    CommonSteps.cs
// CONTRIBUTOR: Jeff Lill
// COPYRIGHT:	Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using Neon.Stack.Common;
using Neon.Stack.Management;

namespace NeonConf
{
    /// <summary>
    /// Implements common configuration steps.
    /// </summary>
    public static class CommonSteps
    {
        /// <summary>
        /// Initializes a near virgin server with the basic capabilities required
        /// for a NeonCloud host node.
        /// </summary>
        /// <param name="server">The target server.</param>
        public static void PrepareNode(NodeManagementProxy<NodeDefinition> server)
        {
            server.InitializeNeonFolders();
            server.UploadConfFiles(null);
            server.UploadComposeFiles(null);
            server.UploadSetupFiles(null);

            server.Status = "run: setup-prep-node.sh";
            server.SudoCommand("setup-prep-node.sh");

            // Reboot the server to ensure that all changes are live.

            server.Reboot(wait: true);
        }
    }
}
