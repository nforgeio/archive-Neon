﻿//-----------------------------------------------------------------------------
// FILE:	    NodeManagementProxyExtensions.cs
// CONTRIBUTOR: Jeff Lill
// COPYRIGHT:	Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.Contracts;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

using Neon.Stack.Common;
using Neon.Stack.IO;
using Neon.Stack.Management;

namespace NeonConf
{
    /// <summary>
    /// <see cref="NodeManagementProxy{T}"/> extension methods.
    /// </summary>
    public static class NodeManagentProxyExtension
    {
        /// <summary>
        /// Converts a string into a value suitable for use in a Bash script.
        /// </summary>
        /// <param name="value">The value to be made safe,</param>
        /// <returns>The safe value.</returns>
        private static string BashSafeValue(object value)
        {
            if (value == null)
            {
                return "\"\"";
            }

            if (value is bool)
            {
                return (bool)value ? "true" : "false";
            }
            else if (value is int)
            {
                return value.ToString();
            }
            else
            {
                // We need to escape single and double quotes.

                var stringValue = value.ToString();

                stringValue = stringValue.Replace("'", "\\'");
                stringValue = stringValue.Replace("\"", "\\\"");

                return $"\"{stringValue}\"";
            }
        }

        /// <summary>
        /// Sets a variable in a <see cref="PreprocessReader"/> such that the value will be safe
        /// to be included in a Bash variable set statement.
        /// </summary>
        /// <param name="preprocessReader">The reader.</param>
        /// <param name="name">The variable name.</param>
        /// <param name="value">The variable value.</param>
        private static void SetBashVariable(PreprocessReader preprocessReader, string name, object value)
        {
            Covenant.Requires<ArgumentNullException>(preprocessReader != null);
            Covenant.Requires<ArgumentNullException>(name != null);

            if (value == null)
            {
                preprocessReader.Set(name, value);
            }
            else
            {
                if (value is bool)
                {
                    value = (bool)value ? "true" : "false";
                }
                else if (value is int)
                {
                    value = value.ToString();
                }
                else
                {
                    // We need to escape single and double quotes.

                    var stringValue = value.ToString();

                    stringValue = stringValue.Replace("'", "\\'");
                    stringValue = stringValue.Replace("\"", "\\\"");

                    value = $"\"{stringValue}\"";
                }

                preprocessReader.Set(name, value);
            }
        }

        /// <summary>
        /// Sets cluster definition related variables for a <see cref="PreprocessReader"/>.
        /// </summary>
        /// <param name="preprocessReader">The reader.</param>
        /// <param name="clusterDefinition">The cluster definition.</param>
        /// <param name="targetNode">The target node.</param>
        private static void SetClusterVariables(PreprocessReader preprocessReader, ClusterDefinition clusterDefinition, NodeDefinition targetNode)
        {
            Covenant.Requires<ArgumentNullException>(preprocessReader != null);
            Covenant.Requires<ArgumentNullException>(clusterDefinition != null);

            // Generate the manager node variables in sorted order.  The variable 
            // names will be formatted as:
            //
            //      NEON_MANAGER_#
            //
            // where [#] is the zero-based index of the node.  This is compatible
            // with the [getmanager] function included the script.
            //
            // Each variable defines an associative array with [name] and [address]
            // properties.
            //
            // Then generate the NEON_MANAGER_NAMES and NEON_MANAGER_ADDRESSES arrays.
            //
            // NOTE: We need to use Linux-style line endings.

            var sbManagers                  = new StringBuilder();
            var sbManagerNamesArray         = new StringBuilder();
            var sbManagerAddressesArray     = new StringBuilder();
            var sbPeerManagerAddressesArray = new StringBuilder();
            var sbManagerNodesSummary       = new StringBuilder();
            var index                       = 0;
            var managerNameWidth            = 0;

            sbManagerNamesArray.Append("(");
            sbManagerAddressesArray.Append("(");
            sbPeerManagerAddressesArray.Append("(");

            foreach (var manager in clusterDefinition.SortedManagers)
            {
                sbManagers.Append($"declare -x -A NEON_MANAGER_{index}\n");
                sbManagers.Append($"NEON_MANAGER_{index}=( [\"name\"]=\"{manager.Name}\" [\"address\"]=\"{manager.Address}\" )\n");
                sbManagers.Append("\n");
                index++;

                sbManagerNamesArray.Append($" \"{manager.Name}\"");
                sbManagerAddressesArray.Append($" \"{manager.Address}\"");

                if (manager != targetNode)
                {
                    sbPeerManagerAddressesArray.Append($" \"{manager.Address}\"");
                }

                managerNameWidth = Math.Max(manager.Name.Length, managerNameWidth);
            }

            sbManagerNamesArray.Append(" )");
            sbManagerAddressesArray.Append(" )");
            sbPeerManagerAddressesArray.Append(" )");

            foreach (var manager in clusterDefinition.SortedManagers)
            {
                var nameField = manager.Name;

                if (nameField.Length < managerNameWidth)
                {
                    nameField += new string(' ', managerNameWidth - nameField.Length);
                }

                // The blanks below are just enough so that the "=" sign lines up
                // with the summary output from [neoncloud.conf.sh].

                if (sbManagerNodesSummary.Length == 0)
                {
                    sbManagerNodesSummary.Append($"    echo \"NEON_MANAGER NODES             = {nameField}: {manager.Address}\" 1>&2\n");
                }
                else
                {
                    sbManagerNodesSummary.Append($"    echo \"                                 {nameField}: {manager.Address}\" 1>&2\n");
                }
            }

            foreach (var manager in clusterDefinition.SortedManagers)
            {
                sbManagers.Append($"declare -x -A NEON_MANAGER_{index}\n");
                sbManagers.Append($"NEON_MANAGER_{index}=( [\"name\"]=\"{manager.Name}\" [\"address\"]=\"{manager.Address}\" )\n");
                index++;
            }

            sbManagers.Append("\n");
            sbManagers.Append($"declare -x NEON_MANAGER_NAMES={sbManagerNamesArray}\n");
            sbManagers.Append($"declare -x NEON_MANAGER_ADDRESSES={sbManagerAddressesArray}\n");

            sbManagers.Append("\n");

            if (clusterDefinition.Managers.Count() > 1)
            {
                sbManagers.Append($"declare -x NEON_MANAGER_PEERS={sbPeerManagerAddressesArray}\n");
            }
            else
            {
                sbManagers.Append("export NEON_MANAGER_PEERS=\"\"\n");
            }

            // Generate the manager and worker NTP time sources.

            var managerTimeSources = string.Empty;
            var workerTimeSources  = string.Empty;

            if (clusterDefinition.TimeSources != null)
            {
                foreach (var source in clusterDefinition.TimeSources)
                {
                    if (string.IsNullOrWhiteSpace(source))
                    {
                        continue;
                    }

                    if (managerTimeSources.Length > 0)
                    {
                        managerTimeSources += " ";
                    }

                    managerTimeSources += $"\"{source}\"";
                }
            }

            foreach (var manager in clusterDefinition.SortedManagers)
            {
                if (workerTimeSources.Length > 0)
                {
                    workerTimeSources += " ";
                }

                workerTimeSources += $"\"{manager.Address}\"";
            }

            if (string.IsNullOrWhiteSpace(managerTimeSources))
            {
                // Default to reasonable public time sources.

                managerTimeSources = "\"0.pool.ntp.org\" \"1.pool.ntp.org\" \"ec2-us-east.time.rightscale.com\" \"ec2-us-west.time.rightscale.com\"";
            }

            // Assemble the Swarm command line options.

            var swarmOptions = string.Empty;

            if (targetNode.Manager)
            {
                if (!string.IsNullOrWhiteSpace(clusterDefinition.Swarm.AdvancedManager))
                {
                    swarmOptions = clusterDefinition.Swarm.AdvancedManager;
                }
                else
                {
                    switch (clusterDefinition.Swarm.Strategy)
                    {
                        case SchedulingStrategy.Spread:

                            swarmOptions = "--strategy spread";
                            break;

                        case SchedulingStrategy.Binpack:

                            swarmOptions = "--strategy binpack";
                            break;

                        case SchedulingStrategy.Random:

                            swarmOptions = "--strategy random";
                            break;

                        default:

                            throw new NotImplementedException($"Scheduling strategy [{clusterDefinition.Swarm.Strategy}] is not implemented.");
                    }
                }
            }
            else
            {
                if (!string.IsNullOrWhiteSpace(clusterDefinition.Swarm.AdvancedAgent))
                {
                    swarmOptions = clusterDefinition.Swarm.AdvancedAgent;
                }
                else
                {
                    swarmOptions = "-delay 10s";
                }
            }

            // Generate the Docker daemon command line options.  The [/etc/default/docker] script uses this.

            var sbDockerOptions = new StringBuilder();
            var dockerLabels    = new List<KeyValuePair<string, object>>();

            sbDockerOptions.Append($"DOCKER_OPTS=\" \\\n");
            sbDockerOptions.Append($"    -H tcp://0.0.0.0:{clusterDefinition.Docker.Port} -H unix:///var/run/docker.sock \\\n");
            sbDockerOptions.Append($"    --log-level=info \\\n");
            sbDockerOptions.Append($"    --cluster-advertise eth0:{clusterDefinition.Docker.Port} \\\n");
            sbDockerOptions.Append($"    --cluster-store consul://127.0.0.1:{clusterDefinition.Consul.Port}");

            dockerLabels.Add(new KeyValuePair<string, object>(NodeLabels.LabelDatacenter, clusterDefinition.Datacenter));
            dockerLabels.Add(new KeyValuePair<string, object>(NodeLabels.LabelEnvironment, clusterDefinition.Environment));

            foreach (var item in targetNode.Labels.Standard)
            {
                dockerLabels.Add(new KeyValuePair<string, object>(item.Key.ToLowerInvariant(), item.Value));
            }

            foreach (var item in targetNode.Labels.Custom)
            {
                dockerLabels.Add(new KeyValuePair<string, object>(item.Key.ToLowerInvariant(), item.Value));
            }

            foreach (var label in dockerLabels)
            {
                // Note that I need to escape the double quotes in the safe label values 
                // because the entire DOCKER_OPTS value is also quoted.

                sbDockerOptions.Append($" \\\n    --label {label.Key.ToLowerInvariant()}={BashSafeValue(label.Value).Replace("\"", "\\\"")}");
            }

            sbDockerOptions.Append(" \\\n\"\n");

            // Define the Consul command line options.

            var consulOptions = string.Empty;

            if (!string.IsNullOrWhiteSpace(clusterDefinition.Consul.Advanced))
            {
                consulOptions = clusterDefinition.Consul.Advanced;
            }

            preprocessReader.Set("docker.options", sbDockerOptions);
            
            // Set the variables.

            preprocessReader.Set("load-cluster-config", NodeHostFolder.ConfigFolder + "/neoncloud.conf.sh --echo-summary");
            preprocessReader.Set("load-cluster-config-quiet", NodeHostFolder.ConfigFolder + "/neoncloud.conf.sh");

            SetBashVariable(preprocessReader, "cluster.schema", ClusterDefinition.ConfigSchema);

            SetBashVariable(preprocessReader, "neon.folders.compose", NodeHostFolder.ComposeFolder);
            SetBashVariable(preprocessReader, "neon.folders.config", NodeHostFolder.ConfigFolder);
            SetBashVariable(preprocessReader, "neon.folders.secrets", NodeHostFolder.SecretsFolder);
            SetBashVariable(preprocessReader, "neon.folders.setup", NodeHostFolder.SetupFolder);
            SetBashVariable(preprocessReader, "neon.folders.state", NodeHostFolder.StateFolder);

            SetBashVariable(preprocessReader, "nodes.manager.count", clusterDefinition.Managers.Count());
            preprocessReader.Set("nodes.managers", sbManagers);
            preprocessReader.Set("nodes.manager.summary", sbManagerNodesSummary);

            SetBashVariable(preprocessReader, "ntp.manager.sources", managerTimeSources);
            SetBashVariable(preprocessReader, "ntp.worker.sources", workerTimeSources);

            SetBashVariable(preprocessReader, "docker.port", clusterDefinition.Docker.Port);
            SetBashVariable(preprocessReader, "docker.compose.version", clusterDefinition.Docker.ComposeVersion);

            SetBashVariable(preprocessReader, "consul.enabled", clusterDefinition.Consul.Enabled);
            SetBashVariable(preprocessReader, "consul.version", clusterDefinition.Consul.Version);
            SetBashVariable(preprocessReader, "consul.options", consulOptions);
            SetBashVariable(preprocessReader, "consul.port", clusterDefinition.Consul.Port);

            SetBashVariable(preprocessReader, "network.name", clusterDefinition.Network.Name);
            SetBashVariable(preprocessReader, "network.dnsdomain", $"{clusterDefinition.Network.DomainLabel}.local");
            SetBashVariable(preprocessReader, "network.dnsdomain.neon", ClusterDefinition.ReservedDomain);
            SetBashVariable(preprocessReader, "network.overlaydns", clusterDefinition.Network.Dns);

            SetBashVariable(preprocessReader, "weave.net.enabled", clusterDefinition.Weave.Network.Enabled);
            SetBashVariable(preprocessReader, "weave.net.version", clusterDefinition.Weave.Network.Version);
            SetBashVariable(preprocessReader, "weave.net.subnet", clusterDefinition.Network.Subnet);
            SetBashVariable(preprocessReader, "weave.net.proxyport", clusterDefinition.Weave.Network.ProxyPort);

            SetBashVariable(preprocessReader, "weave.flux.enabled", clusterDefinition.Weave.Flux.Enabled);
            SetBashVariable(preprocessReader, "weave.flux.version", clusterDefinition.Weave.Flux.Version);
            SetBashVariable(preprocessReader, "weave.flux.ctlversion", clusterDefinition.Weave.Flux.CtlVersion);

            SetBashVariable(preprocessReader, "weave.scope.enabled", clusterDefinition.Weave.Scope.Enabled);
            SetBashVariable(preprocessReader, "weave.scope.version", clusterDefinition.Weave.Scope.Version);
            SetBashVariable(preprocessReader, "weave.scope.port", clusterDefinition.Weave.Scope.Port);

            SetBashVariable(preprocessReader, "etcd.enabled", clusterDefinition.Etcd.Enabled);
            SetBashVariable(preprocessReader, "etcd.version", clusterDefinition.Etcd.Version);
            SetBashVariable(preprocessReader, "etcd.port", clusterDefinition.Etcd.Port);
            SetBashVariable(preprocessReader, "etcd.peerport", clusterDefinition.Etcd.PeerPort);

            SetBashVariable(preprocessReader, "swarm.version", clusterDefinition.Swarm.Version);
            SetBashVariable(preprocessReader, "swarm.options", swarmOptions);
            SetBashVariable(preprocessReader, "swarm.manager.port", clusterDefinition.Swarm.Port);
            SetBashVariable(preprocessReader, "swarm.manager.address", $"{targetNode.Address}:{clusterDefinition.Swarm.Port}");
            SetBashVariable(preprocessReader, "swarm.advertise.port", "${NEON_DOCKER_PORT}");
            SetBashVariable(preprocessReader, "swarm.discovery", "consul://${NEON_HOST_IP}:${NEON_CONSUL_PORT}");

            SetBashVariable(preprocessReader, "vault.enabled", clusterDefinition.Vault.Enabled);
            SetBashVariable(preprocessReader, "vault.version", clusterDefinition.Vault.Version);
            SetBashVariable(preprocessReader, "vault.download", $"https://s3-us-west-2.amazonaws.com/neon-research/images/vault-{clusterDefinition.Vault.Version}.zip");
            SetBashVariable(preprocessReader, "vault.port", clusterDefinition.Vault.Port);
            SetBashVariable(preprocessReader, "vault.consulpath", "vault");
            SetBashVariable(preprocessReader, "vault.tlsdisabled", clusterDefinition.Vault.TlsDisabled);

            SetBashVariable(preprocessReader, "log.enabled", clusterDefinition.Log.Enabled);
            SetBashVariable(preprocessReader, "log.tdagent.osversion", clusterDefinition.Log.TDAgentVersion);
            SetBashVariable(preprocessReader, "log.tdagent.nodeimage", clusterDefinition.Log.TDAgentNodeImage);
            SetBashVariable(preprocessReader, "log.tdagent.clusterimage", clusterDefinition.Log.TDAgentCollectorImage);
            SetBashVariable(preprocessReader, "log.tdagent.node.bindip", clusterDefinition.Log.TDAgentNodeBindIP);
            SetBashVariable(preprocessReader, "log.tdagent.os.bindip", clusterDefinition.Log.TDAgentOsBindIP);
            SetBashVariable(preprocessReader, "log.tdagent.forwardport", clusterDefinition.Log.TDAgentForwardPort);
            SetBashVariable(preprocessReader, "log.tdagent.httpport", clusterDefinition.Log.TDAgentHttpPort);
            SetBashVariable(preprocessReader, "log.collector", clusterDefinition.Log.CollectorAddress);

            SetBashVariable(preprocessReader, "dotnet.enabled", clusterDefinition.Dotnet.Enabled);
            SetBashVariable(preprocessReader, "dotnet.version", clusterDefinition.Dotnet.Version);
        }

        /// <summary>
        /// Uploads a resource file to the remote server after performing any necessary preprocessing.
        /// </summary>
        /// <typeparam name="TMetadata">The server's metadata type.</typeparam>
        /// <param name="server">The remote server.</param>
        /// <param name="clusterDefinition">The cluster definition or <c>null</c>.</param>
        /// <param name="file">The resource file.</param>
        /// <param name="targetPath">The target path on the remote server.</param>
        private static void UploadFile<TMetadata>(this NodeManagementProxy<TMetadata> server, ClusterDefinition clusterDefinition, ResourceFiles.File file, string targetPath)
            where TMetadata : class
        {
            using (var input = file.ToStream())
            {
                if (file.HasVariables)
                {
                    // We need to expand any variables.  Note that if we don't have a
                    // cluster definition or for undefined variables, we're going to 
                    // have the variables expand to the empty string.

                    using (var msExpanded = new MemoryStream())
                    {
                        using (var writer = new StreamWriter(msExpanded))
                        {
                            var preprocessReader =
                                new PreprocessReader(new StreamReader(input))
                                {
                                    DefaultVariable = string.Empty,
                                    ExpandVariables = true,
                                    ProcessCommands = false,
                                    StripComments   = false
                                };

                            if (clusterDefinition != null)
                            {
                                SetClusterVariables(preprocessReader, clusterDefinition, server.Metadata as NodeDefinition);
                            }

                            foreach (var line in preprocessReader.Lines())
                            {
                                writer.WriteLine(line);
                            }

                            writer.Flush();

                            msExpanded.Position = 0;
                            server.UploadText(msExpanded, targetPath, tabStop: 4, outputEncoding: Encoding.UTF8);
                        }
                    }
                }
                else
                {
                    server.UploadText(input, targetPath, tabStop: 4, outputEncoding: Encoding.UTF8);
                }
            }
        }

        /// <summary>
        /// Uploads the configuration files for the target operating system to the server.
        /// </summary>
        /// <typeparam name="Metadata">The server's metadata type.</typeparam>
        /// <param name="server">The remote server.</param>
        /// <param name="clusterDefinition">The cluster definition or <c>null</c>.</param>
        public static void UploadConfFiles<Metadata>(this NodeManagementProxy<Metadata> server, ClusterDefinition clusterDefinition = null)
            where Metadata : class
        {
            Covenant.Requires<ArgumentNullException>(server != null);

            // Clear the contents of the configuration folder.

            server.Status = $"clear: {NodeHostFolder.ConfigFolder}";
            server.SudoCommand($"rm -rf {NodeHostFolder.ConfigFolder}/*.*");

            // Upload the files.

            server.Status = "upload: config...";

            foreach (var file in Program.LinuxFolder.GetFolder("conf").Files())
            {
                server.UploadFile(clusterDefinition, file, $"{NodeHostFolder.ConfigFolder}/{file.Name}");
            }

            foreach (var file in Program.LinuxFolder.GetFolder("default").Files())
            {
                server.UploadFile(clusterDefinition, file, $"/etc/default/{file.Name}");
            }

            // Secure the files and make the scripts executable.

            server.SudoCommand($"chmod 600 {NodeHostFolder.ConfigFolder}/*.*");
            server.SudoCommand($"chmod 700 {NodeHostFolder.ConfigFolder}/*.sh");

            server.Status = "copied";
        }

        /// <summary>
        /// Uploads the Docker compose files for the target operating system to the server.
        /// </summary>
        /// <typeparam name="Metadata">The server's metadata type.</typeparam>
        /// <param name="server">The remote server.</param>
        /// <param name="clusterDefinition">The cluster definition or <c>null</c>.</param>
        public static void UploadComposeFiles<Metadata>(this NodeManagementProxy<Metadata> server, ClusterDefinition clusterDefinition = null)
            where Metadata : class
        {
            Covenant.Requires<ArgumentNullException>(server != null);

            // Clear the contents of the configuration folder.

            server.Status = $"clear: {NodeHostFolder.ComposeFolder}";
            server.SudoCommand($"rm -rf {NodeHostFolder.ComposeFolder}/*.*");

            // Upload the files.

            server.Status = "upload: docker compose...";

            server.Status = "copied";
        }

        /// <summary>
        /// Uploads the setup related files for the target operating system to the server.
        /// </summary>
        /// <typeparam name="TMetadata">The server's metadata type.</typeparam>
        /// <param name="server">The remote server.</param>
        /// <param name="clusterDefinition">The cluster definition or <c>null</c>.</param>
        public static void UploadSetupFiles<TMetadata>(this NodeManagementProxy<TMetadata> server, ClusterDefinition clusterDefinition = null)
            where TMetadata : class
        {
            Covenant.Requires<ArgumentNullException>(server != null);

            // Clear the contents of the setup scripts folder.

            server.Status = $"clear: {NodeHostFolder.SetupFolder}";
            server.SudoCommand($"rm -rf {NodeHostFolder.SetupFolder}/*.*");

            // Upload the setup files.

            server.Status = "upload: setup files...";

            foreach (var file in Program.LinuxFolder.GetFolder("setup").Files())
            {
                server.UploadFile(clusterDefinition, file, $"{NodeHostFolder.SetupFolder}/{file.Name}");
            }

            // Make the scripts executable.

            server.SudoCommand($"chmod 700 {NodeHostFolder.SetupFolder}/*.sh");

            // Upload the current program as a Mono executable with a seamless
            // Bash script to a location on the server's path.  This will make
            // this command available for easy manual invocation on the Linux 
            // nodes.

            server.UploadMonoExecutable(Program.PathToExecutable, "neon-conf");

            server.Status = "copied";
        }

        /// <summary>
        /// Attempts to resolve the server's host name into an IP address.
        /// </summary>
        /// <typeparam name="TMetadata">The server's metadata type.</typeparam>
        /// <param name="server">The remote server.</param>
        /// <returns>The resolved IP address.</returns>
        /// <exception cref="ClusterDefinitionException">Thrown if an IP address couldn't be resolveds.</exception>
        public static IPAddress ResolveAddress<TMetadata>(this NodeManagementProxy<TMetadata> server)
            where TMetadata : class
        {
            IPAddress address;

            if (IPAddress.TryParse(server.DnsName, out address))
            {
                return address;
            }
            else
            {
                try
                {
                    var addresses = Dns.GetHostAddresses(server.DnsName);

                    if (addresses.Length > 1)
                    {
                        throw new ClusterDefinitionException($"DNS lookup for node [name={server.Name}] with [host-name={server.DnsName}] returned more than one address.");
                    }

                    return addresses[0];
                }
                catch (Exception e)
                {
                    throw new ClusterDefinitionException($"DNS lookup for node [name={server.Name}] with [host-name={server.DnsName}] failed: {NeonHelper.ExceptionError(e)}");
                }
            }
        }
    }
}
