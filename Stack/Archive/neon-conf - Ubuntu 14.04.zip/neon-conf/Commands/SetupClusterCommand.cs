﻿//-----------------------------------------------------------------------------
// FILE:	    SetupClusterCommand.cs
// CONTRIBUTOR: Jeff Lill
// COPYRIGHT:	Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Dynamic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using Newtonsoft;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

using Neon.Stack.Common;
using Neon.Stack.Docker;
using Neon.Stack.Management;
using Neon.Stack.Time;

namespace NeonConf
{
    /// <summary>
    /// Implements the <b>setup-cluster</b> command.
    /// </summary>
    public class SetupClusterCommand : ICommand
    {
        private const string usage = @"
neon-conf setup-cluster [--no-prep] DEFINITION-PATH

Configures a Neon cluster as described in the cluster definition file.

    --no-prep   - Indicates that the node has already been prepared
                  with the [neon-conf prep-node] so it won't be
                  prepared again.

NOTE: Preparing a node takes quite some time and includes substantial
      Internet downloads.

      For development and production environments, we recommend that
      you prepare a single bootable image to be used for all nodes
      and then instantiate base nodes using virtualization, PXE boot,
      etc.  Then use the [--no-prep] option when setting up your
      NeonCloud cluster.  A prepared Ubuntu-14.04 VHDX can be obtained
      from here:

      https://s3.amazonaws.com/neon-research/images/ubuntu-14.04-prep.vhdx
";
        private List<NodeManagementProxy<NodeDefinition>>   servers;
        private ClusterDefinition                           clusterDefinition;
        private string                                      managerNodeNames     = string.Empty;
        private string                                      managerNodeAddresses = string.Empty;
        private int                                         managerCount         = 0;

        /// <inheritdoc/>
        public string Name
        {
            get { return "setup-cluster"; }
        }

        /// <inheritdoc/>
        public bool NeedsCredentials
        {
            get { return true; }
        }

        /// <inheritdoc/>
        public void Help()
        {
            Console.WriteLine(usage);
        }

        /// <inheritdoc/>
        public void Run(CommandLine commandLine)
        {
            if (commandLine.Arguments.Length < 2)
            {
                Console.Error.WriteLine("Error: The cluster definition file path is required.");
                Program.Exit(1);
            };

            servers = new List<NodeManagementProxy<NodeDefinition>>();

            //---------------------------------------------

            // Parse the cluster definition and initialize the servers.

            clusterDefinition = ClusterDefinition.FromFile(commandLine.Arguments[1]);

            foreach (var nodeDefinition in clusterDefinition.SortedNodes)
            {
                var server = (Program.CreateNodeManagementProxy<NodeDefinition>(nodeDefinition.DnsName, nodeDefinition.Name));

                server.Metadata         = nodeDefinition;
                server.Metadata.Address = server.ResolveAddress();
                servers.Add(server);
            }

            // Ensure that the nodes have unique IP addresses.

            var ipAddressToServer = new Dictionary<IPAddress, NodeManagementProxy<NodeDefinition>>();

            foreach (var server in servers.OrderBy(s => s.Name))
            {
                NodeManagementProxy<NodeDefinition> duplicateServer;

                if (ipAddressToServer.TryGetValue(server.Metadata.Address, out duplicateServer))
                {
                    throw new ArgumentException($"Nodes [{duplicateServer.Name}] and [{server.Name}] share the same IP address [{server.Metadata.Address}].");
                }

                ipAddressToServer.Add(server.Metadata.Address, server);
            }

            // Generate a string with the IP addresses of the management nodes separated
            // by spaces.  We'll need this when we initialize the management nodes.
            //
            // We're also going to select the management address that we'll use to for
            // joining regular nodes to the cluster.  We'll use the first management
            // node when sorting in ascending order by name for this.

            foreach (var managerNodeDefinition in clusterDefinition.SortedManagers)
            {
                managerCount++;

                if (managerNodeNames.Length > 0)
                {
                    managerNodeNames     += " ";
                    managerNodeAddresses += " ";
                }

                managerNodeNames     += managerNodeDefinition.Name;
                managerNodeAddresses += managerNodeDefinition.Address.ToString();
            }

            // Perform the operation.

            var operation = new SetupController(this.Name, servers);

            operation.AddWaitUntilOnlineStep("connecting");

            if (!commandLine.HasOption("--no-prep"))
            {
                operation.AddStep("preparing", server => CommonSteps.PrepareNode(server));
            }

            operation.AddStep("common config", s => ConfigureCommon(s));
            operation.AddStep("manager cluster", s => ConfigureManagerCluster(s), s => s.Metadata.Manager);
            operation.AddStep("create networks", s => CreateNetworks(s), s => s.Metadata == clusterDefinition.SortedManagers.First());
            operation.AddStep("manager config", s => ConfigureManager(s), s => s.Metadata.Manager);
            operation.AddStep("worker config", s => ConfigureWorker(s), s => s.Metadata.Worker);

            if (clusterDefinition.Log.Enabled)
            {
                operation.AddStep("start swarm cluster", WaitForSwarm);
                operation.AddGlobalStep("logging services", () => DeployLogServices(clusterDefinition, servers));
            }

            operation.AddDelayStep($"stablize cluster ({Program.WaitSeconds}s)", TimeSpan.FromSeconds(Program.WaitSeconds), "stablizing");
            operation.AddStep("manager diagnostics", s => ClusterDiagnostics.CheckClusterManager(s, clusterDefinition), s => s.Metadata.Manager);
            operation.AddStep("worker diagnostics", s => ClusterDiagnostics.CheckClusterWorker(s, clusterDefinition), s => s.Metadata.Worker);

            operation.Run();
        }

        /// <summary>
        /// Configures the global environment variables that describe the configuration 
        /// of the server within the cluster.
        /// </summary>
        /// <param name="server">The server to be updated.</param>
        /// <param name="clusterDefinition">The cluster definition.</param>
        private void ConfigureEnvironmentVariables(NodeManagementProxy<NodeDefinition> server, ClusterDefinition clusterDefinition)
        {
            // We're going to append the new variables to the existing Linux [/etc/environment] file.

            var sb = new StringBuilder();

            // Append all of the existing environment variables except for those
            // whose names start with "NEON_" to make the operation idempotent.

            using (var currentEnvironmentStream = new MemoryStream())
            {
                server.Download("/etc/environment", currentEnvironmentStream);

                currentEnvironmentStream.Position = 0;

                using (var reader = new StreamReader(currentEnvironmentStream))
                {
                    foreach (var line in reader.Lines())
                    {
                        if (!line.StartsWith("NEON_"))
                        {
                            sb.AppendLine(line);
                        }
                    }
                }
            }

            // Add the Neon cluster related environment variables. 

            sb.AppendLine($"NEON_NODE_NAME={server.Name}");
            sb.AppendLine($"NEON_HOST_DNSNAME={server.DnsName.ToLowerInvariant()}");
            sb.AppendLine($"NEON_HOST_IP={server.Metadata.Address}");
            sb.AppendLine($"NEON_HOST_SSD={server.Metadata.Labels.StorageSSD.ToString().ToLowerInvariant()}");
            sb.AppendLine($"NEON_CLUSTER={clusterDefinition.Name}");
            sb.AppendLine($"NEON_DATACENTER={clusterDefinition.Datacenter.ToLowerInvariant()}");
            sb.AppendLine($"NEON_ENVIRONMENT={clusterDefinition.Environment.ToString().ToLowerInvariant()}");
            sb.AppendLine($"NEON_MANAGER={server.Metadata.Manager.ToString().ToLowerInvariant()}");

            using (var textStream = new MemoryStream(Encoding.UTF8.GetBytes(sb.ToString())))
            {
                server.UploadText(textStream, "/etc/environment", tabStop: 4);
            }
        }

        /// <summary>
        /// Performs common node configuration.
        /// </summary>
        /// <param name="server">The target server.</param>
        private void ConfigureCommon(NodeManagementProxy<NodeDefinition> server)
        {
            server.Status = "setup: environment...";
            ConfigureEnvironmentVariables(server, clusterDefinition);

            // Upload the setup and configuration files.

            server.InitializeNeonFolders();
            server.UploadConfFiles(clusterDefinition);
            server.UploadComposeFiles(clusterDefinition);
            server.UploadSetupFiles(clusterDefinition);

            // Perform basic node setup including changing the host name.

            server.Status = "run: setup-node.sh";
            server.SudoCommand("setup-node.sh");

            // Reboot to pick up the host name change and the new global
            // environment variables.

            server.Status = "rebooting...";
            server.Reboot(wait: true);

            // Perform other common configuration.

            server.Status = "run: setup-ssd.sh";
            server.SudoCommand("setup-ssd.sh");

            server.Status = "run: setup-dotnet.sh";
            server.SudoCommand("setup-dotnet.sh");
        }

        /// <summary>
        /// Configure the manager cluster.
        /// </summary>
        /// <param name="server">The target server.</param>
        public void ConfigureManagerCluster(NodeManagementProxy<NodeDefinition> server)
        {
            server.Status = "run: setup-ntp.sh";
            server.SudoCommand("setup-ntp.sh");

            server.Status = "run: setup-consul-server.sh";
            server.SudoCommand("setup-consul-server.sh", clusterDefinition.Consul.EncryptionKey);

            // Bootstrap Consul cluster discovery.

            var discoveryTimer = new PolledTimer(TimeSpan.FromMinutes(2));

            server.Status = "bootstrap consul";

            while (true)
            {
                if (server.SudoCommand($"consul join {managerNodeAddresses}", RunOption.None).ExitCode == 0)
                {
                    break;
                }

                if (discoveryTimer.HasFired)
                {
                    server.Fault($"Unable to form Consul cluster for [{discoveryTimer.Interval}].");
                    break;
                }

                Thread.Sleep(TimeSpan.FromSeconds(5));
            }

            server.Status = "run: setup-docker.sh";
            server.SudoCommand("setup-docker.sh");
        }

        /// <summary>
        /// Create cluster networks.
        /// </summary>
        /// <param name="server">The target server.</param>
        public void CreateNetworks(NodeManagementProxy<NodeDefinition> server)
        {
            // NOTE: This is called only for the first manager node.

            server.Status = "create: network(s)";

            var name   = clusterDefinition.Network.Name;
            var driver = clusterDefinition.Weave.Network.Enabled ? "weavemesh" : "overlay";
            var subnet = clusterDefinition.Network.Subnet;

            server.SudoCommand("docker network create", $"--driver={driver}", $"--subnet={subnet}", name);
        }

        /// <summary>
        /// Complete a manager node configuration.
        /// </summary>
        /// <param name="server">The target server.</param>
        public void ConfigureManager(NodeManagementProxy<NodeDefinition> server)
        {
            server.Status = "run: setup-network.sh";
            server.SudoCommand("setup-network.sh", clusterDefinition.Weave.Network.Enabled ? clusterDefinition.Weave.Network.EncryptionKey : string.Empty);

            server.Status = "run: setup-tdagent.sh";
            server.SudoCommand("setup-tdagent.sh");

            server.Status = "run: setup-docker-compose.sh";
            server.SudoCommand("setup-docker-compose.sh");

            server.Status = "run: setup-swarm-manager.sh";
            server.SudoCommand("setup-swarm-manager.sh");

            server.Status = "run: setup-etcd-server.sh";
            server.SudoCommand("setup-etcd-server.sh");

            server.Status = "run: setup-weave-scope.sh";
            server.SudoCommand("setup-weave-scope.sh");

            // Weave Flux is deployed to both manager and workers
            // if it's enabled.

            server.Status = "run: setup-weave-flux.sh";
            server.SudoCommand("setup-weave-flux.sh");

            // Configure Vault

            server.Status = "run: setup-vault.sh";
            server.SudoCommand("setup-vault.sh");

            // Cleanup any cached APT files.

            server.Status = "cleanup";
            server.SudoCommand("apt-get clean -yq");
            server.SudoCommand("rm -rf /var/lib/apt/lists");
        }

        /// <summary>
        /// Configures a worker node.
        /// </summary>
        /// <param name="server">The target server.</param>
        private void ConfigureWorker(NodeManagementProxy<NodeDefinition> server)
        {
            // Configure the worker.

            server.Status = "run: setup-ntp.sh";
            server.SudoCommand("setup-ntp.sh");

            server.Status = "run: setup-consul-proxy.sh";
            server.SudoCommand("setup-consul-proxy.sh", clusterDefinition.Consul.EncryptionKey);

            // Join this node's Consul agent to the masters.

            var discoveryTimer = new PolledTimer(TimeSpan.FromMinutes(2));

            server.Status = "join consul";

            while (true)
            {
                if (server.SudoCommand($"consul join {managerNodeAddresses}", RunOption.None).ExitCode == 0)
                {
                    break;
                }

                if (discoveryTimer.HasFired)
                {
                    server.Fault($"Unable to join Consul cluster for [{discoveryTimer.Interval}].");
                    break;
                }

                Thread.Sleep(TimeSpan.FromSeconds(5));
            }

            server.Status = "run: setup-docker.sh";
            server.SudoCommand("setup-docker.sh");

            server.Status = "run: setup-network.sh";
            server.SudoCommand("setup-network.sh", clusterDefinition.Weave.Network.Enabled ? clusterDefinition.Weave.Network.EncryptionKey : string.Empty);

            server.Status = "run: setup-tdagent.sh";
            server.SudoCommand("setup-tdagent.sh");

            server.Status = "run: setup-docker-compose.sh";
            server.SudoCommand("setup-docker-compose.sh");

            server.Status = "run: setup-swarm-agent.sh";
            server.SudoCommand("setup-swarm-agent.sh");

            server.Status = "run: setup-etcd-proxy.sh";
            server.SudoCommand("setup-etcd-proxy.sh");

            server.Status = "run: setup-weave-scope.sh";
            server.SudoCommand("setup-weave-scope.sh");

            // Weave Flux is deployed to both manager and workers
            // if it's enabled.

            server.Status = "run: setup-weave-flux.sh";
            server.SudoCommand("setup-weave-flux.sh");

            // Configure Vault

            server.Status = "run: setup-vault.sh";
            server.SudoCommand("setup-vault.sh");

            // Cleanup any cached APT files.

            server.Status = "cleanup";
            server.SudoCommand("apt-get clean -yq");
            server.SudoCommand("rm -rf /var/lib/apt/lists");
        }

        /// <summary>
        /// Ensures that the docker engine is ready on the node as well as the Swarm Manager for
        /// Manager nodes.
        /// </summary>
        /// <param name="server">The target server.</param>
        private void WaitForSwarm(NodeManagementProxy<NodeDefinition> server)
        {
            using (var docker = new DockerSettings(server.Metadata.Address, clusterDefinition.Docker.Port).CreateClient())
            {
                docker.WaitUntilReadyAsync().Wait();
            }

            if (server.Metadata.Manager)
            {
                using (var swarm = new DockerSettings(server.Metadata.Address, clusterDefinition.Swarm.Port).CreateClient())
                {
                    swarm.WaitUntilReadyAsync().Wait();
                }
            }
        }

        /// <summary>
        /// Deploys the cluster logging related services to the cluster.
        /// </summary>
        /// <param name="clusterDefinition">The cluster definition.</param>
        /// <param name="servers">The cluster servers.</param>
        private void DeployLogServices(ClusterDefinition clusterDefinition, List<NodeManagementProxy<NodeDefinition>> servers)
        {
            // Choose the manager node we'll use to bring up the log services.

            var manager = servers.First(s => s.Metadata.Manager);

            //-----------------------------------------------------------------
            // Elasticsearch deployment

            // Create the named database volumes the Elasticsearch containers will bind to.  
            // We'll be submitting Docker commands to the specific nodes where we'll want 
            // Elasticsearch to be deployed.
            //
            // Note that we're not going to recreate volumes that already exist.

            var esDeployment    = ComposeLogServices.ElasticsearchDeployment(clusterDefinition);
            var existingVolumes = new HashSet<string>();

            using (var dockerSwarm = new DockerSettings(manager.Metadata.Address, clusterDefinition.Swarm.Port).CreateClient())
            {
                try
                {
                    // List the existing Swarm volumes, so we won't inadvertantly create
                    // multiple volumes with the same name.

                    manager.Status = "listing cluster volumes";

                    var response = dockerSwarm.VolumeListAsync().Result;

                    foreach (var volume in response.Volumes)
                    {
                        // Strip off the node path because Docker Compose assumes 
                        // that named volumes will be unique across the cluster.

                        string  volumeName = volume.Name;
                        int     pos        = volumeName.IndexOf('/');

                        if (pos >= 0)
                        {
                            volumeName = volumeName.Substring(pos + 1);
                        }

                        existingVolumes.Add(volumeName);
                    }

                    manager.Status = string.Empty;
                }
                catch (Exception e)
                {
                    manager.Fault(NeonHelper.ExceptionError(e));
                }
            }

            foreach (var volume in esDeployment.Volumes)
            {
                if (existingVolumes.Contains(volume.Name))
                {
                    continue;
                }

                var server = servers.Single(s => s.Name.Equals(volume.Node.Name, StringComparison.InvariantCultureIgnoreCase));

                using (var dockerNode = new DockerSettings(server.Metadata.Address, clusterDefinition.Docker.Port).CreateClient())
                {
                    try
                    {
                        server.Status = $"[{volume.Name}] creating volume.";

                        dockerNode.VolumeCreate(volume.Name).Wait();

                        server.Status = $"[{volume.Name}] volume created";
                    }
                    catch (Exception e)
                    {
                        server.Fault(NeonHelper.ExceptionError(e));
                    }
                }
            }

            // Fire up the Elasticsearch instances using Docker Compose.  Note that we need to
            // run [neoncloud.conf.sh] to pick up the environment variables.

            foreach (var volume in esDeployment.Volumes)
            {
                servers.First(s => s.Name == volume.Node.Name).Status = "elasticsearch deploy";
            }

            var bundle = new CommandBundle($". {NodeHostFolder.ConfigFolder}/neoncloud.conf.sh && swarm-compose -f {esDeployment.ProjectName}/docker-compose.yml up -d")
            {
                new CommandFile() { Path = $"{esDeployment.ProjectName}/docker-compose.yml", Text = esDeployment.ComposeFile }
            };

            manager.SudoCommand(bundle);



            // Indicate that we're done.

            foreach (var server in servers)
            {
                server.IsReady = true;
            }
        }
    }
}
