﻿//-----------------------------------------------------------------------------
// FILE:	    SampleDefCommand.cs
// CONTRIBUTOR: Jeff Lill
// COPYRIGHT:	Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using Newtonsoft;
using Newtonsoft.Json;

using Neon.Stack.Common;
using Neon.Stack.Management;

namespace NeonConf
{
    /// <summary>
    /// Implements the <b>sample-def</b> command.
    /// </summary>
    public class SampleDefCommand : ICommand
    {
        private const string usage = @"
neon-conf sample-def

Writes a sample cluster definition file to the standard output.  You
can use this as a starting point for creating a customized definition.
";
        /// <inheritdoc/>
        public string Name
        {
            get { return "sample-def"; }
        }

        /// <inheritdoc/>
        public bool NeedsCredentials
        {
            get { return false; }
        }

        /// <inheritdoc/>
        public void Help()
        {
            Console.WriteLine(usage);
        }

        /// <inheritdoc/>
        public void Run(CommandLine commandLine)
        {
            const string sampleJson =
@"//-----------------------------------------------------------------------------
// This is a sample cluster definition file.  This can be a good starting point 
// for creating a custom cluster.
//
// The file format is JSON with some preprocessing capabilities.  Scroll down to
// the bottom of the file for more information.

//-----------------------------------------------------------------------------
// Definitions:

// Consul and Weave encrypt network traffic between cluster nodes with shared 
// 16-byte Base64 encoded keys.  These keys can be the same or different.  Use
// [null] or the empty string to disable encryption.
//
// You can generate a new key via:
//
//      neon-conf generate-key

#define consul-key = ""j8iZXbQ6/mxisZhXmZ5LeQ==""
#define weave-key  = ""j8iZXbQ6/mxisZhXmZ5LeQ==""

//-----------------------------------------------------------------------------
// The JSON below defines a Docker cluster with three manager and ten worker
// host nodes.
//
// Naming: Cluster, datacenter and node names may be one or more characters 
//         including case insensitive letters, numbers, dashes, underscores,
//         or periods.

{
    //-------------------------------------------------------------------------
    // This section describes the cluster.
    //
    //  Name            - Cluster name
    //  Datacenter      - Datacenter name
    //  Environment     - Describes the type of environment, one of:
    //
    //                      Unknown, Development, Test, Stage, or Production
    //
    //  TimeSources     - The FQDNs or IP addresses of the NTP time sources
    //                    used to synchronize the cluster as an array of
    //                    strings.  Reasonable defaults will be used if
    //                    not specified.
    //
    //  DotnetVersion   - The version of .NET Core to be installed on the cluster
    //                    host nodes.  This defaults to the latest released
    //                    version.

    ""Name"": ""my-cluster"",
    ""Datacenter"": ""Seattle"",
    ""Environment"": ""Dev"",
    ""TimeSources"": [ ""0.pool.ntp.org"", ""1.pool.ntp.org"", ""2.pool.ntp.org"" ],

    // HashiCorp Consul distributed service discovery and key/valuestore settings.
    
    ""Consul"": {

        //  Version               The version to be installed.  This defaults to
        //                        a reasonable recent version.
        //
        //  EncryptionKey         16-byte shared secret (Base64) used to encrypt 
        //                        Consul network traffic.  Set the empty string or
        //                        null to disable encryption.  Use the command 
        //                        below to generate a new key:
        //
        //                              neon-conf generate-key 
        //
        //  Advanced              Advanced Consul command line options

        ""EncryptionKey"": $<consul-key>,
        ""Advanced"": null
    },

    // Etcd distributed key/valuestore settings.  Note that this is required
    // by Weave Flux.
    //
    // Etcd depends on Weave Networking (which must be enabled).
    
    ""Etcd"": {

        //  Version               The version to be installed.  This defaults to
        //                        a reasonable recent version.
        //
        //  Enabled               Indicates that Etcd will be deployed to the
        //                        manager nodes.  This defaults to [true].

        ""Enabled"":true
    },

    // Docker Swarm cluster container orchestration.

    ""Swarm:"": {

        //  Version               The version to be installed.  This defaults to
        //                        a reasonable recent version.
        //
        //  Strategy              Specifies how Docker Swarm schedules containers
        //                        on nodes.  This defaults to [Spread].  The 
        //                        possible options are:
        //
        //                              Spread, Binpack, or Random
        //
        //  AdvancedManager       Advanced manager command line options
        //  AdvancedAgent         Advanced agent command line options

        ""Strategy"": ""Spread"",
        ""AdvancedManager"": null,
        ""AdvancedAgent"": null
    },

    // Docker overlay network settings.

    ""Network"": {

        //  Subnet                  The network subnet in CIDR notation in which Docker
        //                          or Weave overlay networks will assign IP addresses 
        //                          to Docker containers.  This defaults to 10.64.0.0/16
        //                          which provides for 64K unique addresses.
        // 
        
        ""Subnet"" : ""10.64.0.0/16""
    },

    // Weaveworks networking related settings.

    ""Weave"": {

        // Weave network overlay options.

        ""Network"": {

            //  Enabled           Indicates that Weave Networking will be enabled.
            //                    This defaults to FALSE due to a Docker plugin
            //                    design flaw.
            //
            //  Version           The version to be installed.  This defaults to
            //                    a reasonable recent version.
            //
            //  Plugin            Indicates that the Weave Docker plugin should be
            //                    configured for the cluster rather than using the
            //                    Weave API proxy.  This defaults to TRUE.
            //
            //  EncryptionKey     16-byte shared secret (Base64) used to encrypt 
            //                    Weave network traffic.  Set the empty string or
            //                    null to disable encryption.  Use the command 
            //                    below to generate a new key:
            //
            //                          neon-conf generate-key 

            ""Enabled"": false,
            ""Plugin"": true,
            ""EncryptionKey"": $<weave-key>
        },

        // Weave Scope topology dashboard options.

        ""Scope"": {

            //  Version           The version to be installed.  This defaults to
            //                    a reasonable recent version.
            //
            //  CtlVersion        The version of FluxCtl to be installed.  This
            //                    defaults to [Version] but may be overriden
            //                    if necessary.
            //
            //  Enabled           Indicates that Weave Scope should be deployed on
            //                    all nodes.  This defaults to [true].

            ""Enabled"": false
        },

        // Weave Flux load balancing options.
        //
        // Note: Weave Flux depends on Weave Network and Etcd.  Both must be enabled.

        ""Flux"": {

            //  Version           The version to be installed.  This defaults to
            //                    a reasonable recent version.
            //
            //  Enabled           Indicates that Weave Flux should be deployed on
            //                    all nodes.  This defaults to [true].

            ""Enabled"": true
        },

        // HashiCorp Vault secret server options.
        //
        // Note: Vault depends Consul which must be enabled.

        ""Vault"": {

            //  Version           The version to be installed.  This defaults to
            //                    a reasonable recent version.
            //
            //  Enabled           Indicates that Vault should be deployed on
            //                    all nodes.  This defaults to [false].
            //
            //  TlsDisabled       Indicates that communication will not be
            //                    secured.  This should not be set in production.
            //                    This defaults to [false].

            ""Enabled"": false,
            ""TlsEnabled"": false
        },

        // Cluster logging options.
        //
        // Logging requires that Weave Network also be enabled.

        ""Log"": {

            //  Enabled               Indicates that cluster logging is enabled.
            //                        This defaults to [true].
            //
            //  TDAgentVersion        The version of the Treasure Data [tg-agent]
            //                        (Fluentd-style) logging agent to be installed
            //                        on the host nodes.  This defaults to a reasonable
            //                        recent version.
            //
            //  TDAgentNodeImage      The [td-agent] Docker image to be run on each
            //                        node to forward log events to the cluster's
            //                        log aggregator.  This defaults to
            //                        [neoncloud/td-agent].
            //
            //  TDAgentCollectorImage The [td-agent] Docker image to be run as
            //                        a service on the cluster that aggregates log
            //                        events from the nodes and pushes them into
            //                        Elasticsearch.  This defaults to 
            //                        [neoncloud/td-agent].
            //
            //  ElasticsearchImage    The [Elasticsearch] Docker image to be used
            //                        to persist cluster log events.  This defaults to 
            //                        [neoncloud/elasticsearch].
            //
            //  CollectorAddress      The address where the nodes will forward log
            //                        events.  This defaults to the Neon cluster
            //                        log collector service at:
            //
            //                            log-collector.neon.cluster.local:24224
            //
            //  EsInstances           The number of Elasticsearch database containers to
            //                        be deployed.  This defaults to 1.
            //
            //  EsConstraints         Zero or more Docker Swarm style container placement
            //                        constraints referencing built-in or custom
            //                        node labels used to locate Elasticsearch containers.
            //
            //  EsShards              The number of Elasticsearch shards.
            //                        This defaults to 1.
            //
            //  EsReplicas            The number of Elasticsearch replicas.
            //                        This defaults to 1.
            //
            //  CollectorInstances    The number of TD-Agent based collectors to be deployed
            //                        to receive, transform, and persist events collected by
            //                        the cluster nodes.  This defaults to 1.
            //
            //  CollectorConstraints  Zero or more Docker Swarm style container placement
            //                        constraints referencing built-in or custom
            //                        node labels used to locate TD-Agent collector
            //                        containers.
            //
            //  KibanaInstances       The number of Kibana daskboard containers to be deployed.
            //                        This defaults to 1.
            //
            //  KibanaConstraints     Zero or more Docker Swarm style container placement
            //                        constraints referencing built-in or custom
            //                        node labels used to locate Kibana containers.
            //

            ""Enabled"": true,
            ""EsInstances"": 1,
            ""EsConstraints"": [],
            ""EsShards"": 1,
            ""EsReplicas"": 1,
            ""CollectorInstances"": 1,
            ""CollectorConstraints"": [],
            ""KibanaInstances"": 1,
            ""KibanaConstraints"": []
        },

        // .NET Core options.

        ""DotNet"": {

            //  Version           The version to be installed.  This defaults to
            //                    a reasonable recent version.
            //
            //  Enabled           Indicates that Weave Flux should be deployed on
            //                    all nodes.  This defaults to [false].

            ""Enabled"": false,
            ""Version"": null
        }
    },

    //-------------------------------------------------------------------------
    // This section describes the physical and/or virtual machines that 
    // will host your cluster.  There are two basic types of nodes:
    //
    //      * Manager Nodes
    //      * Worker Nodes
    //
    // Manager nodes handle the cluster management tasks.  Both types of
    // nodes can host application containers.
    //
    //      DnsName         - IP address or FQDN of the node
    //      Manager         - true for manager nodes (default=false)
    //
    // Node Labels
    // -----------
    // Node details can be specified using Docker labels.  These labels
    // will be passed to the Docker daemon when it is launched so they
    // will be available for Swarm filtering operations.  Some labels
    // are also used during cluster configuration.
    //
    // You'll use the [Labels] property to specifiy labels.  NeonCloud
    // predefines several labels.  You may extend these using [Labels.Custom].
    //
    // The [io.neoncloud] prefix is reserved for NeonCloud related labels.
    // The following reserved labels are currently supported (see the documentation
    // for more details):
    //
    //      StorageCapacity               Storage in MB (int)
    //      StorageLocal                  Storage is local (bool)
    //      StorageSSD                    Storage is backed by SSD (bool)
    //      StorageRedundant              Storage is redundant (bool)
    //      StorageEphemeral              Storage is ephemeral (bool)
    //
    //      ComputeCores                  Number of CPU cores (int)
    //      ComputeArchitecture           x32, x64, arm32, arm64
    //      ComputeRAM                    RAM in MB
    //
    //      PhysicalLocation              location (string)
    //      PhysicalMachine               computer model (string)
    //      PhysicalFaultDomain           fault domain (string)
    //      PhysicalPower                 power (string)
    //
    // IMPORTANT: Be sure to set [StorageSSD=true] if your 
    //            node is backed by a SSD so that cluster setup will tune
    //            Linux for better performance.
    //
    // NOTE:      Docker does not support whitespace in label values.

    ""Nodes"": {

        //---------------------------------------------------------------------
        // Describe the cluster management nodes by setting [Manager=true].
        // Management nodes host Consul service discovery, Vault secret 
        // management, and the Docker Swarm managers.
        // 
        // Neon clusters must have at least one manager node.  To have
        // high availability, you may deploy three or five management node.
        // Only an odd number of management nodes are allowed up to a
        // maximum of five.  A majority of these must be healthy for the 
        // cluster as a whole to function.
        //
        // Note: 
        //
        // Swarm will not deploy containers to manager hosts.  For large 
        // clusters, you'll probably want have dedicated hardware for these
        // anyway.  For smaller clusters, you may deploy management nodes
        // as VMs on physical servers that also host worker Swarm nodes.

        ""Manage-0"": {
            ""DnsName"": ""manage-0.lilltek.net"",
            ""Manager"": true,
            ""Labels"": {
                ""StorageSSD"": true,
                ""Custom"": {
                    ""MyLabel"": ""Hello World!""
                }
            }
        },
        ""Manage-1"": {
            ""DnsName"": ""manage-1.lilltek.net"",
            ""Manager"": true,
            ""Labels"": {
                ""StorageSSD"": true
            }
        },
        ""Manage-2"": {
            ""DnsName"": ""manage-2.lilltek.net"",
            ""Manager"": true,
            ""Labels"": {
                ""StorageSSD"": true
            }
        },

        //---------------------------------------------------------------------
        // Describe the worker cluster nodes by leaving [Manager=false].
        // Swarm will schedule containers to run on these nodes.

        ""Node-0"": {
            ""DnsName"": ""node-0.lilltek.net"",
            ""Labels"": {
                ""StorageSSD"": true
            }
        },
        ""Node-1"": {
            ""DnsName"": ""node-1.lilltek.net"",
            ""Labels"": {
                ""StorageSSD"": true
            }
        },
        ""Node-2"": {
            ""DnsName"": ""node-2.lilltek.net"",
            ""Labels"": {
                ""StorageSSD"": true
            }
        },
        ""Node-3"": {
            ""DnsName"": ""node-3.lilltek.net"",
            ""Labels"": {
                ""StorageSSD"": true
            }
        },
        ""Node-4"": {
            ""DnsName"": ""node-3.lilltek.net"",
            ""Labels"": {
                ""StorageSSD"": true
            }
        },
        ""Node-5"": {
            ""DnsName"": ""node-3.lilltek.net"",
            ""Labels"": {
                ""StorageSSD"": true
            }
        },
        ""Node-6"": {
            ""DnsName"": ""node-3.lilltek.net"",
            ""Labels"": {
                ""StorageSSD"": true
            }
        },
        ""Node-7"": {
            ""DnsName"": ""node-3.lilltek.net"",
            ""Labels"": {
                ""StorageSSD"": true
            }
        },
        ""Node-8"": {
            ""DnsName"": ""node-3.lilltek.net"",
            ""Labels"": {
                ""StorageSSD"": true
            }
        },
        ""Node-9"": {
            ""DnsName"": ""node-3.lilltek.net"",
            ""Labels"": {
                ""StorageSSD"": true
            }
        }
    }
}

//-----------------------------------------------------------------------------
// Cluster definition files are preprocessed to remove comments as well as to
// implement variables and conditionals:
//
//      * Comment lines
//
//      * Variables defined like: 
//
//          #define myvar1
//          #define myvar2=Hello
//
//      * Variables referenced via:
//
//          $<myvar1>
//
//      * Environment variables referenced via:
//
//          $<<ENV_VAR>>
//
//      * If statements:
//
//          #define DEBUG=TRUE
//          #if $<DEBUG>==TRUE
//              Do something
//          #else
//              Do something else
//          #endif
//
//          #if defined(DEBUG)
//              Do something
//          #endif
//
//          #if undefined(DEBUG)
//              Do something
//          #endif
//
//      * Switch statements:
//
//          #define datacenter=uswest
//          #switch $<datacenter>
//              #case uswest
//                  Do something
//              #case useast
//                  Do something else
//              #default
//                  Do the default thing
//          #endswitch
";
            Console.Write(sampleJson);
        }
    }
}
