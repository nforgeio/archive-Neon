﻿//-----------------------------------------------------------------------------
// FILE:	    UpdateToolsCommand.cs
// CONTRIBUTOR: Jeff Lill
// COPYRIGHT:	Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using Newtonsoft;
using Newtonsoft.Json;

using Neon.Stack.Common;
using Neon.Stack.Management;
using Neon.Stack.Time;

namespace NeonConf
{
    /// <summary>
    /// Implements the <b>update-tools</b> command.
    /// </summary>
    public class UpdateToolsCommand : ICommand
    {
        private const string usage = @"
neon-conf update-tools DEFINITION-PATH
neon-conf update-tools SERVER1 [ SERVER2... ]

Uploads the current versions of the neon tools and scripts to servers, 
deleting and overwriting the existing scripts.  The command has two
versions:

    * The first loads the cluster definition file and uploads
      the tools and scripts to all nodes in the cluster.

    * The second uploads the tools and scripts to specific servers
      using their DNS name or IP address.
";
        private List<NodeManagementProxy<NodeDefinition>>   servers;

        /// <inheritdoc/>
        public string Name
        {
            get { return "update-tools"; }
        }

        /// <inheritdoc/>
        public bool NeedsCredentials
        {
            get { return true; }
        }

        /// <inheritdoc/>
        public void Help()
        {
            Console.WriteLine(usage);
        }

        /// <inheritdoc/>
        public void Run(CommandLine commandLine)
        {
            if (commandLine.Arguments.Length < 2)
            {
                Console.Error.WriteLine("Error: The cluster definition file path or at least one server must be specified.");
                Program.Exit(1);
            }

            servers = new List<NodeManagementProxy<NodeDefinition>>();

            // If there's only one argument and it refers to a file that exists, then
            // assume it's a cluster definition file and initialize the servers from
            // there.
            //
            // Otherwise, we'll expect the arguments to be server DNS names or IP
            // addresses.

            ClusterDefinition clusterDefinition = null;

            if (commandLine.Arguments.Length == 2 && File.Exists(commandLine.Arguments[1]))
            {
                clusterDefinition = ClusterDefinition.FromFile(commandLine.Arguments[1]);

                foreach (var node in clusterDefinition.SortedNodes)
                {
                    servers.Add(Program.CreateNodeManagementProxy<NodeDefinition>(node.DnsName, node.Name));
                }
            }
            else
            {
                foreach (var serverHost in commandLine.GetArguments(1))
                {
                    servers.Add(Program.CreateNodeManagementProxy<NodeDefinition>(serverHost));
                }
            }

            // Perform the operation.

            var operation = new SetupController(Name, servers);

            operation.AddWaitUntilOnlineStep("waiting for servers");
            operation.AddStep("updating tools",
                server =>
                {
                    server.InitializeNeonFolders();
                    server.UploadSetupFiles(clusterDefinition);
                });

            operation.Run();
        }

        /// <summary>
        /// Displays server status.
        /// </summary>
        /// <param name="waitForReady">Indicates that status should be displayed continuously until all servers indicate they're ready or any are faulted.</param>
        private void DisplayStatus(bool waitForReady = false)
        {
            if (waitForReady)
            {
                while (true)
                {
                    DisplayStatus();

                    Thread.Sleep(TimeSpan.FromSeconds(2));

                    if (!servers.Exists(s => !s.IsReady))
                    {
                        break;
                    }

                    // Display status for another minute if any servers are faulted 
                    // as a diagnostic and then terminate.  The delay may provide
                    // useful additional diagnostics.

                    if (servers.Exists(s => s.IsFaulted))
                    {
                        var timer = new PolledTimer(TimeSpan.FromMinutes(1));

                        while (!timer.HasFired)
                        {
                            DisplayStatus();
                            Thread.Sleep(TimeSpan.FromSeconds(2));
                        }
                    }
                }

                DisplayStatus();
            }
            else
            {
                Console.Clear();
                Console.WriteLine(Name);
                Console.WriteLine();
                Console.WriteLine();
                Console.WriteLine($"{"Server",-20}Status");
                Console.WriteLine("-----------------------------------------------------------");

                foreach (var server in servers)
                {
                    Console.WriteLine($"{server.Name,-20}{server.Status}");
                }

                Console.WriteLine();
                Console.WriteLine();
            }
        }

        /// <summary>
        /// Sets the <see cref="NodeManagementProxy{TMetadata}.IsReady"/> state for all servers.
        /// </summary>
        /// <param name="isReady">The new state.</param>
        private void SetServerReady(bool isReady)
        {
            foreach (var server in servers)
            {
                server.IsReady = isReady;
            }
        }
    }
}
