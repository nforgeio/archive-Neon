﻿//-----------------------------------------------------------------------------
// FILE:	    ValidateDefCommand.cs
// CONTRIBUTOR: Jeff Lill
// COPYRIGHT:	Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using Newtonsoft;
using Newtonsoft.Json;

using Neon.Stack.Common;
using Neon.Stack.Management;

namespace NeonConf
{
    /// <summary>
    /// Implements the <b>validate-def</b> command.
    /// </summary>
    public class ValidateDefCommand : ICommand
    {
        private const string usage = @"
neon-conf validate-def DEFINITION-PATH

Validates a cluster definition file.
";

        /// <inheritdoc/>
        public string Name
        {
            get { return "validate-def"; }
        }

        /// <inheritdoc/>
        public bool NeedsCredentials
        {
            get { return false; }
        }

        /// <inheritdoc/>
        public void Help()
        {
            Console.WriteLine(usage);
        }

        /// <inheritdoc/>
        public void Run(CommandLine commandLine)
        {
            if (commandLine.Arguments.Length < 2)
            {
                Console.Error.WriteLine("Error: The cluster definition file path is required.");
                Program.Exit(1);
            }

            // Parse and validate the cluster definition and initialize the servers.

            ClusterDefinition.FromFile(commandLine.Arguments[1]);

            Console.WriteLine("");
            Console.WriteLine("The cluster definition is OK.");
        }
    }
}
