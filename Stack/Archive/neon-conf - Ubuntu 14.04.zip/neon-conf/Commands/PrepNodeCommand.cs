﻿//-----------------------------------------------------------------------------
// FILE:	    PrepNodeCommand.cs
// CONTRIBUTOR: Jeff Lill
// COPYRIGHT:	Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using Neon.Stack.Common;
using Neon.Stack.Management;

namespace NeonConf
{
    /// <summary>
    /// Implements the <b>prep-node</b> command.
    /// </summary>
    public class PrepNodeCommand : ICommand
    {
        private const string usage = @"
neon-conf prep-node DEFINITION-PATH
neon-conf prep-node SERVER1 [ SERVER2... ]

Configures a near virgin node so that it is prepared to join a Neon Docker
cluster.

Server Requirements:
--------------------

    * Supported version of Linux server.
    * Known admin credentials.
    * OpenSSH installed (or another SSH server)
    * SUDO configured to elevate permissions without
      asking for a password.
";
        private List<NodeManagementProxy<NodeDefinition>>   servers;

        /// <inheritdoc/>
        public string Name
        {
            get { return "prep-node"; }
        }

        /// <inheritdoc/>
        public bool NeedsCredentials
        {
            get { return true; }
        }

        /// <inheritdoc/>
        public void Help()
        {
            Console.WriteLine(usage);
        }
        
        /// <inheritdoc/>
        public void Run(CommandLine commandLine)
        {
            if (commandLine.Arguments.Length < 2)
            {
                Console.Error.WriteLine("Error: At least one server IP address or FQDN must be specified.");
                Program.Exit(1);
            }

            servers = new List<NodeManagementProxy<NodeDefinition>>();

            // If there's only one argument and it refers to a file that exists, then
            // assume it's a cluster definition file and initialize the servers from
            // there.
            //
            // Otherwise, we'll expect the arguments to be server DNS names or IP
            // addresses.

            ClusterDefinition clusterDefinition = null;

            if (commandLine.Arguments.Length == 2 && File.Exists(commandLine.Arguments[1]))
            {
                clusterDefinition = ClusterDefinition.FromFile(commandLine.Arguments[1]);

                foreach (var node in clusterDefinition.SortedNodes)
                {
                    servers.Add(Program.CreateNodeManagementProxy<NodeDefinition>(node.DnsName, node.Name));
                }
            }
            else
            {
                foreach (var serverHost in commandLine.GetArguments(1))
                {
                    servers.Add(Program.CreateNodeManagementProxy<NodeDefinition>(serverHost));
                }
            }

            // Perform the operation.

            var operation = new SetupController(Name, servers);

            operation.AddWaitUntilOnlineStep("connecting");
            operation.AddStep("preparing", server => CommonSteps.PrepareNode(server));

            operation.Run();
        }
    }
}
