﻿//-----------------------------------------------------------------------------
// FILE:	    CheckHealthCommand.cs
// CONTRIBUTOR: Jeff Lill
// COPYRIGHT:	Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using Newtonsoft;
using Newtonsoft.Json;

using Neon.Stack.Common;
using Neon.Stack.Management;

namespace NeonConf
{
    /// <summary>
    /// Implements the <b>check-health</b> command.
    /// </summary>
    public class CheckHealthCommand : ICommand
    {
        private const string usage = @"
neon-conf check-health DEFINITION-PATH

Verifies the health of the cluster nodes.
";
        private List<NodeManagementProxy<NodeDefinition>>   servers;
        private ClusterDefinition                           clusterDefinition;

        /// <inheritdoc/>
        public string Name
        {
            get { return "check-health"; }
        }

        /// <inheritdoc/>
        public bool NeedsCredentials
        {
            get { return true; }
        }

        /// <inheritdoc/>
        public void Help()
        {
            Console.WriteLine(usage);
        }

        /// <inheritdoc/>
        public void Run(CommandLine commandLine)
        {
            if (commandLine.Arguments.Length < 2)
            {
                Console.Error.WriteLine("Error: The cluster definition file path is required.");
                Program.Exit(1);
            }

            servers = new List<NodeManagementProxy<NodeDefinition>>();

            // Parse the cluster definition and initialize the servers.

            clusterDefinition = ClusterDefinition.FromFile(commandLine.Arguments[1]);

            foreach (var nodeDefinition in clusterDefinition.SortedNodes)
            {
                var server = (Program.CreateNodeManagementProxy<NodeDefinition>(nodeDefinition.DnsName, nodeDefinition.Name));

                server.Metadata         = nodeDefinition;
                server.Metadata.Address = server.ResolveAddress();
                servers.Add(server);
            }

            // Perform the operation.

            var operation = new SetupController(this.Name, servers);

            operation.AddWaitUntilOnlineStep("connecting");
            operation.AddStep("manager health check",  s => ClusterDiagnostics.CheckClusterManager(s, clusterDefinition), s => s.Metadata.Manager);
            operation.AddStep("worker health check",  s => ClusterDiagnostics.CheckClusterWorker(s, clusterDefinition), s => s.Metadata.Worker);
            operation.Run();
        }
    }
}
