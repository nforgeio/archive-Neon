﻿//-----------------------------------------------------------------------------
// FILE:	    SetupController.cs
// CONTRIBUTOR: Jeff Lill
// COPYRIGHT:	Copyright (c) 2016 by Neon Research, LLC.  All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.Contracts;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using Neon.Stack.Common;
using Neon.Stack.Management;

namespace NeonConf
{
    /// <summary>
    /// Manages a cluster server setup operation consisiting of a series of 
    /// setup operations steps, while displaying status to the <see cref="Console"/>.
    /// </summary>
    public class SetupController
    {
        //---------------------------------------------------------------------
        // Private types

        private enum StepStatus
        {
            None,
            Running,
            Done,
            Failed
        }

        private class Step
        {
            public string                                           Summary;
            public Action                                           GlobalAction;
            public Action<NodeManagementProxy<NodeDefinition>>      ServerAction;
            public Func<NodeManagementProxy<NodeDefinition>, bool>  Predicate;
            public StepStatus                                       Status;
            public bool                                             NoParallelLimit;
        }

        //---------------------------------------------------------------------
        // Implementation

        private string                                      operationSummary;
        private List<NodeManagementProxy<NodeDefinition>>   servers;
        private List<Step>                                  steps;
        private bool                                        error;

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="operationSummary">Summarizes the high-level operation being performed.</param>
        /// <param name="servers">The management proxies for the cluster servers being manipulated.</param>
        public SetupController(string operationSummary, IEnumerable<NodeManagementProxy<NodeDefinition>> servers)
        {
            this.operationSummary = operationSummary;
            this.servers          = servers.OrderBy(s => s.Name, StringComparer.InvariantCultureIgnoreCase).ToList();
            this.steps            = new List<Step>();
        }

        /// <summary>
        /// Appends a configuration step.
        /// </summary>
        /// <param name="stepSummary">Brief step summary.</param>
        /// <param name="serverAction">The action to be performed on each server.</param>
        /// <param name="serverPredicate">
        /// The predicate used to select the servers that participate in the step
        /// or <c>null</c> to select all servers.
        /// </param>
        public void AddStep(string stepSummary,
                            Action<NodeManagementProxy<NodeDefinition>> serverAction,
                            Func<NodeManagementProxy<NodeDefinition>, bool> serverPredicate = null)
        {
            serverAction    = serverAction ?? new Action<NodeManagementProxy<NodeDefinition>>(s => { });
            serverPredicate = serverPredicate ?? new Func<NodeManagementProxy<NodeDefinition>, bool>(s => true);

            steps.Add(
                new Step()
                {
                    Summary      = stepSummary,
                    ServerAction = serverAction,
                    Predicate    = serverPredicate
                });
        }

        /// <summary>
        /// Appends a configuration step that will not be limited by <see cref="Program.MaxParallel"/>.
        /// </summary>
        /// <param name="stepSummary">Brief step summary.</param>
        /// <param name="serverAction">The action to be performed on each server.</param>
        /// <param name="serverPredicate">
        /// The predicate used to select the servers that participate in the step
        /// or <c>null</c> to select all servers.
        /// </param>
        public void AddStepNoParallelLimit(string stepSummary,
                                           Action<NodeManagementProxy<NodeDefinition>> serverAction,
                                           Func<NodeManagementProxy<NodeDefinition>, bool> serverPredicate = null)
        {
            serverAction    = serverAction ?? new Action<NodeManagementProxy<NodeDefinition>>(s => { });
            serverPredicate = serverPredicate ?? new Func<NodeManagementProxy<NodeDefinition>, bool>(s => true);

            steps.Add(
                new Step()
                {
                    Summary         = stepSummary,
                    ServerAction    = serverAction,
                    Predicate       = serverPredicate,
                    NoParallelLimit = true
                });
        }

        /// <summary>
        /// Adds a global cluster configuration step.
        /// </summary>
        /// <param name="stepSummary">Brief step summary.</param>
        /// <param name="action">The global action to be performed.</param>
        public void AddGlobalStep(string stepSummary, Action action)
        {
            steps.Add(
                new Step()
                {
                    Summary      = stepSummary,
                    GlobalAction = action,
                    Predicate    = s => true,
                });
        }

        /// <summary>
        /// Adds a step that waits for nodes to be online.
        /// </summary>
        /// <param name="stepSummary">Brief step summary.</param>
        /// <param name="status">The optional server status.</param>
        /// <param name="serverPredicate">
        /// The predicate used to select the servers that participate in the step
        /// or <c>null</c> to select all servers.
        /// </param>
        public void AddWaitUntilOnlineStep(string stepSummary, string status = null, Func<NodeManagementProxy<NodeDefinition>, bool> serverPredicate = null)
        {
            AddStepNoParallelLimit(stepSummary,
                s =>
                {
                    s.Status = status ?? "connecting";
                    s.WaitForBoot();
                    s.IsReady = true;
                },
                serverPredicate);
        }

        /// <summary>
        /// Adds a step that waits for a specified period of time.
        /// </summary>
        /// <param name="stepSummary">Brief step summary.</param>
        /// <param name="delay">The amount of time to wait.</param>
        /// <param name="status">The optional server status.</param>
        /// <param name="serverPredicate">
        /// The predicate used to select the servers that participate in the step
        /// or <c>null</c> to select all servers.
        /// </param>
        public void AddDelayStep(string stepSummary, TimeSpan delay, string status = null, Func<NodeManagementProxy<NodeDefinition>, bool> serverPredicate = null)
        {
            AddStepNoParallelLimit(stepSummary,
                s =>
                {
                    s.Status = status ?? $"delay: [{delay.TotalSeconds}] seconds";
                    Thread.Sleep(delay);
                    s.IsReady = true;
                },
                serverPredicate);
        }

        /// <summary>
        /// Performs the operation steps in the order they were added.
        /// </summary>
        /// <param name="leaveServersConnected">Pass <c>true</c> leave the servers connected.</param>
        /// <returns><c>true</c> if all steps completed successfully.</returns>
        public bool Run(bool leaveServersConnected = false)
        {
            try
            {
                foreach (var step in steps)
                {
                    if (!PerformStep(step))
                    {
                        break;
                    }
                }

                if (error)
                {
                    return false;
                }

                foreach (var server in servers)
                {
                    server.Status = "ready";
                }

                DisplayStatus();
                return true;
            }
            finally
            {
                if (!leaveServersConnected)
                {
                    // Dispose all of the servers so they'll close any open connections.

                    foreach (var server in servers)
                    {
                        server.Dispose();
                    }
                }
            }
        }

        /// <summary>
        /// Performs an operation step on the selected servers.
        /// </summary>
        /// <param name="step">A step being performed.</param>
        /// <returns><c>true</c> if the step succeeded.</returns>
        /// <remarks>
        /// <para>
        /// This method begins by setting the <see cref="NodeManagementProxy{TMetadata}.IsReady"/>
        /// state of each selected server to <c>false</c> and then it starts a new thread for
        /// each server and performs the action on these server threads.
        /// </para>
        /// <para>
        /// In parallel, the method spins on the current thread, displaying status while
        /// waiting for each of the servers to transition to the <see cref="NodeManagementProxy{TMetadata}.IsReady"/>=<c>true</c>
        /// state.
        /// </para>
        /// <para>
        /// The method returns <c>true</c> after all of the server actions have completed
        /// and none of the servers have <see cref="NodeManagementProxy{TMetadata}.IsFaulted"/>=<c>true</c>.
        /// </para>
        /// <note>
        /// This method does nothing if a previous step failed.
        /// </note>
        /// </remarks>
        private bool PerformStep(Step step)
        {
            if (error)
            {
                return false;
            }

            step.Status = StepStatus.Running;

            var stepServers        = servers.Where(step.Predicate);
            var stepServerNamesSet = new HashSet<string>(StringComparer.InvariantCultureIgnoreCase);

            foreach (var server in stepServers)
            {
                stepServerNamesSet.Add(server.Name);

                server.IsReady = false;
            }

            foreach (var server in servers)
            {
                if (stepServerNamesSet.Contains(server.Name))
                {
                    server.Status = string.Empty;
                }
                else
                {
                    server.Status = string.Empty;
                }
            }

            DisplayStatus(stepServerNamesSet);

            var parallelOptions = new ParallelOptions()
            {
                MaxDegreeOfParallelism = step.NoParallelLimit ? 500 : Program.MaxParallel
            };

            NeonHelper.ThreadRun(
                () =>
                {
                    if (step.ServerAction != null)
                    {
                        Parallel.ForEach(stepServers, parallelOptions,
                            server =>
                            {
                                try
                                {
                                    step.ServerAction(server);

                                    server.Status  = "* step complete";
                                    server.IsReady = true;
                                }
                                catch (Exception e)
                                {
                                    server.Fault(NeonHelper.ExceptionError(e));
                                }
                            });
                    }
                    else if (step.GlobalAction != null)
                    {
                        step.GlobalAction();
                    }
                });

            while (true)
            {
                DisplayStatus(stepServerNamesSet);

                if (stepServers.Count(s => !s.IsReady || s.IsFaulted) == 0)
                {
                    DisplayStatus(stepServerNamesSet);
                    break;
                }

                Thread.Sleep(TimeSpan.FromSeconds(2));
            }

            error = stepServers.FirstOrDefault(s => s.IsFaulted) != null;

            if (error)
            {
                step.Status = StepStatus.Failed;

                return false;
            }
            else
            {
                step.Status = StepStatus.Done;

                return true;
            }
        }

        /// <summary>
        /// Returns the current status for a server.
        /// </summary>
        /// <param name="stepServerNamesSet">The set of server names participating in the current step.</param>
        /// <param name="server">The server being queried.</param>
        /// <returns>The status prefix.</returns>
        private string GetStatus(HashSet<string> stepServerNamesSet, NodeManagementProxy<NodeDefinition> server)
        {
            if (stepServerNamesSet != null && !stepServerNamesSet.Contains(server.Name))
            {
                return "  -";
            }
            else
            {
                // We mark completed steps with a "* " prefix and indent
                // non-completed steps status with two blanks.

                if (server.Status.StartsWith("* "))
                {
                    return server.Status;
                }
                else
                {
                    return "  " + server.Status;
                }
            }
        }

        /// <summary>
        /// Formats a step index into a form suitable for display.
        /// </summary>
        /// <param name="stepNumber">The step index.</param>
        /// <returns>The formatted step number.</returns>
        private string FormatStepNumber(int stepNumber)
        {
            int     stepCount = steps.Count();
            string  number;

            if (stepCount < 10)
            {
                number = $"{stepNumber,1}";
            }
            else if (stepCount < 100)
            {
                number = $"{stepNumber,2}";
            }
            else
            {
                number = stepNumber.ToString();
            }

            return $"{number}. ";
        }

        /// <summary>
        /// Displays the current operation status on the <see cref="Console"/>.
        /// </summary>
        /// <param name="stepServerNamesSet">
        /// The set of server names that participating in the current step or
        /// <c>null</c> if all servers are included.
        /// </param>
        private void DisplayStatus(HashSet<string> stepServerNamesSet = null)
        {
            var underline           = " " + new string('-', 39);
            var maxStepSummaryWidth = steps.Max(s => s.Summary.Length);
            var maxNameWidth        = servers.Max(s => s.Name.Length);
            var stepNumber          = 0;

            Console.Clear();
            Console.WriteLine();
            Console.WriteLine($" {operationSummary}");
            Console.WriteLine();

            Console.WriteLine();
            Console.WriteLine(" Steps:");
            Console.WriteLine(underline);
            Console.WriteLine();

            foreach (var step in steps)
            {
                stepNumber++;

                switch (step.Status)
                {
                    case StepStatus.None:

                        Console.WriteLine($"     {FormatStepNumber(stepNumber)}{step.Summary}");
                        break;

                    case StepStatus.Running:

                        Console.WriteLine($" --> {FormatStepNumber(stepNumber)}{step.Summary}");
                        break;

                    case StepStatus.Done:

                        Console.WriteLine($"     {FormatStepNumber(stepNumber)}{step.Summary}{new string(' ', maxStepSummaryWidth - step.Summary.Length)}   [done]");
                        break;

                    case StepStatus.Failed:

                        Console.WriteLine($"     {FormatStepNumber(stepNumber)}{step.Summary}{new string(' ', maxStepSummaryWidth - step.Summary.Length)}   [fail]"); ;
                        break;
                }
            }

            if (servers.First().Metadata != null)
            {
                Console.WriteLine();
                Console.WriteLine();
                Console.WriteLine(" Managers:");
                Console.WriteLine(underline);
                Console.WriteLine();

                foreach (var server in servers.Where(s => s.Metadata.Manager))
                {
                    Console.WriteLine($"    {server.Name}{new string(' ', maxNameWidth - server.Name.Length)}   {GetStatus(stepServerNamesSet, server)}");
                }

                Console.WriteLine();
                Console.WriteLine();
                Console.WriteLine(" Workers:");
                Console.WriteLine(underline);
                Console.WriteLine();

                foreach (var server in servers.Where(s => s.Metadata.Worker))
                {
                    Console.WriteLine($"    {server.Name}{new string(' ', maxNameWidth - server.Name.Length)}   {GetStatus(stepServerNamesSet, server)}");
                }
            }
            else
            {
                Console.WriteLine();
                Console.WriteLine();
                Console.WriteLine("Nodes:");
                Console.WriteLine(underline);
                Console.WriteLine();

                foreach (var server in servers)
                {
                    Console.WriteLine($"    {server.Name}{new string(' ', maxNameWidth - server.Name.Length)}   {GetStatus(stepServerNamesSet, server)}");
                }
            }

            Console.WriteLine();
            Console.WriteLine();
        }

        /// <summary>
        /// Throws an exception if any of the operation steps did not complete successfully.
        /// </summary>
        public void ThrowOnError()
        {
            if (error)
            {
                throw new NeonManagementException($"[{servers.Count(s => s.IsFaulted)}] servers are faulted.");
            }
        }
    }
}
